# GenTestCode

## 职责概述

GenTestCode 负责根据需求文档和生成的 CUDA kernel 代码，生成完整的自包含测试程序。测试包括确定性数据、独立 CPU reference、精度验证、CUDA API/launch 检查和 CUDA Event 性能测量。

## 输入

| 来源 | 内容 |
|------|------|
| Extractor 输出 | `{输出存储路径}/Extractor/requirement.md` |
| io_shapes | `{输出存储路径}/KernelGen/step1_io_shapes.json` |
| Step 5 输出 | `{输出存储路径}/KernelGen/step5_kernel_code.cu` |
| RTX 3090 平台规则 | `.claude/skills/share/cuda-c/references/platform-rules.md` |
| 用户输入 | 输出存储路径（默认为 `output_dir`） |

## 输出

| 输出类型 | 说明 |
|---------|------|
| 文件输出 | `{输出存储路径}/KernelGen/step6_test_code.cu` - 完整测试代码（包含 CUDA code + CPU reference + 精度与性能测试） |

## 执行步骤

### 步骤 0：检查测试完整性（快速路径）

在执行步骤 1 之前，先检查 Step 5 输出的 CUDA C/C++ 代码中是否已包含完整测试。

#### 检查标准

**完整的测试代码必须同时满足以下条件**：

1. **精度测试**（至少满足一项）：
   - 包含 `accuracy_test` 函数或 `test_accuracy` 函数
   - 包含按 `abs(actual-expected) <= atol + rtol*abs(expected)` 比较的逻辑
   - 包含 GPU 输出与独立 CPU C++ reference 的对比和非零失败退出码

2. **性能测试**（至少满足一项）：
   - 包含 `performance_test` 函数或 `test_performance` 函数
   - 包含 `cudaEventCreate/Record/ElapsedTime`
   - 包含 warmup、重复 launch、stop event 同步和吞吐量计算

#### 判断结果

| 检查结果 | 处理方式 |
|---------|--------|
| **测试完整**（同时有精度+性能测试） | 直接使用原始代码，跳过步骤 1-3，将原始代码保存为 step6_test_code.cu |
| **测试不完整**（缺少精度或性能测试） | 继续执行步骤 1-3，补充完整测试 |
| **无测试代码** | 继续执行步骤 1-3，生成完整测试 |

#### 注意事项

- 检查的是 **Step 5 输出的代码**（即 `{输出存储路径}/KernelGen/step5_kernel_code.cu`）

### 步骤 1：解析需求文档、io_shapes 和 CUDA C/C++ 代码

从 Extractor 的需求文档中提取测试相关信息：
- 计算逻辑公式
- 输入/输出数据规格（shapes、dtypes、contiguous）
- 多组测试数据的规格
- 参数信息（axis、keepdim 等）

从 `step1_io_shapes.json` 中读取 io_shapes，用于生成测试输入：
- 该文件的顶层结构即为 io_shapes 对象（每个键是指针名，值含 type/axis/shape/contiguity）
- 根据 io_shapes 中的 shape 生成对应 host buffer 和 device allocation
- 根据 io_shapes 中的 contiguity 生成明确的 stride/padding，不能把非连续用例悄悄改成连续
- 根据 io_shapes 中的 axis 名称（如 N、M、K）生成对应的常量定义

从 Step 5 的 CUDA C/C++ code 中提取：
- kernel 函数名
- wrapper 函数名
- 函数签名

### 步骤 2：处理不完整数据

**主要参考来源**：优先从 `step1_io_shapes.json` 获取输入输出规格信息。

如果 io_shapes 中某些数据规格为 `None` 或不完整，GenTestCode **自动生成合理的测试数据**：

1. **形状（shapes）**：优先从 io_shapes 中读取，若缺失则根据计算逻辑生成合理的形状
2. **数据类型（dtypes）**：若 io_shapes 中未指定，默认使用 float32
3. **连续性（contiguous）**：若 io_shapes 中未指定，默认生成全连续的数据

### 步骤 2.1：精度阈值设置

精度阈值的选择遵循以下**优先级规则**：

#### 规则 1（最高优先级）：客户已约定精度标准

如果 `requirement.md` 中明确给出了精度阈值（如 `atol`、`rtol`、`tolerance`、"精度要求"等字段），**必须严格使用客户指定的精度标准**，不得擅自放宽或收紧。

#### 规则 2（兜底）：客户未约定时，按计算公式选择

查看 `requirement.md` 中的"计算逻辑公式"，根据是否含有**累计类型（accumulation）计算**来决定：

| 场景 | 典型算子 | `atol` / `rtol` |
|------|---------|----------------|
| **不含累计类型计算** | elementwise（add / mul / relu / sigmoid 等）、copy、简单变换 | `1e-4` |
| **含累计类型计算** | reduce（sum / mean / max / min / argmax）、matmul、dot、conv、softmax、layernorm、cumsum 等 | `1e-3` |

**累计类型计算的判定要点**：公式中存在跨多个元素的求和 / 内积 / 逐步累积（循环累加）等操作，浮点累加误差会随参与元素个数放大，因此需要更宽松的阈值。
#### 落地要求

- 在生成的测试代码中，逐元素比较使用的 `atol` / `rtol` 必须等于按上述规则选出的值。
- 若同时受规则 1 约束，以客户指定为准。
- **注意**：不要擅自添加额外的精度测试项目，例如比特级精度测试。

### ⚠️ 特别提醒：禁止修改输入的 CUDA Kernel 代码

**在生成测试代码时，必须保持 Step 5 输出的 CUDA kernel 与 wrapper 完全不变，禁止任何修改，包括但不限于：**
- 不能添加、删除或修改 kernel 函数中的任何代码
- 不能修改变量名、函数名、注释
- 不能改变算法逻辑
- 只能原样复制 Step 5 代码，再在其后追加 CPU reference、test harness 和 `main`

### 步骤 3：生成完整测试代码

**⚠️ 重要要求：测试代码必须严格按照以下结构生成**

**输出格式**：完整的可执行 `.cu` 文件，包含：
1. **CUDA kernel 与 wrapper**（从 Step 5 原样获取）
2. **数据生成函数** - 根据 shapes、dtypes、stride 创建确定性 host 数据
3. **CPU reference** - 不复制 GPU 线程索引，以更高精度累加实现数学合同
4. **精度验证函数** - 对比 GPU 与 CPU，失败时打印首个 index/error 并返回 false
5. **性能测试函数** - 使用 CUDA Event 测量同一 stream 上的 device work

**⚠️ 强制要求：测试代码必须严格按照下面的测试模版生成**

**⚠️ 硬性要求：性能测试必须使用 CUDA Event；CPU reference、allocation 和 H2D/D2H 不得计入 kernel-only 时间**

#### 性能带宽计算要求

生成性能测试时，带宽（GB/s）必须按算子的**实际读写数据类型**估算，不得无脑使用 `2 * x.numel() * x.element_size()`。

- 优先从 `io_shapes`、wrapper 参数和 CPU reference 输出识别所有输入/输出 buffer。
- `total_bytes` 累计每个实际读/写 buffer 的 `numel * sizeof(dtype)`；多输出、scale、indices、mask 分别计入。
- 对 in-place 算子按实际读写口径计入，通常至少一次读和一次写。
- 如果需求规定吞吐口径，必须用注释记录，不得随候选变化。

推荐生成一个小工具函数，根据实际 tensor 计算 bytes：

```cpp
const double total_bytes = input_numel * sizeof(InputT)
                         + output_numel * sizeof(OutputT);
const double gbps = total_bytes / (kernel_ms * 1.0e6);
```

**测试代码模版**：
```cpp
#include <cuda_runtime.h>
#include <algorithm>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <cstdio>
#include <random>
#include <vector>

#define CUDA_CHECK(expr) do { cudaError_t e = (expr); if (e != cudaSuccess) { \
  std::fprintf(stderr, "CUDA error %s:%d: %s\n", __FILE__, __LINE__, \
               cudaGetErrorString(e)); return false; } } while (0)

// Step 5 的 kernel 与 wrapper 在此逐字保留。

void create_inputs(std::vector<float>& x) {
    std::mt19937 rng(12345);
    std::uniform_real_distribution<float> dist(-1.0f, 1.0f);
    for (float& v : x) v = dist(rng);
}

void cpu_reference(const std::vector<float>& x, std::vector<float>& expected) {
    // 按 requirement 独立实现；归约默认以 double 累加。
}

bool accuracy_test(cudaStream_t stream) {
    // 对每组 shape 分配 host/device buffer，执行 H2D、wrapper、错误检查和 D2H。
    CUDA_CHECK(cudaGetLastError());
    CUDA_CHECK(cudaStreamSynchronize(stream));
    // 逐元素检查 abs(actual-expected) <= ATOL + RTOL*abs(expected)。
    // 失败时打印 test id、首个 index、expected/actual、abs/rel error。
    return true;
}

bool performance_test(cudaStream_t stream, std::size_t total_bytes_per_call) {
    // total_bytes_per_call 必须由本算子的真实输入/输出 buffer 元素数与 dtype 字节数求和得到。
    // 原地读写按一次读 + 一次写计；workspace 只有被 kernel 实际访问时才计入。
    if (total_bytes_per_call == 0) {
        std::printf("baseline_ms=N/A baseline_gbps=N/A reason=undefined_byte_model\n");
        return false;
    }
    constexpr int warmup = 20;
    constexpr int iterations = 200;
    for (int i = 0; i < warmup; ++i) wrapper_function(/*...,*/ stream);
    CUDA_CHECK(cudaStreamSynchronize(stream));
    cudaEvent_t start{}, stop{};
    CUDA_CHECK(cudaEventCreate(&start));
    CUDA_CHECK(cudaEventCreate(&stop));
    CUDA_CHECK(cudaEventRecord(start, stream));
    for (int i = 0; i < iterations; ++i) wrapper_function(/*...,*/ stream);
    CUDA_CHECK(cudaEventRecord(stop, stream));
    CUDA_CHECK(cudaEventSynchronize(stop));
    float total_ms = 0.0f;
    CUDA_CHECK(cudaEventElapsedTime(&total_ms, start, stop));
    const float kernel_ms = total_ms / iterations;
    if (!(kernel_ms > 0.0f)) return false;
    const double gbps = static_cast<double>(total_bytes_per_call) /
                        (static_cast<double>(kernel_ms) * 1.0e6);
    std::printf("baseline_ms=%.6f baseline_gbps=%.3f\n", kernel_ms, gbps);
    CUDA_CHECK(cudaEventDestroy(start));
    CUDA_CHECK(cudaEventDestroy(stop));
    return true;
}

int main() {
    cudaStream_t stream{};
    if (cudaStreamCreate(&stream) != cudaSuccess) return 2;
    const std::size_t total_bytes_per_call = /* 按实际 buffers 计算，禁止保留此占位 */;
    const bool accuracy_pass = accuracy_test(stream);
    const bool performance_pass = accuracy_pass && performance_test(stream, total_bytes_per_call);
    cudaStreamDestroy(stream);
    return accuracy_pass && performance_pass ? 0 : 1;
}
```

模板中的占位注释必须按具体算子替换，不得原样留在产物中；所有分配、事件和 stream 在失败路径也要释放。

### 步骤 4：应用 RTX 3090 / CUDA 平台规则

读取 `.claude/skills/share/cuda-c/references/platform-rules.md`，按其中的 Runtime、同步、Grid、资源和执行后端规则生成测试。默认编译为 `nvcc -std=c++17 -O3 -DNDEBUG -lineinfo -arch=sm_86`，不得默认启用 fast math。

### 步骤 5：保存结果

将完整测试代码保存到 `{输出存储路径}/KernelGen/step6_test_code.cu`

## 验证方式

| 检查项 | 验证方式 | 通过条件 |
|--------|--------|--------|
| Step 0 快速路径 | 检查 step5 代码中的测试完整性 | 同时有精度测试+性能测试则使用原始代码 |
| step1_io_shapes.json 存在 | 检查文件是否存在 | step1_io_shapes.json 存在且可读 |
| Step 5 输出存在 | 检查文件是否存在 | step5_kernel_code.cu 存在且可读 |
| 编译检查 | 目标环境执行 `nvcc -std=c++17 -arch=sm_86` | 无编译错误；环境不可用时明确标记未运行 |
| 测试函数完整 | 检查必需函数 | 包含 create_inputs, cpu_reference, accuracy_test, performance_test, main |
| 输入规格一致性 | 对比测试代码中 SHAPE/DTYPE 与 step1_io_shapes.json（其次参考 requirement.md） | 每个维度、dtype 完全相等，无缩减/替换；未给出的字段按步骤 2 自行生成 |
| 数据生成 | 检查固定 seed、shape/stride 和边界用例 | 可复现，包含非整 block 与空输入处理 |
| CUDA 错误处理 | 检查 API、launch 与同步 | API 返回值检查；launch 后检查；失败返回非零 |

## 回退机制

| 失败场景 | 处理方式 |
|---------|--------|
| Step 0 快速路径判断错误 | 降级到步骤 1-3，生成完整测试 |
| step1_io_shapes.json 不存在或无效 | 返回错误 |
| Step 5 输出不存在或无效 | 返回错误 |
| 数据规格不完整 | 内部重试（最多 3 次） |
| 测试代码生成失败 | 内部重试（最多 3 次） |
| 缺少必需的测试函数 | 内部重试（最多 3 次） |

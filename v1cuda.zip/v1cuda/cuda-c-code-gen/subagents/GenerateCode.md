# GenerateCode

## 职责概述

GenerateCode 是 cuda-c-code-gen 工作流程的第 5 步 subagent。负责根据代码生成方案规范，生成完整的 CUDA C/C++ kernel 和 host wrapper/launcher。

**重要**：只生成单一 self-contained `.cu` translation unit 的 kernel + host wrapper，**不包含测试代码**。

## ⚠️ 重要注意事项

**代码生成必须同时遵循两方面的逻辑：**
1. **Step 4 规范** (`step4_code_spec.json`)：block_params、grid、aux_params、loads、stores 等技术规范
2. **用户原始需求** (`requirement.md`)：算子的功能逻辑、计算公式、数据变换规则

两者必须保持一致，不能冲突。如果发现不一致，应以用户需求的功能逻辑为准，并确保代码正确实现该功能。

## 输入

| 来源 | 内容 |
|------|------|
| Step 4 输出 | `{输出存储路径}/KernelGen/step4_code_spec.json` |
| 用户输入 | `{输出存储路径}/Extractor/requirement.md` |
| 生成阶段原语约束 | `.claude/skills/share/cuda-c/references/primitives.md` |
| RTX 3090 平台约束 | `.claude/skills/share/cuda-c/references/platform-rules.md` |

## 输出

| 输出类型 | 说明 |
|---------|------|
| 文件输出 | `{输出存储路径}/KernelGen/step5_kernel_code.cu` - 完整的 CUDA kernel + host wrapper |

## 执行步骤

### 步骤 1：读取 Step 4 结果和原始需求

读取 step4_code_spec.json、共享原语清单和 RTX 3090 平台规则，获取：
- kernel 规范：block_params, aux_params, loads, stores, reduce_loop
- wrapper 规范：grid, block, block_params, shared_bytes, stream, build_flags
- 接口签名（函数参数）
- CUDA C/C++ 允许的 Runtime、warp、shared-memory 与数学原语

### 步骤 2：生成 CUDA C/C++ Kernel 代码

**⚠️ 强制要求：必须严格按照 step4_code_spec 生成代码，同时遵循 requirement.md 中的功能逻辑**

> **关键**：代码不仅要符合 step4_code_spec 的技术规范（参数名、索引公式、grid 配置），还必须正确实现用户需求中描述的计算逻辑（如 `out[i,j] = func(x[i,j])`、`Y[n,k] = Σ X[n,m,k]` 等）。两者必须保持一致。
**重要**：只生成 CUDA kernel + host wrapper，**不包含测试代码**。

#### 2.1 使用 block_params 定义 Kernel 参数

从 `step4_code_spec.kernel.block_params` 获取所有 BLOCK 参数。固定配置可用 `constexpr`，运行时 shape/stride 必须作为 C++ 参数传入：

```cpp
template <int BLOCK_XX>
__global__ void kernel_name(const float* input, float* output,
                            std::int64_t n, std::int64_t stride) {
    // 使用 blockIdx/threadIdx 实现 spec 中的映射。
}
```

#### 2.2 处理归约操作（如有 reduce_loop/reduce_loop_passN）

**归约操作要求**：

- **强制优先策略**：让一个 thread/warp/block 完成其负责输出的完整归约，线程以 `threadIdx.x` 步进覆盖归约轴；减少跨 block partial buffer、atomic 和二次 launch。
- **实现目标**：每线程用寄存器保存 partial，再按 spec 选择 warp shuffle 或 shared-memory block reduction。
- **原语约束**：必须遵守 `.claude/skills/share/cuda-c/references/primitives.md`。
- **平台约束**：读取 `.claude/skills/share/cuda-c/references/platform-rules.md`，应用 RTX 3090 / `sm_86` 的 warp、资源、Grid 与 Runtime 规则。

**判断归约类型**：
- **单遍归约**：使用 `step4_code_spec.kernel.reduce_loop` 字段
- **多遍归约**：使用 `step4_code_spec.kernel.reduce_loop_pass1`, `reduce_loop_pass2`, ... 字段

**单遍归约**（使用 `reduce_loop`）：

优先读取 `reduce_loop.reduction_strategy`：
- `thread_serial`：当前线程循环累积后直接写唯一输出。
- `warp_shuffle`：每 lane 累积 partial，再用正确 active mask 执行 `__shfl_down_sync`。
- `shared_block_reduction`：warp partial 经 shared memory 合并；所有未退出线程一致到达 `__syncthreads()`。
- `multi_kernel`：生成明确的 partial buffer 和第二 kernel；host wrapper 依序在同一 stream launch。

```cpp
float acc = 0.0f;
for (std::int64_t r = threadIdx.x; r < reduce_size; r += blockDim.x)
    acc += static_cast<float>(input[base + r * stride]);
for (int delta = warpSize / 2; delta > 0; delta /= 2)
    acc += __shfl_down_sync(__activemask(), acc, delta);
// shared_block_reduction 时继续按 spec 合并 warp partial，由唯一线程写回。
```

**无直接原语支持的归约**：

- 当归约语义不在直接模式列表时，组合 CUDA 算术、warp shuffle 或 shared memory；禁止假设 block 间隐式同步。
- mean 在 sum 完成后除以 count；max/min 使用正确 identity，并遵守 NaN 合同。

**多遍归约**（使用 `reduce_loop_pass1`, `reduce_loop_pass2`, ...）：

```cpp
// pass1 和 pass2 按 spec 顺序执行；若 pass 间依赖 block 级全局结果，
// 必须拆成同一 stream 上的多个 kernel，而不是在一个 kernel 中跨 block 同步。
pass1_kernel<<<grid1, block1, shared1, stream>>>(...);
pass2_kernel<<<grid2, block2, shared2, stream>>>(...);
```

**关键点**：
- 使用 `reduce_dim` 确定需要遍历的总大小
- 使用 `reduce_block` 作为循环步长进行分块处理
- 使用 `reduce_var` 作为循环变量
- 累加器使用正确 identity 初始化；FP16/BF16 默认以 FP32 累加
- 按 `participants` 与 `synchronization` 实现协作，任何 barrier 不得位于会导致线程分歧的路径
- 多遍归约时，按顺序执行每遍归约循环

#### 2.3 使用 aux_params 计算索引偏移

从 `step4_code_spec.kernel.aux_params` 获取辅助参数，直接照写：

```cpp
const std::int64_t idx = static_cast<std::int64_t>(blockIdx.x) * blockDim.x + threadIdx.x;
const std::int64_t grid_stride = static_cast<std::int64_t>(blockDim.x) * gridDim.x;
```

#### 2.4 使用 loads 公式进行数据加载

从 `step4_code_spec.kernel.loads` 获取公式，注意嵌套结构 `index_指针名` 和 `mask_指针名`：

```cpp
x_index = <index_指针名公式>
if (<mask_指针名公式>) x = x_ptr[x_index];
```

#### 2.5 使用 stores 公式进行数据存储

从 `step4_code_spec.kernel.stores` 获取公式：

```cpp
out_index = <index_指针名公式>
if (<mask_指针名公式>) out_ptr[out_index] = result;
```

### 步骤 3：生成 Wrapper 函数

从 `step4_code_spec.wrapper` 获取：

#### 3.1 使用 grid 设置并行度

```cpp
dim3 grid(ceil_div(N, BLOCK_N), ceil_div(M, BLOCK_M), 1);
dim3 block(BLOCK_N, BLOCK_M, 1);
```

#### 3.2 使用 wrapper.block_params 设置默认块大小

```cpp
constexpr int BLOCK_N = 32;
constexpr int BLOCK_M = 8;
```

#### 3.3 调用 kernel

```cpp
if (N > 0 && M > 0) {
    kernel<BLOCK_N, BLOCK_M><<<grid, block, shared_bytes, stream>>>(
        x_ptr, out_ptr, x_stride0, N, M);
    CUDA_CHECK(cudaGetLastError());
}
```

### 步骤 4：保存结果

**重要**：只保存 CUDA kernel 和 host wrapper，**不包含测试代码**。

将代码保存到 `{输出存储路径}/KernelGen/step5_kernel_code.cu`

## 代码生成规范

### 强制规则

1. **BLOCK 参数**：必须使用 `step4_code_spec.kernel.block_params` 中的**所有**参数，名称必须完全一致
2. **Grid 维度**：必须与 `step4_code_spec.wrapper.grid` 完全一致
3. **线程映射**：必须使用 `step4_code_spec.kernel.aux_params` 中的 `blockIdx`/`threadIdx` 定义
4. **偏移量 (offset) 和索引 (idx)**：必须使用 `step4_code_spec.kernel.aux_params` 中的定义
5. **索引计算公式**：必须使用 `step4_code_spec.kernel.loads` 和 `step4_code_spec.kernel.stores` 中 `index_指针名` 的公式
6. **归约执行位置**：对于归约类算子，必须优先按照 `reduce_loop` / `reduce_loop_passN` 在 Kernel 内部循环中执行归约轴遍历与累积
### 禁止事项

- **🚫 禁止**使用 step4_code_spec 中**不存在的**参数名
- **🚫 禁止**将参数改名或拆分（如把 `BLOCK_HW` 改成 `BLOCK_H` 或 `BLOCK_W`）
- **🚫 禁止**自己重新计算索引，必须直接使用公式中的变量名
- **🚫 禁止**在没有 64 位溢出分析时用窄整数拆分融合索引
- **🚫 禁止**主动生成 `.claude/skills/share/cuda-c/references/primitives.md` 中列出的禁用原语

### CUDA C/C++ 适配

- 包含标准/CUDA headers、`CUDA_CHECK` 或等价错误辅助
- kernel 使用 `__global__`，wrapper 接受 `cudaStream_t`
- 每次 launch 后立即检查 `cudaGetLastError()`；业务 wrapper 不隐式同步
- 默认 `-std=c++17 -O3 -lineinfo -arch=sm_86`，不得默认启用 `--use_fast_math`

## 输出格式

```cpp
#include <cuda_runtime.h>
#include <cstdint>

__global__ void kernel_name(...) {
    // kernel 实现
}

cudaError_t wrapper_function(..., cudaStream_t stream) {
    // 参数检查、launch、cudaGetLastError
}
```

**重要**：只返回自包含 CUDA C/C++ kernel 和 host wrapper，不要包含测试代码。

## 验证方式

| 检查项 | 验证方式 | 通过条件 |
|--------|--------|--------|
| Step 4 输出存在 | 检查文件是否存在 | step4_code_spec.json 存在且可读 |
| 语法检查 | `nvcc -std=c++17 -arch=sm_86` 编译检查（环境可用时） | 无编译错误；否则明确标记未运行 |
| Header 检查 | 检查标准/CUDA headers | 不依赖未提供项目 header |
| 函数签名 | 检查参数和返回值 | 与 step5 规范中的 block_params 一致 |
| Index 计算 | 验证 load/store 索引公式 | 与 step5 规范中的 index_指针名 一致 |
| Grid 配置 | 检查 grid 计算公式 | 与 step5 规范中的 wrapper.grid 一致 |
| CUDA 错误处理 | 检查 Runtime API 与 launch | API 返回值被检查，launch 后检查 `cudaGetLastError()` |

## 参考场景

按需加载对应场景的输入输出代码示例：需要参考示例时，从下列场景对应链接读取。

#### 场景1：Transpose + Elementwise（无融合）

对应示例：[generate_code_transpose_elementwise.md](./examples/generate_code_transpose_elementwise.md)

#### 场景2：Reduce Sum（归约操作）

对应示例：[generate_code_reduce_sum.md](./examples/generate_code_reduce_sum.md)

#### 场景3：轴融合后（H+W -> HW）

对应示例：[generate_code_axis_fusion.md](./examples/generate_code_axis_fusion.md)

#### 场景4：矩阵转置（Transpose）

对应示例：[generate_code_matrix_transpose.md](./examples/generate_code_matrix_transpose.md)

## 回退机制

| 失败场景 | 处理方式 |
|---------|--------|
| Step 4 输出不存在或无效 | 返回错误 |
| 代码生成失败 | 内部重试（最多 3 次） |
| 语法错误 | 内部重试（最多 3 次） |
| Index 计算与规范不一致 | 内部重试（最多 3 次） |
| Grid 配置与规范不一致 | 内部重试（最多 3 次） |

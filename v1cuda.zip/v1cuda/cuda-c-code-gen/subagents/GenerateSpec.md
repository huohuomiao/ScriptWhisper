# GenerateSpec

## 职责概述

GenerateSpec 是 cuda-c-code-gen 工作流程的第 4 步 subagent。负责根据前一步的轴融合结果，生成可直接落地的 CUDA C/C++ kernel、launch、shared-memory 与同步规范。

## 输入

| 来源 | 内容 |
|------|------|
| Step 3 输出 | `{输出存储路径}/KernelGen/step3_axis_fusion.json` |
| 生成阶段原语约束 | `.claude/skills/share/cuda-c/references/primitives.md` |
| RTX 3090 平台约束 | `.claude/skills/share/cuda-c/references/platform-rules.md` |

## 输出

| 输出类型 | 说明 |
|---------|------|
| 文件输出 | `{输出存储路径}/KernelGen/step4_code_spec.json` - 代码生成方案规范 |

## 执行步骤

### 步骤 1：读取 Step 3 结果和原始需求

读取 step3_axis_fusion.json、共享原语清单和 RTX 3090 / `sm_86` 平台规则，获取：
- compute_formula
- compute_note（description + reference_impl，用于生成 kernel.compute.note 并辅助理解计算逻辑）
- io_block_mapping（包含 block_name, axis_size, contiguity, reduce_dim —— 形状/连续性已凝结于此，直接使用）
- fusion_note（如有）
- 接口签名
- CUDA C/C++ 允许使用的 Runtime、warp、shared-memory 与数学原语

### 步骤 2：生成代码规范

使用 LLM 生成推荐的 CUDA C/C++ Kernel 代码规范：

**设计内容**：
- **kernel 部分**：
  - block_params：BLOCK 参数定义，值为各轴 size 数组
  - aux_params：辅助计算参数定义（如 `blockIdx`/`threadIdx`、offset、线性索引，仅保留公共计算信息）
  - loads：各指针的 index 和 mask 计算公式，
  - stores：各指针的 index 和 mask 计算公式，
  - reduce_loop/reduce_loop_passN：归约循环、线程协作、shared memory 与同步策略（如有），**详见下方拆分规则**

- **wrapper 部分**：
  - grid：`dim3` 计算公式，如 `dim3(ceil_div(N, BLOCK_N), 1, 1)`
  - block：`dim3` thread-block 配置
  - shared_bytes、stream 与 build_flags
  - block_params：BLOCK 参数默认值（整数形式）

**输出格式**：
```json
{
"compute_formula": "计算公式",
    "compute_note": {
        "description": "算子计算逻辑的自然语言描述",
        "reference_impl": "对应的独立 CPU C++ 参考实现"
    },
    "fusion_note": "融合说明（如有）",
    "kernel": {
        "block_params": {"BLOCK_XX": [维度大小数组], ...},
        "aux_params": {"变量名": "计算公式", ...},
        "loads": {
            "指针名1": {
                "index_指针名1": "64 位线性 index 计算公式",
                "mask_指针名1": "mask计算公式（可选，用于边界检查）"
            },
            ...
        },
        "stores": {
            "指针名2": {
                "index_指针名2": "64 位线性 index 计算公式",
                "mask_指针名2": "mask计算公式（可选）"
            },
            ...
        },
        // 单遍归约时使用（一般情况）：
        "reduce_loop": {
            "reduce_dim": "归约维度名",
            "reduce_var": "循环变量名",
            "reduce_block": "BLOCK_XX",
            "accumulator": "累加方式",
            "reduction_strategy": "thread_serial|warp_shuffle|shared_block_reduction|multi_kernel",
            "participants": "参与归约的线程集合与 active mask",
            "synchronization": "同步点及其一致到达条件",
            "final_reduction": "最终归约与唯一写回线程"
        },
        // 多遍归约时使用（按需添加），内部字段必须与"reduce_loop"相同：
        // "reduce_loop_pass1": { ... },
        // "reduce_loop_pass2": { ... },
        "compute": {
            "formula": "核心计算公式",
            "note": "计算逻辑说明"
        }
    },
    "wrapper": {
        "grid": "grid计算公式",
        "block": "block计算公式",
        "block_params": {"BLOCK_XX": 默认块大小, ...},
        "shared_bytes": "动态共享内存字节数",
        "stream": "cudaStream_t stream",
        "build_flags": "-std=c++17 -O3 -lineinfo -arch=sm_86"
    }
}
```

⚠️ **字段说明**：

输出必须严格按照以下字段，结合以上JSON代码格式，不得额外添加或删除字段
| 字段 | 必填 | 说明 |
|------|------|------|
| `compute_formula` | ✅ 必填 | 原始计算公式，如 `Y[n,k] = Σ X[n,m,k]` |
| `compute_note` | ✅ 必填 | 从 step1 透传的算子语义，包含 `description` 和 `reference_impl`（独立 CPU C++ 参考实现） |
| `fusion_note` | 可选 | 融合说明，如 "融合: H + W -> HW"，无融合则不填 |
| `kernel.block_params` | ✅ 必填 | BLOCK 参数定义，值为各轴 size 数组（列表形式） |
| `kernel.aux_params` | ✅ 必填 | 辅助计算参数定义（如 block/thread 索引、offset、grid-stride） |
| `kernel.loads` | ✅ 必填 | 各输入指针的 index 和 mask 计算公式 |
| `kernel.stores` | ✅ 必填 | 各输出指针的 index 和 mask 计算公式 |
| `kernel.reduce_loop` | 仅归约时 | **单遍归约**：归约维度循环信息，包含 reduce_dim, reduce_var, reduce_block, accumulator；归约实现策略字段 `reduction_strategy` 必须填写，详见“归约实现策略选择规则”<br/>**多遍归约**：字段名称采用 `kernel.reduce_loop_pass1`, `kernel.reduce_loop_pass2`, ... 分别描述每遍归约的信息<br/>**无归约操作时**：**不包含此字段** |
| `kernel.compute` | ✅ 必填 | 核心计算逻辑，包含 formula 和 note 两个子字段 |
| `wrapper.grid` | ✅ 必填 | CUDA `dim3 grid` 计算公式 |
| `wrapper.block` | ✅ 必填 | CUDA `dim3 block` 配置，默认不超过 256 threads/block，除非有资源依据 |
| `wrapper.block_params` | ✅ 必填 | BLOCK 参数默认值（整数形式） |

**关键规则**：
- **必须遵守** `.claude/skills/share/cuda-c/references/primitives.md` 中的生成阶段原语约束；不得在 spec 中推荐禁止或不受支持的原语。
- 读取 `.claude/skills/share/cuda-c/references/platform-rules.md` 获取 RTX 3090 / `sm_86` 专有约束，不要把硬件事实复制回通用方案流程。
- **aux_params** 只保留公共计算信息，如：
  - `linear = blockIdx.x * blockDim.x + threadIdx.x`
  - `stride = blockDim.x * gridDim.x`
  - `row/col` 的 64 位反解公式
- **index_指针名** 中包含具体线性索引和 stride，每个指针可以有不同逻辑
- **mask_指针名** 用于边界检查，每个指针可以有独立的 mask 计算逻辑
- **多遍归约判断**：当算子的计算公式`compute`中解析到**需要多次遍历归约轴**时，使用多遍归约。此时使用 `reduce_loop_pass1`, `reduce_loop_pass2`, ... 字段替换 `reduce_loop` 字段，分别描述每遍归约的信息
- **归约轴放置原则**：优先由一个 block/warp 负责一个独立输出归约，线程以 grid-stride 方式覆盖归约轴；只有需要 multi-kernel partial 合并时才把归约轴映射到额外 grid，并明确临时缓冲与第二阶段。

**归约实现策略选择规则**：
对每个 `reduce_loop` / `reduce_loop_passN`，必须先判断归约应采用哪种实现策略，并在字段中明确表达。

`reduce_loop` / `reduce_loop_passN` 子字段要求：

| 子字段 | 必填条件 | 说明 |
|--------|----------|------|
| `reduce_dim` | 必填 | 被遍历的归约维度名 |
| `reduce_var` | 必填 | 归约循环变量名 |
| `reduce_block` | 必填 | 归约维度的块大小参数 |
| `accumulator` | 必填 | 循环内累加器更新方式 |
| `reduction_strategy` | 必填 | `thread_serial`、`warp_shuffle`、`shared_block_reduction` 或 `multi_kernel` |
| `participants` | 协作归约时必填 | 参与线程、warp active mask 与有效 lane 规则 |
| `synchronization` | shared/multi-kernel 时必填 | barrier 或 kernel 边界；说明所有线程一致到达条件 |
| `final_reduction` | 必填 | 最终合并公式与唯一写回线程 |

| 策略 | 适用场景 | 生成规范要求 |
|------|----------|--------------|
| `thread_serial` | 归约维度很短或每个输出并行度已足够 | 单线程顺序累加，无 block barrier |
| `warp_shuffle` | 一个 warp 覆盖一个归约，数据可合并读取 | 使用 `__shfl_down_sync(active_mask, ...)`；mask 与参与 lane 必须正确 |
| `shared_block_reduction` | 一个 block 协作长归约 | 每线程寄存器 partial，warp/shared 分层合并；`__syncthreads()` 由所有未退出线程一致到达 |
| `multi_kernel` | 单 block 无法经济覆盖或明确采用 split reduction | 写 partial buffer，再由第二 kernel 合并；不得用跨 block 同步假设 |

**CUDA 归约原语选择**：
- 查看 `.claude/skills/share/cuda-c/references/primitives.md`，优先使用已说明的 warp shuffle、cooperative groups 或 shared-memory 模式。
- mean 使用 sum 后除以 count；max/min 必须使用正确 identity 并按精度合同处理 NaN。
- 不允许依赖未声明的 block 间同步；使用 atomic 时必须说明类型支持、确定性与精度影响。

**默认偏好**：
- 优先采用“每线程寄存器 partial → warp shuffle → 必要时 shared memory 合并”的单 kernel 结构，控制寄存器与共享内存占用。
- `accumulator` 必须明确类型和更新式；FP16/BF16 默认用 FP32 累加，除非需求另有精度合同。
- 除非资源或并行度分析明确支持，不建议生成多 kernel partial reduction；若采用，必须规范临时缓冲、第二次 launch 与错误检查。

**归约循环字段拆分规则**：
根据 `reduce_loop.accumulator` 的复杂程度决定是否需要拆分为多遍归约：

| accumulator 复杂度 | 示例 | 处理方式 |
|-------------------|------|---------|
| **简单累加** | `acc += x`, `acc = acc * x` | 使用单 `reduce_loop` |
| **多步归约** | 归约公式包含多个不同的归约操作（如 `softmax` 需要 `exp`、`sum`、`div`） | 必须拆分，每个独立操作一个 `reduce_loop_passN` |

**拆分原则**：
- 当 `accumulator` 包含多个不同操作（如乘法后再加法、调用函数等），难以在单次循环内完成时，拆分为多遍归约
- 多遍归约时，使用 `reduce_loop_pass1`, `reduce_loop_pass2`, ... 分别描述每遍归约的信息
- 拆分后的每遍归约应该只包含单一类型的归约操作

### 步骤 3：保存结果

将分析结果保存到 `{输出存储路径}/KernelGen/step4_code_spec.json`

## 参考场景

按需加载对应场景的输入输出格式示例：需要参考示例时，从下列场景对应链接读取。

#### 场景1：Reduce Sum

对应示例：[generate_spec_reduce_sum.md](./examples/generate_spec_reduce_sum.md)

#### 场景2：Transpose + Elementwise Add（无融合）

对应示例：[generate_spec_transpose_elementwise.md](./examples/generate_spec_transpose_elementwise.md)

#### 场景3：轴融合后（H+W -> HW）

对应示例：[generate_spec_axis_fusion.md](./examples/generate_spec_axis_fusion.md)

#### 场景4：矩阵转置（Transpose）

对应示例：[generate_spec_matrix_transpose.md](./examples/generate_spec_matrix_transpose.md)

**说明**：
- 当计算公式包含转置操作（如 `X.T[m,n]`）时，需要在 `compute` 字段中指定明确的交换索引公式
- 转置场景下，load 时使用转置前的索引顺序（n 行 m 列）
- 转置场景下的 mask 计算需要注意维度的对应关系

## 核心规则

### Grid 规范

⚠️ **CUDA Grid 最多三维**
- 输出拆分轴超过三维时必须线性化或融合，不得生成四维 launch
- 每个 grid 维度使用 `ceil_div(axis_size, tile_size)`，并检查设备 grid 上限
- 空输入时 host wrapper 必须跳过 launch，避免零维 grid

⚠️ **Grid 顺序必须与 block/thread 反解一致**
- `grid.x/y/z` 分别对应 `blockIdx.x/y/z`；线程局部轴对应 `threadIdx.x/y/z`

### Block 参数规范

- `kernel.block_params`：值为**列表形式**，对应各测试用例的轴大小
- `wrapper.block_params`：值为**整数形式**，推荐使用的默认块大小
- 默认不超过 256 threads/block；只有寄存器、shared memory 与 occupancy 依据充分时才提高

### 融合轴处理

当输入包含融合轴（如 `HW`, `NM`）时：
- block_params 使用融合后的轴名和融合后的维度值
- grid 维度基于融合后的轴数量
- aux_params 使用融合后的变量名（如 `hw_idx`）
- **重要**：在 loads/stores 公式中，融合后的索引使用**原始 stride 的最后一维**

## 验证方式

| 检查项 | 验证方式 | 通过条件 |
|--------|--------|--------|
| Step 3 输出存在 | 检查文件是否存在 | step3_axis_fusion.json 存在且可读 |
| compute_formula 存在 | 解析 JSON 格式 | 包含 compute_formula 字段 |
| compute_note 透传 | 解析 JSON 格式 | 包含 compute_note.description 和 compute_note.reference_impl |
| kernel 规范完整 | 检查 kernel 字段 | 包含 block_params, aux_params, loads, stores |
| loads/stores 结构正确 | 检查 loads/stores 字段 | 每个指针包含 index_指针名 和 mask_指针名 字段 |
| wrapper 规范完整 | 检查 wrapper 字段 | 包含 grid, block, block_params, shared_bytes, stream, build_flags |
| Grid 维度正确 | 检查 grid 公式 | 最多三维，覆盖完整且不产生非法零 grid |

## 回退机制

| 失败场景 | 处理方式 |
|---------|--------|
| Step 3 输出不存在或无效 | 返回错误 |
| 输出 JSON 格式无效 | 内部重试（最多 3 次） |
| kernel 规范缺失关键字段 | 内部重试（最多 3 次） |
| wrapper 规范缺失关键字段 | 内部重试（最多 3 次） |
| Grid 维度与输出轴不匹配 | 内部重试（最多 3 次） |

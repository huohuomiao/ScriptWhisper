# GenerateCode 示例：轴融合后（H+W -> HW）

**输入（step4_code_spec，有融合）：**
```json
{
  "compute_formula": "out[n,h,w,c] = sigmoid(x[n,c,h,w])",
  "fusion_note": "融合: H + W -> HW",
  "kernel": {
    "block_params": {"BLOCK_HW": [32], "BLOCK_C": [4, 8]},
    "aux_params": {
      "hw": "int64(blockIdx.x) * blockDim.x + threadIdx.x",
      "c": "int64(blockIdx.y) * blockDim.y + threadIdx.y",
      "n": "blockIdx.z"
    },
    "loads": {
      "x_ptr": {
        "index_x_ptr": "n * C * HW + c * HW + hw",
        "mask_x_ptr": "n < N && c < C && hw < H * W"
      }
    },
    "stores": {
      "out_ptr": {
        "index_out_ptr": "n * HW * C + hw * C + c",
        "mask_out_ptr": "n < N && hw < H * W && c < C"
      }
    }
  },
  "wrapper": {
    "grid": "dim3(ceil_div(HW, BLOCK_HW), ceil_div(C, BLOCK_C), N)",
    "block": "dim3(BLOCK_HW, BLOCK_C, 1)",
    "block_params": {"BLOCK_HW": 32, "BLOCK_C": 8},
    "shared_bytes": "0",
    "stream": "cudaStream_t stream",
    "build_flags": "-std=c++17 -O3 -lineinfo -arch=sm_86"
  }
}
```

**输出（关键点说明）：**
- 保留融合后的 `HW` 线性索引，不把 launch 重新拆成 H/W 轴。
- `blockIdx.z` 对应 N，Grid 保持 CUDA 支持的三维形式。
- NCHW load 与 NHWC store 直接使用 `hw`，不需要 `% W`/`/ W`。

```cpp
#include <cuda_runtime.h>
#include <cstdint>
#include <cmath>

template <int BLOCK_HW, int BLOCK_C>
__global__ void transpose_sigmoid_4d_kernel(const float* x, float* out,
                                            std::int64_t N, std::int64_t C,
                                            std::int64_t H, std::int64_t W) {
    const std::int64_t HW = H * W;
    const std::int64_t hw = static_cast<std::int64_t>(blockIdx.x) * BLOCK_HW
                            + threadIdx.x;
    const std::int64_t c = static_cast<std::int64_t>(blockIdx.y) * BLOCK_C
                           + threadIdx.y;
    const std::int64_t n = blockIdx.z;
    if (n >= N || c >= C || hw >= HW) return;
    const float v = x[(n * C + c) * HW + hw];
    out[(n * HW + hw) * C + c] = 1.0f / (1.0f + expf(-v));
}

cudaError_t cuda_transpose_sigmoid(const float* x, float* out,
                                   std::int64_t N, std::int64_t C,
                                   std::int64_t H, std::int64_t W,
                                   cudaStream_t stream) {
    if (!x || !out || N < 0 || C < 0 || H < 0 || W < 0)
        return cudaErrorInvalidValue;
    const std::int64_t HW = H * W;
    if (N == 0 || C == 0 || HW == 0) return cudaSuccess;
    constexpr int BLOCK_HW = 32, BLOCK_C = 8;
    dim3 block(BLOCK_HW, BLOCK_C, 1);
    dim3 grid(static_cast<unsigned>((HW + BLOCK_HW - 1) / BLOCK_HW),
              static_cast<unsigned>((C + BLOCK_C - 1) / BLOCK_C),
              static_cast<unsigned>(N));
    transpose_sigmoid_4d_kernel<BLOCK_HW, BLOCK_C><<<grid, block, 0, stream>>>(
        x, out, N, C, H, W);
    return cudaGetLastError();
}
```

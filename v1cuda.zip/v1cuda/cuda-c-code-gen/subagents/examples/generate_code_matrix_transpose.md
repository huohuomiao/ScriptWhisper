# GenerateCode 示例：矩阵转置（Transpose）

**输入（step4_code_spec）：**
```json
{
  "compute_formula": "Y[m,n] = X[n,m]",
  "kernel": {
    "block_params": {"TILE": [32], "BLOCK_ROWS": [8]},
    "aux_params": {
      "m": "blockIdx.x * TILE + threadIdx.x",
      "n": "blockIdx.y * TILE + threadIdx.y",
      "shared": "float tile[TILE][TILE + 1]"
    },
    "loads": {
      "X_ptr": {
        "index_X_ptr": "(n + j) * M + m",
        "mask_X_ptr": "m < M && n + j < N"
      }
    },
    "stores": {
      "Y_ptr": {
        "index_Y_ptr": "(m0 + j) * N + n0",
        "mask_Y_ptr": "n0 < N && m0 + j < M"
      }
    },
    "compute": {
      "formula": "shared-memory tiled transpose",
      "note": "TILE x (TILE+1) padding avoids shared-memory bank conflicts"
    }
  },
  "wrapper": {
    "grid": "dim3(ceil_div(M, TILE), ceil_div(N, TILE), 1)",
    "block": "dim3(TILE, BLOCK_ROWS, 1)",
    "block_params": {"TILE": 32, "BLOCK_ROWS": 8},
    "shared_bytes": "0 (static shared array)",
    "stream": "cudaStream_t stream",
    "build_flags": "-std=c++17 -O3 -lineinfo -arch=sm_86"
  }
}
```

**输出：**
```cpp
#include <cuda_runtime.h>
#include <cstdint>

template <int TILE, int BLOCK_ROWS>
__global__ void transpose_kernel(const float* X, float* Y,
                                 std::int64_t N, std::int64_t M) {
    __shared__ float tile[TILE][TILE + 1];
    const std::int64_t m = static_cast<std::int64_t>(blockIdx.x) * TILE
                           + threadIdx.x;
    const std::int64_t n = static_cast<std::int64_t>(blockIdx.y) * TILE
                           + threadIdx.y;
    for (int j = 0; j < TILE; j += BLOCK_ROWS)
        if (m < M && n + j < N)
            tile[threadIdx.y + j][threadIdx.x] = X[(n + j) * M + m];
    __syncthreads();

    const std::int64_t n0 = static_cast<std::int64_t>(blockIdx.y) * TILE
                            + threadIdx.x;
    const std::int64_t m0 = static_cast<std::int64_t>(blockIdx.x) * TILE
                            + threadIdx.y;
    for (int j = 0; j < TILE; j += BLOCK_ROWS)
        if (n0 < N && m0 + j < M)
            Y[(m0 + j) * N + n0] = tile[threadIdx.x][threadIdx.y + j];
}

cudaError_t cuda_transpose(const float* X, float* Y,
                           std::int64_t N, std::int64_t M,
                           cudaStream_t stream) {
    if (!X || !Y || N < 0 || M < 0) return cudaErrorInvalidValue;
    if (N == 0 || M == 0) return cudaSuccess;
    constexpr int TILE = 32, BLOCK_ROWS = 8;
    dim3 block(TILE, BLOCK_ROWS, 1);
    dim3 grid(static_cast<unsigned>((M + TILE - 1) / TILE),
              static_cast<unsigned>((N + TILE - 1) / TILE), 1);
    transpose_kernel<TILE, BLOCK_ROWS><<<grid, block, 0, stream>>>(X, Y, N, M);
    return cudaGetLastError();
}
```

**说明**：
- load 与 store 都按 warp 连续地址访问；shared tile 实现转置。
- `TILE + 1` padding 减少 shared-memory bank conflict。
- `__syncthreads()` 位于所有线程一致到达的无条件路径。

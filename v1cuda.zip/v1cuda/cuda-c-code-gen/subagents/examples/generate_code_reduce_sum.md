# GenerateCode 示例：Reduce Sum（归约操作）

**输入（step4_code_spec）：**
```json
{
  "compute_formula": "Y[n,k] = Σ X[n,m,k]",
  "compute_note": {
    "description": "对 X 沿 M 求和得到 Y(N,K)",
    "reference_impl": "CPU C++ 三重循环，double 累加"
  },
  "kernel": {
    "block_params": {"BLOCK_K": [128, 256]},
    "aux_params": {
      "n": "blockIdx.y",
      "k": "int64(blockIdx.x) * blockDim.x + threadIdx.x"
    },
    "loads": {
      "X_ptr": {
        "index_X_ptr": "n * stride_x0 + m * stride_x1 + k * stride_x2",
        "mask_X_ptr": "n < N && m < M && k < K"
      }
    },
    "stores": {
      "Y_ptr": {
        "index_Y_ptr": "n * stride_y0 + k * stride_y1",
        "mask_Y_ptr": "n < N && k < K"
      }
    },
    "reduce_loop": {
      "reduce_dim": "M",
      "reduce_var": "m",
      "reduce_block": "1",
      "accumulator": "float acc += float(X[index])",
      "reduction_strategy": "thread_serial",
      "final_reduction": "当前线程写回唯一 Y[n,k]"
    }
  },
  "wrapper": {
    "grid": "dim3(ceil_div(K, BLOCK_K), N, 1)",
    "block": "dim3(BLOCK_K, 1, 1)",
    "block_params": {"BLOCK_K": 256},
    "shared_bytes": "0",
    "stream": "cudaStream_t stream",
    "build_flags": "-std=c++17 -O3 -lineinfo -arch=sm_86"
  }
}
```

**输出：**
```cpp
#include <cuda_runtime.h>
#include <cstdint>

template <int BLOCK_K>
__global__ void reduce_sum_kernel(const float* X, float* Y,
                                  std::int64_t stride_x0,
                                  std::int64_t stride_x1,
                                  std::int64_t stride_x2,
                                  std::int64_t stride_y0,
                                  std::int64_t stride_y1,
                                  std::int64_t N, std::int64_t M,
                                  std::int64_t K) {
    const std::int64_t n = blockIdx.y;
    const std::int64_t k = static_cast<std::int64_t>(blockIdx.x) * BLOCK_K
                           + threadIdx.x;
    if (n >= N || k >= K) return;
    float acc = 0.0f;
    for (std::int64_t m = 0; m < M; ++m)
        acc += X[n * stride_x0 + m * stride_x1 + k * stride_x2];
    Y[n * stride_y0 + k * stride_y1] = acc;
}

cudaError_t cuda_reduce_sum(const float* X, float* Y,
                            std::int64_t sx0, std::int64_t sx1, std::int64_t sx2,
                            std::int64_t sy0, std::int64_t sy1,
                            std::int64_t N, std::int64_t M, std::int64_t K,
                            cudaStream_t stream) {
    if (!X || !Y || N < 0 || M < 0 || K < 0) return cudaErrorInvalidValue;
    if (N == 0 || K == 0) return cudaSuccess;
    constexpr int BLOCK_K = 256;
    dim3 grid(static_cast<unsigned>((K + BLOCK_K - 1) / BLOCK_K),
              static_cast<unsigned>(N), 1);
    reduce_sum_kernel<BLOCK_K><<<grid, BLOCK_K, 0, stream>>>(
        X, Y, sx0, sx1, sx2, sy0, sy1, N, M, K);
    return cudaGetLastError();
}
```

**说明**：
- 连续 K 由相邻线程处理，形成合并读取和写回。
- M 在每个线程内顺序累加；更复杂的单输出长归约应按 spec 选择 warp/shared reduction。
- FP16/BF16 输入默认以 FP32 累加。

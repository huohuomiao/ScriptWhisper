# GenerateCode 示例：Transpose + Elementwise（无融合）

**输入（step4_code_spec）：**
```json
{
  "compute_formula": "out[h,n,w] = exp(x[n,h,w])",
  "kernel": {
    "block_params": {"BLOCK_SIZE": [128, 256]},
    "aux_params": {
      "linear": "int64(blockIdx.x) * blockDim.x + threadIdx.x",
      "stride": "int64(blockDim.x) * gridDim.x"
    },
    "loads": {
      "x_ptr": {
        "index_x_ptr": "n * H * W + h * W + w",
        "mask_x_ptr": "linear < N * H * W"
      }
    },
    "stores": {
      "out_ptr": {
        "index_out_ptr": "h * N * W + n * W + w",
        "mask_out_ptr": "linear < N * H * W"
      }
    }
  },
  "wrapper": {
    "grid": "dim3(ceil_div(N * H * W, BLOCK_SIZE), 1, 1)",
    "block": "dim3(BLOCK_SIZE, 1, 1)",
    "block_params": {"BLOCK_SIZE": 256},
    "shared_bytes": "0",
    "stream": "cudaStream_t stream",
    "build_flags": "-std=c++17 -O3 -lineinfo -arch=sm_86"
  }
}
```

**输出：**
```cpp
#include <cuda_runtime.h>
#include <cstdint>
#include <cmath>

template <int BLOCK_SIZE>
__global__ void transpose_exp_3d_kernel(const float* x, float* out,
                                        std::int64_t N, std::int64_t H,
                                        std::int64_t W) {
    const std::int64_t total = N * H * W;
    const std::int64_t step = static_cast<std::int64_t>(blockDim.x) * gridDim.x;
    for (std::int64_t linear = static_cast<std::int64_t>(blockIdx.x) * blockDim.x
                               + threadIdx.x;
         linear < total; linear += step) {
        const std::int64_t w = linear % W;
        const std::int64_t q = linear / W;
        const std::int64_t h = q % H;
        const std::int64_t n = q / H;
        out[(h * N + n) * W + w] = expf(x[linear]);
    }
}

cudaError_t cuda_transpose_exp(const float* x, float* out,
                               std::int64_t N, std::int64_t H,
                               std::int64_t W, cudaStream_t stream) {
    if (!x || !out || N < 0 || H < 0 || W < 0) return cudaErrorInvalidValue;
    const std::int64_t total = N * H * W;
    if (total == 0) return cudaSuccess;
    constexpr int BLOCK_SIZE = 256;
    const unsigned grid = static_cast<unsigned>((total + BLOCK_SIZE - 1) / BLOCK_SIZE);
    transpose_exp_3d_kernel<BLOCK_SIZE><<<grid, BLOCK_SIZE, 0, stream>>>(x, out, N, H, W);
    return cudaGetLastError();
}
```

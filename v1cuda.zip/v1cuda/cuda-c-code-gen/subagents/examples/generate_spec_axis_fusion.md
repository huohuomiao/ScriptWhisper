## 场景：轴融合后（H+W -> HW）

**输入（上一步结果）：**
```json
{
  "compute_formula": "out[n,h,w,c] = exp(x[n,c,h,w])",
  "compute_note": {
    "description": "NCHW 输入逐元素取指数并写为 NHWC",
    "reference_impl": "CPU C++ 四重循环执行布局转换与 exp"
  },
  "fusion_note": "融合: H + W -> HW",
  "io_block_mapping": {
    "x_ptr": {"block_name": {"N": "BLOCK_N", "C": "BLOCK_C", "HW": "BLOCK_HW"}, "axis_size": {"N": [3, 7], "C": [5, 9], "HW": [595, 2211]}, "contiguity": [true, true, true]},
    "out_ptr": {"block_name": {"N": "BLOCK_N", "HW": "BLOCK_HW", "C": "BLOCK_C"}, "axis_size": {"N": [3, 7], "HW": [595, 2211], "C": [5, 9]}, "contiguity": [true, true, true]}
  }
}
```

**输出（融合后的规范）：**
```json
{
  "compute_formula": "out[n,h,w,c] = exp(x[n,c,h,w])",
  "compute_note": {
    "description": "NCHW 输入逐元素取指数并写为 NHWC",
    "reference_impl": "CPU C++ 四重循环执行布局转换与 exp"
  },
  "fusion_note": "融合: H + W -> HW",
  "kernel": {
    "block_params": {"BLOCK_HW": [32], "BLOCK_C": [4, 8]},
    "aux_params": {
      "hw": "int64(blockIdx.x) * blockDim.x + threadIdx.x",
      "c": "int64(blockIdx.y) * blockDim.y + threadIdx.y",
      "n": "blockIdx.z"
    },
    "loads": {
      "x_ptr": {"index_x_ptr": "n * C * HW + c * HW + hw", "mask_x_ptr": "n < N && c < C && hw < HW"}
    },
    "stores": {
      "out_ptr": {"index_out_ptr": "n * HW * C + hw * C + c", "mask_out_ptr": "n < N && hw < HW && c < C"}
    },
    "compute": {"formula": "out = expf(x)", "note": "HW 保持线性，不为 launch 重新拆分 H/W"}
  },
  "wrapper": {
    "grid": "dim3(ceil_div(HW, BLOCK_HW), ceil_div(C, BLOCK_C), N)",
    "block": "dim3(BLOCK_HW, BLOCK_C, 1)",
    "block_params": {"BLOCK_HW": 32, "BLOCK_C": 8},
    "shared_bytes": "0",
    "stream": "cudaStream_t stream",
    "build_flags": "-std=c++17 -O3 -lineinfo -arch=sm_86"
  }
}
```

**说明**：
- X 的融合 stride 为 `[C*HW, HW, 1]`；out 为 `[HW*C, C, 1]`。
- Grid 使用 x/y/z 三维，对应 HW/C/N；host 对零维输入跳过 launch。

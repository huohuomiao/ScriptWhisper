## 场景：矩阵转置（Transpose）

**输入（上一步结果）：**
```json
{
  "compute_formula": "Y[m,n] = X[n,m]",
  "compute_note": {
    "description": "转置 row-major X(N,M) 得到 Y(M,N)",
    "reference_impl": "CPU C++ 双重循环执行 Y[m*N+n] = X[n*M+m]"
  },
  "io_block_mapping": {
    "X_ptr": {"block_name": {"M": "TILE", "N": "TILE"}, "axis_size": {"M": [128], "N": [64]}, "contiguity": [true, true], "transpose": true},
    "Y_ptr": {"block_name": {"M": "TILE", "N": "TILE"}, "axis_size": {"M": [128], "N": [64]}, "contiguity": [true, true]}
  }
}
```

**输出：**
```json
{
  "compute_formula": "Y[m,n] = X[n,m]",
  "compute_note": {
    "description": "转置 row-major X(N,M) 得到 Y(M,N)",
    "reference_impl": "CPU C++ 双重循环执行 Y[m*N+n] = X[n*M+m]"
  },
  "kernel": {
    "block_params": {"TILE": [32], "BLOCK_ROWS": [8]},
    "aux_params": {
      "m": "blockIdx.x * TILE + threadIdx.x",
      "n": "blockIdx.y * TILE + threadIdx.y",
      "shared": "float tile[TILE][TILE + 1]"
    },
    "loads": {
      "X_ptr": {"index_X_ptr": "(n+j) * M + m", "mask_X_ptr": "m < M && n+j < N"}
    },
    "stores": {
      "Y_ptr": {"index_Y_ptr": "(m0+j) * N + n0", "mask_Y_ptr": "n0 < N && m0+j < M"}
    },
    "compute": {
      "formula": "shared tile transpose",
      "note": "TILE x (TILE+1) padding，barrier 由所有线程一致到达"
    }
  },
  "wrapper": {
    "grid": "dim3(ceil_div(M, TILE), ceil_div(N, TILE), 1)",
    "block": "dim3(TILE, BLOCK_ROWS, 1)",
    "block_params": {"TILE": 32, "BLOCK_ROWS": 8},
    "shared_bytes": "0 (static shared array)",
    "stream": "cudaStream_t stream",
    "build_flags": "-std=c++17 -O3 -lineinfo -arch=sm_86"
  }
}
```

**说明**：
- load 使用 X 的 row-major 连续方向；store 交换 block 起点后保持 Y 连续写。
- `TILE + 1` padding 避免典型 shared-memory bank conflict。
- 每次 load/store 都有独立 tail predicate。

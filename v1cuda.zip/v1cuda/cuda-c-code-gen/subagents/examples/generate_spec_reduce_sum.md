## 场景：Reduce Sum

**输入（上一步结果）：**
```json
{
  "compute_formula": "Y[n,k] = Σ X[n,m,k]",
  "compute_note": {
    "description": "沿 M 维求和得到 Y(N,K)",
    "reference_impl": "CPU C++ 三重循环，double 累加"
  },
  "io_block_mapping": {
    "X_ptr": {"block_name": {"N": "BLOCK_N", "K": "BLOCK_K"}, "axis_size": {"N": [16], "K": [128]}, "reduce_dim": "M", "contiguity": [true, false, true]},
    "Y_ptr": {"block_name": {"N": "BLOCK_N", "K": "BLOCK_K"}, "axis_size": {"N": [16], "K": [128]}, "contiguity": [true, true]}
  }
}
```

**输出：**
```json
{
  "compute_formula": "Y[n,k] = Σ X[n,m,k]",
  "compute_note": {
    "description": "沿 M 维求和得到 Y(N,K)",
    "reference_impl": "CPU C++ 三重循环，double 累加"
  },
  "kernel": {
    "block_params": {"BLOCK_K": [128, 256]},
    "aux_params": {
      "n": "blockIdx.y",
      "k": "int64(blockIdx.x) * blockDim.x + threadIdx.x"
    },
    "loads": {
      "X_ptr": {"index_X_ptr": "n * stride_x0 + m * stride_x1 + k * stride_x2", "mask_X_ptr": "n < N && m < M && k < K"}
    },
    "stores": {
      "Y_ptr": {"index_Y_ptr": "n * stride_y0 + k * stride_y1", "mask_Y_ptr": "n < N && k < K"}
    },
    "reduce_loop": {
      "reduce_dim": "M",
      "reduce_var": "m",
      "reduce_block": "1",
      "accumulator": "float acc += float(X[index])",
      "reduction_strategy": "thread_serial",
      "final_reduction": "当前线程写唯一 Y[n,k]"
    },
    "compute": {"formula": "acc += x", "note": "连续 K 映射到相邻线程；M 在线程内循环"}
  },
  "wrapper": {
    "grid": "dim3(ceil_div(K, BLOCK_K), N, 1)",
    "block": "dim3(BLOCK_K, 1, 1)",
    "block_params": {"BLOCK_K": 256},
    "shared_bytes": "0",
    "stream": "cudaStream_t stream",
    "build_flags": "-std=c++17 -O3 -lineinfo -arch=sm_86"
  }
}
```

**说明**：
- `k` 使用 64 位索引，边界 predicate 覆盖非整 block。
- 更长且单输出的归约按共享原语文档改用 warp/shared block reduction。

## 场景：Transpose + Elementwise Add（无融合）

**输入（上一步结果）：**
```json
{
  "compute_formula": "C[n,m] = A[m,n] + B[n,m]",
  "compute_note": {
    "description": "转置 A 后与 B 逐元素相加",
    "reference_impl": "CPU C++ 双重循环执行 C[n,m] = A[m,n] + B[n,m]"
  },
  "io_block_mapping": {
    "A_ptr": {"block_name": {"M": "BLOCK_M", "N": "BLOCK_N"}, "axis_size": {"M": [128], "N": [64]}, "contiguity": [true, true]},
    "B_ptr": {"block_name": {"N": "BLOCK_N", "M": "BLOCK_M"}, "axis_size": {"N": [64], "M": [128]}, "contiguity": [true, true]},
    "C_ptr": {"block_name": {"N": "BLOCK_N", "M": "BLOCK_M"}, "axis_size": {"N": [64], "M": [128]}, "contiguity": [true, true]}
  }
}
```

**输出：**
```json
{
  "compute_formula": "C[n,m] = A[m,n] + B[n,m]",
  "compute_note": {
    "description": "转置 A 后与 B 逐元素相加",
    "reference_impl": "CPU C++ 双重循环执行 C[n,m] = A[m,n] + B[n,m]"
  },
  "kernel": {
    "block_params": {"BLOCK_M": [32], "BLOCK_N": [8]},
    "aux_params": {
      "m": "int64(blockIdx.x) * blockDim.x + threadIdx.x",
      "n": "int64(blockIdx.y) * blockDim.y + threadIdx.y"
    },
    "loads": {
      "A_ptr": {"index_A_ptr": "m * stride_a0 + n * stride_a1", "mask_A_ptr": "m < M && n < N"},
      "B_ptr": {"index_B_ptr": "n * stride_b0 + m * stride_b1", "mask_B_ptr": "n < N && m < M"}
    },
    "stores": {
      "C_ptr": {"index_C_ptr": "n * stride_c0 + m * stride_c1", "mask_C_ptr": "n < N && m < M"}
    },
    "compute": {"formula": "c = a + b", "note": "每个线程负责唯一 C[n,m]"}
  },
  "wrapper": {
    "grid": "dim3(ceil_div(M, BLOCK_M), ceil_div(N, BLOCK_N), 1)",
    "block": "dim3(BLOCK_M, BLOCK_N, 1)",
    "block_params": {"BLOCK_M": 32, "BLOCK_N": 8},
    "shared_bytes": "0",
    "stream": "cudaStream_t stream",
    "build_flags": "-std=c++17 -O3 -lineinfo -arch=sm_86"
  }
}
```

# DynamicFixer

## 职责概述

DynamicFixer 负责对经过静态检查后的 CUDA C/C++ kernel 代码进行**动态修复**，即基于真实 `nvcc`、CUDA Runtime、CPU reference 与 Compute Sanitizer 反馈，按错误分类迭代修改代码，直至所有门禁通过或达到终止条件。与 StaticReviewer 不同，DynamicFixer **会实际编译和运行代码**，并以执行结果驱动修复。

## 输入

| 参数 | 说明 |
|------|------|
| `fixed_code_path` | 经过 StaticReviewer 静态检查后产出的 CUDA C/C++ 文件路径（如 `/path/to/xxx_fix.cu`），同时包含 kernel、launcher、CPU reference、测试与 CUDA Event 计时 |

**说明**：
- 输入文件即为**修复目标文件**——后续所有迭代都**直接覆盖该文件**，不再产生编号后缀。
- 不需要额外传入输出目录：迭代日志追加到与 `xxx_fix.cu` 同目录、同前缀的 `xxx_fix.md`。
- 仅接收单个 `.cu` 文件路径，不接收代码片段字符串。

## 输出

输出统一写到输入文件同目录；沿用 StaticReviewer 已生成的文件，不新建其他输出文件。假设输入为 `xxx_fix.cu`：

| 文件 | 说明 |
|------|------|
| `{同目录}/xxx_fix.cu` | 动态修复后的最终 CUDA C/C++ 文件（直接覆盖输入文件） |
| `{同目录}/xxx_fix.md` | 在 StaticReviewer 已有内容基础上，**追加**动态修复迭代记录与最终结论 |

**信息传递原则**：所有结果通过上述文件传递，**不向调用方返回摘要字符串**，避免主流程上下文污染。

## 红线（修复时严禁的做法）

在任何迭代中，**禁止**出现以下"替代式修复"——它们会让测试通过但背离 CUDA C 算子开发目标：

1. ❌ 将 CUDA kernel 改为 CPU 实现或直接返回 CPU reference
2. ❌ 用 PyTorch、cuBLAS、cuDNN、Thrust 等替代要求开发的自定义 kernel
3. ❌ 删除测试、缩小 Shape、放宽精度阈值或修改 reference 来迎合结果

一旦迭代中出现上述迹象，必须立刻回退该轮修改，改走其他修复思路。

## 执行契约

本子代理必须遵守 `cuda-c-main` 的 EnvConfig 环境选择结果，**本地 Linux 环境具备目标 RTX 3090 与 `nvcc` 时优先本地执行**。禁止无条件提交 Worker Task，也不得把其他 GPU 的诊断结果写成目标验证。

### 执行后端选择

执行 `xxx_fix.cu` 前，先确认当前工作流的 EnvConfig 产物：

- 优先读取 `{output_dir}/EnvConfig/config.md` 中的 `execution_backend`
- `output_dir` 可由 `fixed_code_path` 所在目录向上推断：通常 `xxx_fix.cu` 位于 `{output_dir}/KernelGen/` 下
- 若 EnvConfig 产物缺失或无法判断后端，必须先回到 `cuda-c-main` 的 EnvConfig 规则完成环境确认：顺序执行 `share/cuda-c/runtime/get_device_info.py`、`test_env_code.py`，本地不满足时再用 Worker 执行同一套检查

后端判定：
- `execution_backend=local`：直接在本地执行环境执行代码
- `execution_backend=worker`：通过 `submit_task_to_worker.py` 提交 Worker Task
- 未知或环境检查失败：记录环境错误并终止，**不要修改 kernel 代码**

### 本地执行方式

当 `execution_backend=local` 时，直接在 `fixed_code_path` 所在目录执行：

源码目录只作为命令工作目录；二进制与中间产物仍写入临时构建目录。

```bash
nvcc -std=c++17 -O3 -DNDEBUG -lineinfo -arch=sm_86 -Xptxas=-v \
  <fixed_code_path> -o <temporary_binary>
timeout --signal=TERM --kill-after=5s 120s <temporary_binary>
```

**结果分类**（以本地执行命令退出码为准）：
- `0` → 执行成功 → 按步骤 1 继续判定精度
- 该退出码只代表当前命令成功，仍须检查 CUDA API、CPU reference、CUDA Event 和 sanitizer 门禁。
- 非 `0` → 根据 `nvcc`、stderr、CUDA error、精度输出或 timeout 分类后进入迭代修复
- 环境不可用类错误（如 `nvcc`/驱动/目标设备缺失）→ **不要修改 kernel 代码**，在 `xxx_fix.md` 中记录 `blocked=true` 并终止

### Worker 执行方式

仅当 `execution_backend=worker`，或 EnvConfig 已确认本地没有目标 CUDA 环境而 Worker 可用时，才通过 `submit_task_to_worker.py` 提交 Worker Task。每次调用必须前台同步执行，等待脚本退出后再判断结果；禁止 `&` 后台、禁止并发提交多个 Worker Task：

```bash
python3 .claude/skills/cuda-c-main/subagents/scripts/submit_task_to_worker.py \
    --workdir <绝对路径> \
    --command "<同一本地 nvcc/执行/sanitizer 命令>" \
    --timeout-sec 1800 \
    --task-type accuracy
```

**结果分类**（以 `submit_task_to_worker.py` 退出码为准）：
- `0` → 本次命令成功，继续下一门禁
- `1` → 代码、编译、运行或精度错误，进入迭代修复
- `2` → 基础设施错误（`<code_path>` 不存在 / Worker 不可达等）→ **不要修改 kernel 代码**，在 `xxx_fix.md` 中记录环境错误并终止

无论本地执行还是 Worker 执行，都必须把实际命令、执行后端、退出码、stdout/stderr 关键信息追加到 `xxx_fix.md`；后续修复只能基于真实执行结果，不得臆测。

## 执行流程

### 步骤 1：执行静态修复后的代码

按上文"执行契约"选择本地执行环境或 Worker，对 `xxx_fix.cu` 执行固定门禁：`nvcc(sm_86)` → 二进制/CUDA Runtime → 独立 CPU reference 精度 → CUDA Event 计时 → `compute-sanitizer` 的 memcheck、initcheck、racecheck、synccheck。测试 harness 必须以非零退出码表示误差失败，并输出同一 stream 上 CUDA Event 在 warmup 后重复测量的 kernel 时间。

```bash
timeout --signal=TERM --kill-after=5s 600s compute-sanitizer --tool memcheck --leak-check full --error-exitcode 99 <temporary_binary>
timeout --signal=TERM --kill-after=5s 600s compute-sanitizer --tool initcheck --error-exitcode 99 <temporary_binary>
timeout --signal=TERM --kill-after=5s 600s compute-sanitizer --tool racecheck --error-exitcode 99 <temporary_binary>
timeout --signal=TERM --kill-after=5s 600s compute-sanitizer --tool synccheck --error-exitcode 99 <temporary_binary>
```

四项工具作用不同，任一项通过不能代替其他项；缺少必需工具时结果为环境阻塞，不得写成通过。Sanitizer 下的时长不能作为性能数据。

- **通过**（所有门禁成功且精度达标）→ 在 `xxx_fix.md` 末尾追加完整执行摘要，结束流程
- **业务错误**（编译、CUDA API、sanitizer 或精度不达标）→ 进入步骤 2
- **环境错误**（`xxx_fix.cu` 不存在、`nvcc`/sanitizer/目标 GPU 或 Worker 不可用）→ 记录环境错误，不修改代码，终止流程

### 步骤 2：动态检查与迭代修复

基于最早失败门禁的真实输出分析根因，按以下策略修改 `xxx_fix.cu`。
#### 2.1 错误分类与修复索引

通用错误查阅 `.claude/skills/cuda-c-code-review/ref/troubleshooting.md`；CUDA 专属错误同时查阅 `.claude/skills/share/cuda-c/references/platform-rules.md`、原语清单和 device math 文档：

| 错误类型 | 典型特征 | 详细方案 |
|---------|--------|---------|
| **Launch/资源错误** | `invalid configuration`、`too many resources requested` | `share/cuda-c/references/platform-rules.md` 的 grid/block/资源规则 |
| **寄存器/shared memory** | PTXAS spill、shared memory 超限、低 occupancy | 平台规则；只在根因明确时减小 tile/staging |
| **精度问题** | `allclose=False`、`max_diff` 超阈值、NaN/Inf | 通用 troubleshooting 的精度章节 |
| **编译错误** | `nvcc`/PTXAS 第一条根错误、未知原语 | 通用 troubleshooting + `share/cuda-c/references/primitives.md` |
| **设备/平台错误** | driver/toolkit/GPU 不可用 | 平台规则；环境错误不得修 kernel |
| **Kernel 接口错误** | launch 参数个数/顺序/类型不匹配 | 通用 troubleshooting 的接口章节 |
| **数据类型错误** | overload、atomic、half/BF16 不支持 | 通用 troubleshooting + 共享原语清单 |
| **device math 错误** | 标准函数/快速 intrinsic 精度或签名相关 | `share/cuda-c/references/libdevice.md` |
| **内存越界** | `illegal memory access`、`out of bounds` | 通用 troubleshooting 的访存章节 |
| **同步/竞争** | racecheck、synccheck、hang/timeout | 通用 troubleshooting + CUDA 同步原语 |

#### 2.2 修复原则

1. **明确根因再改**：每轮修改前，先在 `xxx_fix.md` 中记录"本轮错误类型 + 根因推断 + 拟采用的修复策略"
2. **最小改动**：保持测试代码、Kernel 签名等对外接口稳定
3. **遵守红线**：严禁 CPU/框架/库算子替代，严禁削弱 reference、Shape 或容差
4. **同轮多错**：优先修编译/接口类错误 → 越界 → 精度
   - 未初始化与竞争/同步错误在精度修复之前处理，并以 sanitizer 证据为准。
5. **保持 kernel 接口和 launch 不变**：尽可能保持 Kernel 输入输出签名、grid/block 和 stream 语义；确需调整时先记录原因
6. **保留块并行语义**：边界修复不得漏算，普通 grid 不能仅裁剪到 SM 数；persistent 设计必须具有完整 grid-stride loop
7. **保留可回退版本**：每轮修改前在内存中保存上一候选；失败加重、新增 sanitizer 问题或未验证假设时立即恢复
#### 2.3 迭代流程

1. 基于上一轮错误，修改 `xxx_fix.cu`（直接覆盖同一文件，不再新增编号文件）
2. 在 `xxx_fix.md` 追加一条迭代记录：`{迭代号, 错误摘要, 修复策略, 本轮执行结果}`
3. 先重跑最早受影响门禁，通过后再跑完整门禁；使用同一个执行后端，迭代中不得擅自切换本地/Worker
4. **终止条件**（满足任一）：
   - 执行通过且精度达标 → 在 `xxx_fix.md` 末尾写"迭代成功" → 结束
     - 这里的“执行通过”要求编译、CUDA Runtime、CPU reference、CUDA Event 和四项 sanitizer 全部通过。
   - 连续 2 次迭代出现完全相同的错误 → 在 `xxx_fix.md` 标记"无法收敛 + 根因分析" → 结束
   - 达到最大迭代次数（默认 5 次）仍未通过 → 在 `xxx_fix.md` 标记"未收敛 + 最后一轮错误快照" → 结束

### 流程总览

```
输入 xxx_fix.cu（已经过静态检查）
  ↓
[步骤1] nvcc → 执行/CPU reference → Compute Sanitizer
  ├─ 通过 → 补记执行摘要，结束
  ├─ 环境错误（退出码 2） → 记录并终止，不改代码
  └─ 失败 ↓
[步骤2] 动态修复（按错误分类改写 xxx_fix.cu，失败回退，追加 xxx_fix.md）
  ↓
  循环 [步骤1 ↔ 步骤2]，直到通过 / 同类错误连续 2 次 / 达到最大迭代 5 次
```

## 修复总结（xxx_fix.md 追加部分）

在 StaticReviewer 已写入的内容之后，**追加**动态修复相关记录。结构建议：

```markdown
## 动态修复迭代

### 首轮执行 xxx_fix.cu
- 执行命令、退出码、stdout/stderr 关键信息
- 同时记录编译、sanitizer 与 PTXAS 资源证据。

### 迭代 1
- 错误类型：...
- 根因推断：...
- 修复策略：...
- 执行结果：...

### 迭代 N
...

## 最终精度/性能
- 精度指标（max_diff、allclose 等）
- 性能指标（若测试代码有输出）
- 精度来自独立 CPU reference；性能输出必须包含 CUDA Event、warmup、重复次数和 kernel 时间。

## 结论
- 成功：简要说明最终通过的原因
- 失败：根因分析与后续建议

passed: true|false
blocked: true|false
target_verified: true|false
final_code_path: <absolute path>
```

仅当目标探针确认 Linux RTX 3090/CC 8.6、全部动态门禁通过且最终候选仍执行自定义 CUDA kernel 时，才能同时设置 `passed=true`、`blocked=false`、`target_verified=true`。

## 检查原则

- **根因优先**：每轮必须先分析 `nvcc`/stderr、CUDA error、sanitizer 或精度数值，再决定修复策略；切忌"盲改"。
- **可回退**：无论是否成功收敛，都必须让 `xxx_fix.cu` 和报告对应同一候选；失败尝试不得覆盖最后一个更好的候选。
- **红线不可碰**：严禁通过 CPU、框架或库算子替代方式绕过 CUDA kernel 语义。

## 验证方式

| 检查项 | 验证方式 | 通过条件 |
|--------|--------|--------|
| 执行后端选择 | 读取 `EnvConfig/config.md` 的 `execution_backend` | local 时本地执行，worker 时提交 Worker |
| 本地执行驱动 | `execution_backend=local` 时运行 `nvcc`、二进制和 sanitizer | 能拿到每项退出码与 stdout/stderr |
| Worker 执行驱动 | `execution_backend=worker` 时通过 `submit_task_to_worker.py` 同步执行同一组命令 | 能拿到退出码（`0`/`1`/`2`）与日志 |
| 正确性与安全 | CPU reference + memcheck/initcheck/racecheck/synccheck | 所有固定用例和工具均通过 |
| 迭代收敛 | 按错误分类迭代修改 `xxx_fix.cu` | 达到终止条件之一，失败修改已回退 |
| 产物生成 | 最终 `xxx_fix.cu` 与 `xxx_fix.md` 在同目录 | 两个文件均已更新且内容一致 |

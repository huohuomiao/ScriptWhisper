---
name: cuda-c-code-review
description: CUDA C 算子代码验证工具，负责静态审查、编译执行和有界修复，直到获得正确的精度与安全性证据
---

# cuda-c-code-review

## 概述

该 SKILL 是 NVIDIA CUDA C/C++ Kernel 代码验证修复工具，对输入的 `.cu` 文件（同时包含 kernel、launcher 与测试代码）依次进行**静态审查 → 动态执行 → 有界修复**，直至得到可在 Linux RTX 3090（Ampere，`sm_86`）上正确执行且精度达标的代码。

**核心目标**：让输入的 CUDA C kernel 在 RTX 3090 上通过编译、CUDA Runtime、CPU reference、Compute Sanitizer 与精度验证。

**工作原则**：
- **静态先行**：先检查明确的接口、索引、边界和同步错误，避免启动存在确定死锁风险的 kernel
- **文件传递信息**：所有中间产物和总结通过文件输出，**不返回摘要字符串到上下文**
- **统一输入输出契约**：输入为 `.cu` 文件路径，输出固定为同目录下的 `xxx_fix.cu` + `xxx_fix.md`
- **运行环境选择规则**：动态执行必须遵守 `.claude/skills/cuda-c-main/SKILL.md`；只有 EnvConfig 确认 Linux、`nvcc` 和 RTX 3090/CC 8.6 后才能声称目标环境通过，本地不可用时才在当前 `JOB_ID` 下同步提交 Worker Task

## 用法

```bash
/cuda-c-code-review <input_code_path>
```

**参数说明**：

| 参数 | 说明 |
|------|------|
| `input_code_path` | 用户指定的完整 CUDA C/C++ 文件路径（如 `/path/to/xxx.cu`），必须同时包含 `__global__` kernel、launcher、CPU reference、可运行测试和 CUDA Event 计时 |

**仅接收文件路径**，不接收代码片段字符串；输出目录由输入路径自动推导，无需用户指定。

## 输出

所有输出统一写入**输入文件所在目录**。假设输入为 `xxx.cu`：

| 文件 | 说明 |
|------|------|
| `{同目录}/xxx_fix.cu` | 最终 CUDA C/C++ 文件；若无需修复，则为原代码的原样拷贝 |
| `{同目录}/xxx_fix.md` | 修复总结（执行记录、静态/动态检查发现、每轮改动） |

## 红线（修复时严禁的做法）

在任何修复迭代中，**禁止**出现以下"替代式修复"——它们会让测试通过但背离 CUDA C 算子开发目标：

1. ❌ 将 CUDA kernel 改为 CPU 实现，或直接返回 CPU reference
2. ❌ 用 PyTorch、cuBLAS、cuDNN、Thrust 等库算子替代要求开发的自定义 kernel
3. ❌ 删除测试、缩小 Shape、放宽 `atol/rtol`，或修改 reference 来迎合错误结果
4. ❌ 用包围异步 launch 的 CPU 时钟代替 CUDA Event kernel 计时

一旦迭代中出现上述迹象，必须立刻回退该轮修改，改走其他修复思路。

## 工作流程

> 总体思想：**静态先行，真实执行，迭代修复**。
### 步骤 1：确认环境并静态审查

**执行契约**：首轮执行必须先确认当前工作流的 EnvConfig 产物，不允许直接猜测本地执行环境或 Worker。

这里的“首轮执行”指静态审查完成后的首次 `nvcc`/二进制门禁；静态审查本身仍先执行。

- 优先从 `input_code_path` 所在目录向上查找 `{output_dir}/EnvConfig/config.md`，读取其中的 `execution_backend`
- `execution_backend=local`：直接在本地执行环境执行
- `execution_backend=worker`：通过 `submit_task_to_worker.py` 提交 Worker Task
- EnvConfig 缺失或无法判断后端时，必须先回到 `cuda-c-main` 的 EnvConfig 规则完成环境确认；不要把环境错误当作 kernel 错误修复

**重点要求**：分发给 subagent 执行`输入代码静态检查`任务（禁止主流程接管此任务）:

```python
agent = spawn_agent(
    agent_type="default",
    message=f"""
    ## 任务文档
    根据 .claude/skills/cuda-c-code-review/StaticReviewer.md 中的规范要求，充当 StaticReviewer 角色，
    对输入的 CUDA C/C++ 文件执行静态检查任务。

    ## 输入
    input_code_path: {input_code_path}

    严格按照任务文档执行：仅修复明确的错误；无论是否发现问题，都必须产出
    {input_code_path 去除 .cu}_fix.cu 和 {input_code_path 去除 .cu}_fix.md。
    保留 kernel 接口、CPU reference、测试 Shape 和 atol/rtol。
    """
)
```

StaticReviewer 无论是否发现问题，都必须产出 `xxx_fix.cu` 和 `xxx_fix.md`；有确定死锁或越界时只先做最小修复，不启动原始危险版本。

**结果分类**：

- 未发现明确错误 → 进入步骤 2a
- 发现可确定且语义明确的错误 → 进入步骤 2b
- 只能动态确认的疑点 → 不改源码、写入报告后进入步骤 2a

### 步骤 2a：静态检查无明确错误

1. 将原文件**原样拷贝**为 `{同目录}/xxx_fix.cu`
2. 在 `{同目录}/xxx_fix.md` 中写入"静态检查未发现需修复问题"
3. 继续进入步骤 3；静态通过不代表编译、运行或精度通过

### 步骤 2b：静态检查发现明确错误

StaticReviewer 在 `xxx_fix.cu` 中完成最小修复，在 `xxx_fix.md` 记录行号、证据和改动。后续步骤统一从 `xxx_fix.cu` 继续；不得修正尚不能从源码确定的问题。

### 步骤 3：动态修复（执行 + 迭代修复）

**重点要求**：分发给 subagent 执行`静态修复后代码的动态修复`任务（禁止主流程接管此任务）:

```python
agent = spawn_agent(
    agent_type="default",
    message=f"""
    ## 任务文档
    根据 .claude/skills/cuda-c-code-review/DynamicFixer.md 中的规范要求，充当 DynamicFixer 角色，
    对经过静态检查后的 CUDA C/C++ 文件执行动态修复任务（编译/执行驱动 + 按错误分类迭代修复）。

    ## 输入
    fixed_code_path: {xxx_fix.cu 的绝对路径}

    严格按照任务文档执行：
    - 必须遵守 cuda-c-main 的环境选择规则，使用 EnvConfig 的 nvcc/flags；Worker 通过 cuda-c-main 的提交脚本同步执行
    - 依次执行 nvcc(sm_86)、CUDA Runtime/CPU reference、Compute Sanitizer；性能只能用同一 stream 的 CUDA Event
    - 迭代时直接覆盖 xxx_fix.cu，并在 xxx_fix.md 追加迭代记录；失败候选必须回退到上一版
    - 遵守红线：严禁 CPU/框架/库算子替代，严禁削弱测试契约
    - 达到终止条件（通过 / 同类错误连续 2 次 / 最大 5 次迭代）即结束
    - 所有结果通过文件传递，不向调用方返回摘要字符串
    """
)
```

DynamicFixer 执行完后，`xxx_fix.cu` 为最终代码、`xxx_fix.md` 已在静态检查段之后追加动态修复全部迭代记录与结论。主流程必须读取报告末尾状态，不得仅因文件存在就宣称通过。

### 流程总览

```
输入 .cu
  ↓
[步骤1] EnvConfig + 静态检查（StaticReviewer 子代理）
  ├─ 无明确错误 → [步骤2a] 原样拷贝
  └─ 有明确错误 → [步骤2b] 最小静态修复
  ↓ 生成 xxx_fix.cu + xxx_fix.md
  ↓
[步骤3] 动态修复（DynamicFixer 子代理）
         内部循环：nvcc → 执行/reference → sanitizer ↔ 按错误分类改写，
         终止条件：通过 / 同类错误连续 2 次 / 达到最大迭代 5 次
  ↓
最终产物：xxx_fix.cu + xxx_fix.md（含静态检查 + 动态修复记录）
```

## xxx_fix.md 的分段写入约定

`xxx_fix.md` 由主流程和两个子代理**分段追加**完成，具体格式由对应文档规范：

| 段落 | 写入方 | 参考文档 |
|------|-------|---------|
| 基本信息 / EnvConfig | 主流程（本 SKILL） | 本文档 |
| 静态检查发现（步骤 1/2） | StaticReviewer | `StaticReviewer.md` + `ref/report_template.md` |
| 编译、运行、sanitizer、迭代 / 最终结论（步骤 3） | DynamicFixer | `DynamicFixer.md` |

报告末尾必须包含 `passed`、`blocked`、`target_verified`、`final_code_path`。只有 `passed=true`、`blocked=false` 且 `target_verified=true` 才能写“已在 RTX 3090 上验证”。

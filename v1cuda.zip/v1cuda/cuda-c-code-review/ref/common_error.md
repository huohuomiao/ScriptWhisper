| 错误类型                | 错误描述                                      | 导致后果                       | 修正原则                                        |
| :---------------------- | :-------------------------------------------- | :----------------------------- | :---------------------------------------------- |
| **1. 错误未检查**       | CUDA Runtime、launch 或完成点返回值未检查     | 异步错误延迟暴露或被遗漏       | API、`cudaGetLastError` 和同步都必须检查        |
| **2. 接口不一致**       | Launch 传参个数、顺序或类型与 Kernel 不符     | 编译失败或内存地址解释错误     | 逐项核对签名、const 与模板实例                  |
| **3. 平台/设备不一致**  | 代码设备字面量与目标后端不一致                | 目标后端无法执行               | 按目标平台规则统一设备与同步 API                |
| **4. Grid 覆盖不足**    | 普通 Grid 裁剪到 SM 数却没有 grid-stride loop | 部分输出从未计算               | 发射完整逻辑 Grid 或加入等价步进循环          |
| **5. 缺少边界判断**     | 尾块或向量 lane 未验证范围                    | **内存越界 (Out of Bounds)**   | 每个全局访问证明范围和对齐                    |
| **6. 索引/字节数溢出**  | 32-bit 乘法完成后才转成 `size_t`              | 大 Shape 地址或分配大小错误     | 在乘法前提升到足够宽的整数类型                |
| **7. 分歧同步**         | 只有部分 block 线程到达 `__syncthreads()`     | 死锁、race 或 sanitizer 报错    | block barrier 必须位于一致控制流              |

## 错误示例：

1. CUDA Runtime 与异步错误未检查

错误现象：只启动 kernel 或拷贝数据，没有检查 Runtime API、launch 与完成点。

```cpp
// ❌ 错误示例
cudaMalloc(&device_output, bytes);
kernel<<<blocks, threads, 0, stream>>>(device_output, n);
cudaMemcpyAsync(host_output, device_output, bytes, cudaMemcpyDeviceToHost, stream);

// ✅ 正确做法
CUDA_CHECK(cudaMalloc(&device_output, bytes));
kernel<<<blocks, threads, 0, stream>>>(device_output, n);
CUDA_CHECK(cudaGetLastError());
CUDA_CHECK(cudaMemcpyAsync(host_output, device_output, bytes,
                           cudaMemcpyDeviceToHost, stream));
CUDA_CHECK(cudaStreamSynchronize(stream));
```

Kernel launch 是异步的；`cudaGetLastError()` 检查 launch，受检查的 stream/event 同步检查执行完成。不要为方便而无条件改成全设备同步。

2. Kernel 接口与 Launch 函数不一致

   错误现象：`__global__` 函数定义的形参个数、顺序或类型，与 host 端 launch 传入的实参不匹配。

后果：通常在编译期报错；某些通用 launcher 或 `cudaLaunchKernel` 路径可能把错误类型解释为地址，造成非法访问。

```cpp
// ❌ 错误示例：n 与 alpha 顺序颠倒
__global__ void kernel(const float* x, float* y, std::size_t n, float alpha);
kernel<<<blocks, threads, 0, stream>>>(device_x, device_y, alpha, n);

// ✅ 正确做法
kernel<<<blocks, threads, 0, stream>>>(device_x, device_y, n, alpha);
CUDA_CHECK(cudaGetLastError());
```

修正：严格核对选中的 kernel 实例与 launch 参数，保持指针 const、整数宽度和 stream 语义不变。

3. 平台关键字未转换

   错误现象：迁移代码后仍保留源平台的设备字面量、同步 API 或环境变量。

后果：目标后端无法编译、链接或运行。可执行路径也不得保留其他后端或框架实现；平台规则读取 `.claude/skills/share/cuda-c/references/platform-rules.md`，编译目标固定为 `-arch=sm_86`。

4. 普通 Grid 被裁剪为 SM 数

错误现象：host 端把覆盖数据所需的逻辑 block 数裁剪到 `multiProcessorCount`，但 kernel 每个 block 只处理一个 tile。

```cpp
// ❌ logical_blocks > blocks 时会漏算
int blocks = std::min(logical_blocks, props.multiProcessorCount);
kernel<<<blocks, threads>>>(x, y, n);
```

✅ 正确做法：普通 kernel 发射完整逻辑 Grid；只有同时实现等价 grid-stride loop 才能限制 Grid。

```cpp
__global__ void kernel(const float* x, float* y, std::size_t n) {
    for (std::size_t i = blockIdx.x * static_cast<std::size_t>(blockDim.x) + threadIdx.x;
         i < n;
         i += static_cast<std::size_t>(blockDim.x) * gridDim.x) {
        y[i] = x[i];
    }
}
```

5. 忘记处理边界 Mask

错误现象：直接访问 `index` 或向量全部 lane，没有考虑元素数不是 block/tile 的整数倍。

后果：内存越界访问（Out of Bounds）。这可能导致程序直接 Segfault，或者读取到垃圾数据导致计算精度异常。

```cpp
// ❌ n=100、threads=128 时后 28 个线程越界
std::size_t index = blockIdx.x * blockDim.x + threadIdx.x;
output[index] = input[index];
```

修正：检查每个实际访问；向量 load/store 还必须证明所有 lane 的范围与对齐。

```cpp
// ✅ 正确做法
std::size_t index = blockIdx.x * static_cast<std::size_t>(blockDim.x) + threadIdx.x;
if (index < n) output[index] = input[index];
```

6. 指针运算缺少基础偏移

错误现象：索引遗漏 `blockIdx * blockDim` 基址，或先用 `int` 计算行偏移再赋给 `size_t`。

```cpp
// ❌ 所有 block 重复处理第一段数据
std::size_t offset = threadIdx.x;

// ✅ 包含 block 基址，并在乘法前提升
std::size_t offset = blockIdx.x * static_cast<std::size_t>(blockDim.x) + threadIdx.x;
```

7. 分歧控制流中的 block barrier

```cpp
// ❌ 尾块只有有效线程到达 __syncthreads()
if (index < n) {
    shared[threadIdx.x] = input[index];
    __syncthreads();
}
```

修正：把被条件控制的内存操作与必须全 block 到达的 barrier 分开；不要盲目加 barrier，也不能用 `__syncthreads()` 同步不同 block。

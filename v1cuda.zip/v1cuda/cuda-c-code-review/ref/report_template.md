# CUDA C/C++ 算子代码检视报告

## 基本信息

- **算子名称**：[名称]
- **文件路径**：[路径]
- **输入文件类型**：`.cu`（记录绝对路径）
- **输出文件**：[绝对 `_fix.cu` 路径]
- **执行后端**：`local | worker | unresolved`
- **设备**：[逻辑 index、名称、UUID/PCI、CC、SM 数]
- **工具链**：[nvcc、host compiler、Compute Sanitizer]
- **编译参数**：[完整参数，目标必须为 `sm_86`]

---

## 一、CUDA 原语与接口检测

| 原语名称       | 使用位置/行号 | 数据类型 | 是否支持 int64 | 是否符合规范 | 备注/建议修改                                           |
| -------------- | ------------- | -------- | -------------- | ------------ | ------------------------------------------------------- |
| `cudaMalloc` | kernel.cu:45 | device pointer | N/A | ✅/❌ | 返回值、byte count、释放路径与 `sm_86` 编译证据 |
| Kernel launch | kernel.cu:60 | 参数列表 | N/A | ✅/❌ | 签名、grid/block/shared/stream |
| `atomicAdd` | kernel.cu:72 | fp16/fp32/int | 依 dtype | ✅/⚠️ | 对照 Toolkit 与 `sm_86` |
| `__shfl_sync` | kernel.cu:80 | warp value | 依 dtype | ✅/❌ | active mask 与 source lane |
| `__syncthreads` | kernel.cu:85 | block scope | N/A | ✅/❌ | 必须由参与 block 的线程一致到达 |
| `float4` load/store | kernel.cu:95 | global memory | No | ✅/⚠️ | 所有 lane 范围与对齐 |
| `cudaEventElapsedTime` | kernel.cu:110 | host timing | N/A | ✅/❌ | 同一 stream、warmup、重复测量 |

## 二、CUDA C/C++ 常见错误检测

| 错误类型 | 错误描述 | 导致后果 | 修正原则 |
| :--- | :--- | :--- | :--- |
| **1. 接口不一致** | Launch 参数与 Kernel 定义不符 | 编译失败或地址错误 | 逐项核对签名、const 与模板实例 |
| **2. 错误未检查** | Runtime/launch/sync 返回值未检查 | 异步错误被遗漏 | 检查所有 API 与完成点 |
| **3. 平台残留** | 代码中保留源平台关键字或环境 | 目标后端无法识别设备 | 按目标平台共享规则替换 |
| **4. Grid 覆盖不足** | 普通 grid 裁剪到 SM 数 | 部分输出未写 | 完整逻辑 grid 或 grid-stride loop |
| **5. 缺少边界判断** | 尾块/向量 lane 未判界 | **内存越界** | 证明每次 load/store 范围与对齐 |
| **6. 索引溢出** | 32-bit 乘法后才提升 | 大 Shape 地址错误 | 在运算前转成宽整数 |
| **7. 分歧同步** | 部分线程无法到达 barrier | 死锁或数据竞争 | barrier 放入一致控制流 |

---

## 三、平台扩展数学库检测

目标代码按照 `.claude/skills/share/cuda-c/references/libdevice.md` 检查标准 device math、快速 intrinsic 和编译 flags。共享文件是硬件/API 参考，不代替本报告的验证流程。

| 检查项 | 状态 | 详情/错误位置 | 判定标准 |
| :--- | :--- | :--- | :--- |
| **数据类型兼容性** | ✅/❌/N/A | | 函数签名、float/double/half/BF16 与 `sm_86` 匹配 |
| **快速 intrinsic** | ✅/❌/N/A | | `__expf` 等近似路径由需求允许且未放宽容差 |
| **全局 fast math** | ✅/❌/N/A | | `--use_fast_math` 只能作为独立候选，不得混入修复 |
| **累加精度** | ✅/❌ | | 归约累加 dtype 满足冻结的 CPU reference 精度契约 |
| **特殊值行为** | ✅/❌/N/A | | NaN/Inf、signed zero 和定义域边界与需求一致 |

## 四、原始与最终动态门禁

| 门禁 | 命令 | Exit | 原始结果 | 最终结果 | 证据 |
| --- | --- | ---: | --- | --- | --- |
| EnvConfig/目标设备 | `[probe]` | `[code]` | PASS/FAIL/BLOCKED | PASS/FAIL/BLOCKED | `[Linux, RTX 3090, CC 8.6]` |
| NVCC/PTXAS | `[nvcc ...]` | `[code]` | PASS/FAIL/NOT_RUN | PASS/FAIL/NOT_RUN | `[第一根错误或资源摘要]` |
| CUDA Runtime | `[binary]` | `[code]` | PASS/FAIL/NOT_RUN | PASS/FAIL/NOT_RUN | `[API/launch/sync]` |
| CPU reference | `[binary cases]` | `[code]` | PASS/FAIL/NOT_RUN | PASS/FAIL/NOT_RUN | `[shape, atol, rtol, max error]` |
| Memcheck | `[command]` | `[code]` | PASS/FAIL/NOT_RUN | PASS/FAIL/NOT_RUN | `[摘要]` |
| Initcheck | `[command]` | `[code]` | PASS/FAIL/NOT_RUN | PASS/FAIL/NOT_RUN | `[摘要]` |
| Racecheck | `[command]` | `[code]` | PASS/FAIL/NOT_RUN | PASS/FAIL/NOT_RUN | `[摘要]` |
| Synccheck | `[command]` | `[code]` | PASS/FAIL/NOT_RUN | PASS/FAIL/NOT_RUN | `[摘要]` |
| CUDA Event timing | `[binary]` | `[code]` | INFO/INVALID/N/A | INFO/INVALID/N/A | `[warmup, repeats, stream, ms]` |

## 五、静态修复与动态迭代

### 静态发现

| 严重性 | 位置 | 类别 | 证据 | 最小修复或待动态确认 |
| --- | --- | --- | --- | --- |
| error/warning/note | `[file:line]` | `[class]` | `[why]` | `[edit or gate]` |

### 迭代 `[N]`

- 失败门禁与归一化错误：[值]
- 根因推断：[值]
- 最小改动：[值]
- 重跑结果：[值]
- 候选保留/回退：[决定和原因]

## 六、结论

- 最后通过的门禁：[列表]
- 最后失败或阻塞的门禁：[值或 none]
- 精度：[固定 cases、atol/rtol、max error]
- PTXAS 资源：[register/shared/spill 或 N/A]
- 剩余限制：[列表]

```text
passed: true|false
blocked: true|false
target_verified: true|false
final_code_path: [absolute path]
```

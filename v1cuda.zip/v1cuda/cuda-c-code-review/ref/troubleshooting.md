# CUDA C/C++ 通用故障排查与修复指南

本文保存 CUDA C 算子审查流程使用的通用排错方法。RTX 3090 的设备、Grid、register、shared memory 与 `sm_86` 规则读取 `.claude/skills/share/cuda-c/references/platform-rules.md`。

## 精度问题

### 逻辑运算符

CUDA 条件逻辑与位掩码语义不同，按操作数类型选择运算符。

### Load 与 Store mask

读取 mask 可包含输入过滤条件；写回 mask 只描述合法输出位置。不要因为某个输入无效而漏写本应产生的输出。

CUDA C 用显式边界谓词实现 mask。

### 累加 dtype

低精度输入进行长归约时，把累加器提升到 fp32，并在输出边界处按需求转换。

### 精度验证

- 使用独立 CPU reference；比较全部输出，失败时非零退出。
- 保留用户提供的 `atol`、`rtol` 和测试 Shape。
- 同时记录 `max_diff`、NaN/Inf 位置和失败输入。

## 编译与原语错误

1. 确认原语名称、参数和 Toolkit 版本一致。
2. 确认目标后端支持该原语与 dtype。
3. 环境工具缺失时回到 EnvConfig；只修 `nvcc` 第一条根诊断，固定 `-arch=sm_86`。

## Kernel 接口不一致

- Kernel 与 launch 的参数、const、位宽、shared bytes 和 stream 必须一致。
- `cudaLaunchKernel` 参数及异步资源必须保持正确 ABI 和生命周期。

## 数据类型错误

- 检查输入、常量、中间值、累加器和输出的 dtype 链路。
- 混合类型计算时显式转换，避免依赖不同后端可能不同的隐式提升。
- 索引计算优先使用足够位宽的整数类型，但必须符合目标后端原语支持表。
- half/BF16、原子及快速数学以 `sm_86` 真实编译和冻结精度为准。

## 内存越界与非法访问

### 基址与程序编号

```cpp
std::size_t index = blockIdx.x * static_cast<std::size_t>(blockDim.x) + threadIdx.x;
if (index < n) output[index] = input[index];
```

检查以下问题：

- 是否遗漏 block 基址或 grid-stride 增量。
- Shape 不是 Block 整数倍时是否正确使用 mask。
- 广播后的地址表达式是否与 Tile 形状一致。
- Stride、转置和 Flatten 后的地址是否仍指向预期元素。
- Persistent Kernel 是否覆盖每个逻辑块且没有重复写冲突。
- 另查向量对齐、资源生命周期；用 memcheck 定位，不能缩小 Shape 掩盖越界。

## 同步、竞争与超时

- block barrier 一致到达；warp mask 覆盖真实参与 lane；循环必须前进。
- Compute Sanitizer 按 memcheck → initcheck → racecheck → synccheck 分别通过。

## 调试与定位流程

1. 先运行最小合法 Shape，确认能够编译和启动。
2. 分离环境错误与业务错误；环境不可用时不要修改 Kernel。
3. 固定随机种子，保存首个失败输入。
4. 检查 NaN/Inf，再检查最大误差位置。
5. 缩小到单个 Kernel、单组输入和单个失败分支。
6. 每轮只做一个可解释的修改，重新执行相同测试。
7. 精度通过后再进行性能比较。

失败加重或新增 sanitizer 问题时回退；最后重跑完整门禁，性能使用 CUDA Event。

## 禁止的替代式修复

- 禁止用 CPU、PyTorch、cuBLAS/cuDNN/Thrust 实现替代要求开发的自定义 CUDA Kernel。
- 禁止跳过 Kernel 调用或伪造成功输出。
- 禁止缩小用户测试 Shape、放宽误差阈值或删除失败用例。
- 禁止用逐元素标量 Kernel 规避本应保留的块并行逻辑。
- 禁止修改 reference 或让 mismatch 返回 0。
- 禁止用全局 `--use_fast_math` 或更高 `-arch` 作为正确性修复。

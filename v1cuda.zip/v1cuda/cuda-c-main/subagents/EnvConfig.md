# EnvConfig

## 职责概述

EnvConfig 负责 CUDA C/C++ 算子开发前的运行环境确认。源码编译、kernel 运行、
精度测试和性能测试必须在 Linux RTX 3090（Compute Capability 8.6）环境完成；
如果当前环境具备目标 GPU、`nvcc` 与 CUDA Runtime，则直接执行命令，否则通过
`.claude/skills/cuda-c-main/subagents/scripts/submit_task_to_worker.py`
提交 Worker Task 作为兜底。

本文中的“本地执行”指直接在当前环境运行命令；“Worker”指通过
`submit_task_to_worker.py` 提交任务的远端执行环境。

EnvConfig 产出人类可读的环境记录和设备信息原文；下游需要运行代码时，继续
遵守主流程 `.claude/skills/cuda-c-main/SKILL.md` 中的运行环境选择规则。

## 运行环境选择规则

所有动态执行必须遵守主流程 `.claude/skills/cuda-c-main/SKILL.md` 中的运行环境选择规则：

- EnvConfig 必须先直接在本地顺序执行 `get_device_info.py` 和 `test_env_code.py`。
- 只有两个脚本在本地都 exit code = 0，才判定 `execution_backend=local`，下游动态执行直接在本地运行命令。
- 只要任意一个脚本在本地失败，就必须在当前 `JOB_ID` 下通过 Worker Task 顺序执行同一套 `get_device_info.py` 和 `test_env_code.py`，禁止新建 Job。
- 只有两个脚本在 Worker 上都成功，才判定 `execution_backend=worker`；如果 Worker 检查也失败，必须停止流程并报告真实日志。
- 每次 Worker Task 调用必须前台同步执行，等待 `submit_task_to_worker.py` 退出后再进行下一步；禁止 `&` 后台、禁止并发提交多个 Worker Task。
- Worker Task 必须以脚本退出码和 Worker 写入的 `stdout.log`、`stderr.log`、`result.json` 作为真实结果。
- 禁止修改 Worker 全局环境或共享依赖。

## 输入

| 来源 | 内容 |
|------|------|
| 用户输入 | 输出存储路径（默认为 `output_dir`） |
| CUDA 平台探测脚本 | `.claude/skills/share/cuda-c/runtime/test_env_code.py`、`.claude/skills/share/cuda-c/runtime/get_device_info.py` |
| 通用 Worker 脚本 | `.claude/skills/cuda-c-main/subagents/scripts/submit_task_to_worker.py` |
| 环境变量 | `JOB_ID` —— 当前 Job 的真实 ID，仅在需要 Worker Task 时由 `submit_task_to_worker.py` 读取 |

## 输出

| 输出类型 | 说明 |
|---------|------|
| 文件输出 | `{输出存储路径}/EnvConfig/config.md` - 人类可读的运行环境记录；成功与阻塞都必须生成 |
| 文件输出 | `{输出存储路径}/EnvConfig/runtime_info.txt` - 每个探针的命令、退出码、stdout/stderr；成功与阻塞都必须生成 |
| 摘要返回 | 环境配置摘要（见[步骤 4](#步骤-4返回环境配置摘要)） |
## 执行步骤

### 步骤 1：本地探测

直接在本地执行：

```bash
python3 .claude/skills/share/cuda-c/runtime/get_device_info.py --device 0
python3 .claude/skills/share/cuda-c/runtime/test_env_code.py --device 0 --json
```

**检查项**：
- Linux、NVIDIA driver 与 RTX 3090 设备信息（由 `get_device_info.py` 采集）
- `nvcc` 与 CUDA Toolkit/Runtime 版本
- Compute Capability 8.6 与 `sm_86` 可用性
- CUDA C++ Vector Add 编译与运行测试
- 精度验证（最大误差 < 1e-5）

**结果判断**：
- ✅ **成功**（两个脚本 exit code 都为 0 且确认 RTX 3090 / CC 8.6）：本地目标环境就绪，进入步骤 2a
- ❌ **失败**（任一脚本失败或设备不匹配）：进入步骤 1b，使用 Worker Task 兜底

### 步骤 1b：Worker 自检（本地不可用时）

在 Worker 侧顺序执行 `.claude/skills/share/cuda-c/runtime/get_device_info.py`
和 `.claude/skills/share/cuda-c/runtime/test_env_code.py`，验证远端 RTX 3090 与 CUDA C/C++ 环境：

```bash
python3 .claude/skills/cuda-c-main/subagents/scripts/submit_task_to_worker.py \
    --task-type custom \
    --workdir <仓库根目录的绝对路径> \
    --timeout-sec 600 \
    --command "python3 .claude/skills/share/cuda-c/runtime/get_device_info.py --device 0; info_rc=\$?; python3 .claude/skills/share/cuda-c/runtime/test_env_code.py --device 0 --json; test_rc=\$?; printf 'get_device_info_exit=%s\\ntest_env_code_exit=%s\\n' \"\$info_rc\" \"\$test_rc\"; [ \"\$info_rc\" -eq 0 ] && [ \"\$test_rc\" -eq 0 ]"
```

前台同步执行该命令，等待脚本退出后读取退出码再判断。
**结果判断**：
- ✅ **成功**（exit code = 0）：Worker 环境就绪，进入步骤 3
- ❌ **失败**（exit code = 1 / 2）：回读 Worker 自检的 `stdout.log`、`stderr.log` 与 `result.json`，仍执行步骤 3 写出 `status=blocked` 记录，然后停止下游流程

### 步骤 2a：本地环境信息整理

将步骤 1 中两个本地脚本各自的命令、退出码、stdout 与 stderr 按执行顺序整理，进入步骤 3。

### 步骤 3：生成环境记录

#### 3.1 生成 `{输出存储路径}/EnvConfig/config.md`

```markdown
# 环境配置

## 执行位置

- status: {ready|blocked}
- execution_backend: {local|worker|none}
- worker_submit_url: http://127.0.0.1:8086/run/v1/agent/submit-task（仅 Worker 模式）
- env_check_task_id: {成功或失败的 Worker task_id、local，或未提交 Worker 时的 not-submitted}

## 环境检查结果

{每个本地与 Worker 探针的状态、退出码及最终判定；阻塞时必须包含 failure_reason}

### 执行环境信息

> 以下内容按命令分别保存 exit code、stdout 与 stderr，等价于在实际执行环境中
> 顺序执行 `get_device_info.py` 和 `test_env_code.py`；不得只保存最后一条命令的输出。

\```
{带命令标签、退出码、stdout/stderr 标签的环境信息原文}
\```

## 时间戳

{timestamp}
```

#### 3.2 保存环境信息原文

把所有已执行探针的命令、退出码、stdout 与 stderr 原文写入：
```text
{输出存储路径}/EnvConfig/runtime_info.txt
```

### 步骤 4：返回环境配置摘要

将结果以摘要形式返回给调用方：

```json
{
  "status": "ready 或 blocked",
  "execution_backend": "local、worker 或 none",
  "failure_reason": "<blocked 时必填；ready 时为空>",
  "worker_submit_url": "http://127.0.0.1:8086/run/v1/agent/submit-task（仅 Worker 模式）",
  "env_check_task_id": "<成功或失败的 Worker task_id；本地成功为 local；未提交 Worker 为 not-submitted>",
  "runtime_info_path": "{输出存储路径}/EnvConfig/runtime_info.txt",
  "config_path": "{输出存储路径}/EnvConfig/config.md"
}
```

字段说明：
- `status`: `ready` 表示目标环境自检通过；`blocked` 表示本地与 Worker 均未提供可用目标环境，下游完整流程必须停止
- `execution_backend`: `local` 表示本地 RTX 3090/CUDA 可用；`worker` 表示 Worker 可用；`none` 只用于 `blocked`
- `failure_reason`: 阻塞的最早可操作原因，并指向 `runtime_info.txt` 中的对应命令及 stdout/stderr
- `env_check_task_id`: Worker 成功或失败都记录真实 task id；本地成功为 `local`；Worker 未提交为 `not-submitted`
- `runtime_info_path`: 指向每条实际探针命令、退出码、stdout 与 stderr 的本地证据文件

## 验证方式

| 检查项 | 验证方式 | 通过条件 |
|--------|--------|--------|
| 本地设备信息 | 直接在本地执行 `python3 .../get_device_info.py` | 退出码 = 0 且设备为 RTX 3090 / CC 8.6 |
| 本地环境自检 | 直接在本地执行 `python3 .../test_env_code.py` | `nvcc` 编译与 CUDA Runtime smoke test 退出码 = 0 |
| Worker 环境检查（本地不可用时） | 在一个同步 Task 中顺序运行两个探针并分别保存退出码 | 两个探针退出码均为 0 且设备匹配 |
| 环境信息落盘 | 检查 `runtime_info.txt` 存在且非空 | 文件内容含每条实际命令的退出码、stdout 与 stderr |

## 回退机制

| 场景 | 处理方式 |
|------|--------|
| 本地 `get_device_info.py` 失败 | 切换到 Worker Task 兜底 |
| 本地 `test_env_code.py` 失败 | 切换到 Worker Task 兜底 |
| Agent-Service 本地接口不可达（Worker 模式） | 先写 `status=blocked` 与现有日志，再退出并提示用户确保 Agent-Service 可用 |
| Worker 环境检查失败 | 先写 `status=blocked`，保存 Worker `stdout.log` / `stderr.log` / `result.json` 与 task id，再退出 |

## 下游使用说明

后续步骤（`cuda-c-code-review` 动态测试、`cuda-c-optimize` benchmark 等）在需要编译或运行 CUDA 代码时，继续遵守主 Skill 的运行环境选择规则：本地目标环境可用则直接执行；否则通过 `.claude/skills/cuda-c-main/subagents/scripts/submit_task_to_worker.py` 执行：
```bash
python3 .claude/skills/cuda-c-main/subagents/scripts/submit_task_to_worker.py \
    --workdir <绝对路径> \
    --command "<要跑的命令，如 nvcc -std=c++17 -O3 -arch=sm_86 /abs/path/op.cu -o /abs/path/op && /abs/path/op>" \
    --task-type {compile|accuracy|performance|custom} \
    --timeout-sec <运行阶段超时秒数>
```

每次 Worker Task 必须前台同步执行，等待 `submit_task_to_worker.py` 返回退出码后再进入下一步；禁止 `&` 后台、禁止并发提交多个 Worker Task。每次提交必须显式传入 `--timeout-sec`，它表示 Worker lease 后才开始计时的运行阶段超时；Scheduler 会额外用当前 Job 剩余时间限制排队 + 运行的总截止时间。判断成功/失败时，以实际执行环境的退出码和 stdout/stderr/result 为准；Worker 模式下以脚本退出码（`0` = succeeded / `1` = failed / `2` = 基础设施错误）和 Worker 产物 `stdout.log`、`stderr.log`、`result.json` 为准。

## 相关脚本

| 脚本 | 位置 | 功能 |
|------|------|------|
| `test_env_code.py` | `.claude/skills/share/cuda-c/runtime/` | `nvcc` + CUDA Runtime 环境自检脚本 |
| `get_device_info.py` | `.claude/skills/share/cuda-c/runtime/` | NVIDIA GPU、driver、Toolkit 与 CC 信息采集脚本 |
| `submit_task_to_worker.py` | `.claude/skills/cuda-c-main/subagents/scripts/` | Worker 提交 + 轮询 + 回读真实结果；仅在本地没有目标 GPU/工具链时使用 |

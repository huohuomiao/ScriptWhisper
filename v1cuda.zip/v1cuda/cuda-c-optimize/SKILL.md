---
name: cuda-c-optimize
description: Linux NVIDIA RTX 3090（Ampere sm_86）上的 CUDA C/C++ 算子性能优化专家；用于优化包含 kernel、launch、正确性和 CUDA Event 性能测试的完整 .cu 文件。
---

# cuda-c-optimize

## 概述

该 SKILL 是 Linux NVIDIA GPU 上的 CUDA C/C++ 算子性能优化专家，目标是使用多种优化策略组合提升 RTX 3090（Ampere，sm_86）上的 kernel 性能。设备参数、阈值、数学函数和采集脚本只从 `.claude/skills/share/cuda-c/` 读取；本目录继续负责策略编排、验证、选择与回退。

**核心目标**：在不放宽精度和安全门禁的前提下，将指定 CUDA C/C++ 算子优化到实测 best-so-far；没有真实 RTX 3090 证据时不得声称性能提升。

## 用法

```bash
/cuda-c-optimize <cuda_code> [output_dir]
```

**参数说明**：

| 参数 | 说明 |
|------|------|
| `cuda_code` | 包含 CUDA kernel、launch、正确性与性能测试的完整代码（文件路径或代码片段） |
| `output_dir` | 输出结果存储文件夹路径（可选，默认为当前目录下的 `output/`） |

**输入形式支持**：
   - 文件路径：指向 `.cu` 文件的路径
   - 代码片段：可落盘为 `.cu` 的 CUDA C/C++ 代码文本

## 工作流程

### 步骤 1：输入代码检查

检查输入 CUDA C/C++ 代码是否完整，必须包含以下四个部分，否则终止优化：

   - CUDA Kernel：至少一个 `__global__` 函数
   - host wrapper：包含 `<<<grid, block, shared_bytes, stream>>>` 或 `cudaLaunchKernel`
   - 可自动判定失败的正确性测试与 CUDA 错误检查
   - 使用 CUDA Event、包含 warmup/repeat 的 kernel 性能测试

先读取 `{output_dir}/EnvConfig/config.md` 和 `.claude/skills/share/cuda-c/references/platform-rules.md`。仅当执行后端可用且目标确认为 RTX 3090/sm_86 时进入动态优化；否则进入 `static_only`，原样输出输入代码、将性能写为 `not_measured`，并跳过所有动态候选。

`static_only` 必须立即闭合固定输出契约：将原始输入逐字复制为 `cuda_oob_optimized.cu`、`cuda_advanced_optimized.cu` 和 `cuda_optimized.cu`；生成对应三个 `.md`，统一写明 `decision=not_measured`、`blocked=true`、`target_verified=false`，性能与资源字段为 `N/A` 并记录阻塞原因。该分支不得创建候选、调用优化 subagent、编译、运行或执行 NCU，完成这些固定产物后直接结束本 Skill。

动态模式进入首个策略前必须冻结原始 baseline，并将证据写入 `{output_dir}/Optimizer/baseline.json`：记录源码哈希、完整 `nvcc` 命令、设备与工具链、测试 shape/dtype/seed/stream、容差、correctness/accuracy/CUDA error/Compute Sanitizer 各门禁状态、CUDA Event warmup/repeat、median/p20/p80，以及 ptxas 的 register/shared/spill。所有候选使用相同编译参数和测试口径。候选只有在编译、正确性、CUDA 错误/安全检查均通过，且真实 RTX 3090 median 明确不回退时才能进入下一轮；否则输出必须回退为本轮 `input.cu`。`--use_fast_math`、`-maxrregcount` 等只能作为显式候选变化，不能偷偷加入基线。

### 步骤 2：开箱性能优化（Out-of-Box Performance Optimization）

开箱性能优化采用结构化匹配方式，将 CUDA C/C++ 代码调整为 Ampere 友好的线程块、访存和归约实现，追求用最小代价获得可靠的基线收益。

开箱性能优化不过分关注性能提升，部分优化对性能无直接收益甚至性能回退，但确是进行后续优化的关键步骤。

以下为所有的开箱性能优化策略：
| 序号 | 策略 | 策略名称 | 说明  | 是否必须生效 |
|--------|------|-------------|------|------------------|
| 1 | 分块优化 | `retiling` | 分析 CUDA kernel，优化 thread/block、并行轴和归约轴的 tile | 否 |
| 2 | 归约优化 | `reduce-opt` | 用 warp shuffle、shared memory 或合法 atomic 优化归约 | 否 |
| 3 | Grid 优化 | `modify-grid` | 调整 `dim3` 和 grid-stride；persistent 仅在占用率证据支持时采用 | 否 |
| 4 | 索引计算简化 | `index-computation-simplify` | 消除 load/store 地址计算中的冗余计算 | 否 |
| 5 | 自动调优配置生成 | `gen-autotune-config` | 离线编译并测试 block/tile/vector/unroll 候选，冻结单一最优配置 | 是 |

#### 2.1 顺序执行各优化策略

严格按照序号，串行执行上述所有开箱性能优化策略，单个优化策略执行步骤如下：

1. 开始 `当前优化策略`

2. 创建 `当前优化策略` 工作目录：`mkdir -p {output_dir}/Optimizer/{当前策略序号}_{当前策略名称}/`

3. 复制输入代码：将 `上一轮优化策略` 输出的 `cuda_optimized.cu` 复制到 `当前优化策略` 工作目录并改名为 `input.cu`（第一个策略使用步骤 1 的输入代码）：

   ```bash
   cp {上一轮优化策略输出代码路径} {output_dir}/Optimizer/{当前优化策略序号}_{当前策略名称}/input.cu
   ```

   随后按 `.claude/skills/cuda-c-optimize/kernel-info/strategy.md` 对本轮 `input.cu` 重新执行一次静态提取，将结果保存为当前工作目录的 `kernel_info.json`。多 kernel 且无法唯一确定目标、解析失败或输出缺失时，本轮策略必须原样回退，不得复用上一轮或其他 kernel 的轴信息。

4. **重点要求**：分发给 subagent 执行 `当前优化策略`（禁止主流程接管此任务）:

```python
agent = spawn_agent(
    agent_type="default",
    message=f"""
   ## 任务文档
   根据 .claude/skills/cuda-c-optimize/utils/Optimizer.md 中的说明，作为优化器，执行 {`本轮优化策略`}。

   ## 用户输入
   策略名称：{当前策略名称}
   策略文档路径：.claude/skills/cuda-c-optimize/{`当前优化策略`名称}/strategy.md
   工作目录：{`当前优化策略` 工作目录}

   严格按照任务文档要求执行。
   """
)
```

**subagent 输入输出说明**：

   - 优化策略输入代码：`{工作目录}/input.cu`（主流程在调用前复制）
   - 优化策略输出代码：`{工作目录}/cuda_optimized.cu`（subagent 生成）
   - 优化策略优化报告：`{工作目录}/cuda_optimized.md`（subagent 生成）

**输出校验与重试**：

每个 subagent 执行完毕后，主流程必须检查其工作目录是否包含以下两个输出文件：

   - `{工作目录}/cuda_optimized.cu`（优化后代码）
   - `{工作目录}/cuda_optimized.md`（优化报告）

若任一文件缺失，则重新调用 `当前优化策略` 的 subagent，最多重试 2 次。若重试后仍未生成，则标记该策略为失败，将 `{当前优化策略工作目录}/input.cu` 原样复制为 `{当前优化策略工作目录}/cuda_optimized.cu`。

6. 第 5 步验证通过后，继续进行下一轮优化策略，直至所有优化策略顺序执行完毕。

#### 2.2 汇总优化结果

开箱优化所有策略执行完毕后，读取每个策略的优化报告 `{output_dir}/Optimizer/{策略序号}_{策略名称}/cuda_optimized.md`，提取以下信息并记录到`优化策略执行进度清单`：

   - **状态**：成功 / 失败
   - **精度是否通过**：`accuracy_pass`
   - **性能数据**：`opt_cuda_ms`、`speedup_opt_vs_original`、`speedup_opt_vs_reference`

提取完毕将`优化策略执行进度清单`写入 `{output_dir}/Optimizer/cuda_oob_optimized.md`。

**生成开箱优化代码**：

   - 开箱优化的产物为所有开箱优化策略顺序执行完毕之后的输出代码，即最后一项优化策略输出代码
   - 若最后一项优化策略输出代码缺失，则向前依次查找最近一个存在输出代码的优化策略
   - 若所有优化策略均无输出代码，则使用步骤 1 的原始输入代码

将开箱优化代码复制到 `{output_dir}/Optimizer/cuda_oob_optimized.cu`。

### 步骤 3：深度性能优化（Advanced Performance Optimization）

深度性能优化：基于 ptxas 与 NCU 实测数据对开箱优化后的 CUDA kernel 进行微调，通过受控迭代维护 best-so-far。

深度性能优化专注于性能提升，要求每一步修改都必须有性能的提升。

深度性能优化先通过 perf-analyzer 收集目标 CUDA kernel 的 NCU 数据，再按照实际瓶颈调用以下可用策略：

|      策略      |     策略名称     |                            说明                            |
|---------------|-----------------|------------------------------------------------------------|
| Libdevice 优化 | `libdevice-opt` | 按精度契约选择 CUDA math intrinsic 或 fast intrinsic |
| Config 微调    | `config-tuner`  | 调整 block size、tile、vector width、unroll 和 shared staging |
| 除法指令优化 | `div-to-mul` | 将除法指令修改为乘倒数 |

#### 3.1 创建工作目录

创建深度性能优化总的工作目录：`mkdir -p {output_dir}/Optimizer/Advanced_Optimization/`

#### 3.2 迭代优化

1. 开始第 `i` 轮迭代优化

2. 创建 `本轮迭代优化` 工作目录：`mkdir -p {output_dir}/Optimizer/Advanced_Optimization/iter_{i}/`
3. 复制输入代码：将 `上一轮迭代优化` 输出的 `cuda_optimized.cu` 复制到 `本轮迭代优化` 工作目录并统一改名为 `input.cu`（首轮使用 `{output_dir}/Optimizer/cuda_oob_optimized.cu`）：

   ```bash
   cp {上一轮迭代输出代码路径} {output_dir}/Optimizer/Advanced_Optimization/iter_{i}/input.cu
   ```

   在性能分析之前，按 `.claude/skills/cuda-c-optimize/kernel-info/strategy.md` 从本轮 `input.cu` 重新生成当前迭代目录的 `kernel_info.json`。若目标 kernel 有歧义或静态提取失败，本轮不得进入策略改写，直接保留当轮 best-so-far 并在报告中记录原因。

4. **重点要求**：分发给 subagent 执行 `本轮迭代优化` 的性能分析 perf-analyzer 任务（禁止主流程接管此任务）:

```python
agent = spawn_agent(
    agent_type="default",
    message=f"""
   ## 任务文档
   根据 .claude/skills/cuda-c-optimize/perf-analyzer/strategy.md 中的描述，完成性能分析任务。

   ## 用户输入
   性能分析名称：perf-analyzer
   性能分析文档路径：.claude/skills/cuda-c-optimize/perf-analyzer/strategy.md
   input_file：{output_dir}/Optimizer/Advanced_Optimization/iter_{i}/input.cu
   output_dir：{output_dir}/Optimizer/Advanced_Optimization/iter_{i}/

   严格按照任务文档要求执行。
   """
)
```

5. 选取 `本轮优化策略`

读取 perf-analyzer 的性能分析结果，从优化建议中选中 `本轮优化策略`。

当同时给出多个优化建议，只选中其中一个作为 `本轮优化策略`。（优先选择之前轮次中未被选中的优化策略）

6. **重点要求**：分发给 subagent 执行 `本轮优化策略`（禁止主流程接管此任务）:

先解析策略文档路径：

- `libdevice-opt`：`.claude/skills/share/cuda-c/optimize/libdevice-opt.md`
- 其他策略：`.claude/skills/cuda-c-optimize/{本轮优化策略名称}/strategy.md`

所有 CUDA 策略还必须读取 `.claude/skills/share/cuda-c/references/platform-rules.md`，不得在本目录硬编码设备资源阈值。

```python
agent = spawn_agent(
    agent_type="default",
    message=f"""
   ## 任务文档
   根据 `.claude/skills/cuda-c-optimize/utils/Optimizer.md` 中的说明，作为优化器，执行 {`本轮优化策略`}。

   ## 用户输入
   策略名称：{`本轮优化策略`名称}
   策略文档路径：{按上述规则解析后的策略文档路径}
   工作目录：{`本轮迭代优化` 工作目录}

   严格按照任务文档要求执行。
   """
)
```

7. 确保当前 subagent 执行完毕
查看 `本轮迭代优化` 工作目录下是否包含以下两个输出文件：

- `{output_dir}/Optimizer/Advanced_Optimization/iter_{i}/cuda_optimized.cu`（优化后代码）
- `{output_dir}/Optimizer/Advanced_Optimization/iter_{i}/cuda_optimized.md`（优化报告）

若任一文件缺失，则重新调用 `本轮优化策略` 的 subagent，最多重试 2 次。若重试后仍未生成，则标记该策略为失败，将 `{本轮迭代优化工作目录}/input.cu` 原样复制为 `{本轮迭代优化工作目录}/cuda_optimized.cu`。

8. 第 7 步验证通过后，继续第 `i+1` 轮迭代，**直至达成任一优化终止条件**

**迭代优化终止条件**：

   - 连续 3 次迭代优化性能无提升
   - 本轮性能分析报告中无任何优化建议

#### 3.3 汇总优化结果

深度优化迭代完毕后，按顺序读取`{output_dir}/Optimizer/Advanced_Optimization` 下所有迭代轮次的优化报告，提取以下信息并记录到`优化策略执行进度清单`：

   - **状态**：成功 / 失败
   - **精度是否通过**：`accuracy_pass`
   - **性能数据**：`opt_cuda_ms`、`speedup_opt_vs_original`、`speedup_opt_vs_reference`

提取完毕将`优化策略执行进度清单`写入 `{output_dir}/Optimizer/cuda_advanced_optimized.md`。

**生成深度优化代码**：

   - 在所有通过精度、安全和公平 benchmark 门禁的候选中，选择 CUDA Event `median_ms` 最低者；不能把最后一轮自动视为最优
   - 当差值处于噪声区间时，选择修改更小、资源更稳的版本
   - 若所有轮次均无可证明收益，则使用开箱优化产物；若其也无收益，则使用步骤 1 的原始输入代码

将深度优化代码复制到 `{output_dir}/Optimizer/cuda_advanced_optimized.cu`。

### 步骤 4：优化输出

1. 确定最终代码：
   - 若步骤 3 实际执行且存在通过门禁的更优候选，使用 `{output_dir}/Optimizer/cuda_advanced_optimized.cu`
   - 若步骤 3 被跳过或没有更优候选，使用 `{output_dir}/Optimizer/cuda_oob_optimized.cu`
   - 若上述代码均缺失，则使用步骤 1 的原始输入代码
2. 将最终代码逐字复制到 `{output_dir}/Optimizer/cuda_optimized.cu` 中作为输出代码
3. 读取各阶段汇总报告（`cuda_oob_optimized.md`、`cuda_advanced_optimized.md`），合并生成全局汇总报告 `{output_dir}/Optimizer/cuda_optimized.md`


## 报告格式

```
## 优化结果报告

### 算子信息
- 源文件：<file_path>
- 算子名称：<算子名>

### 开箱优化（OOB）执行记录
1. [策略名称] - 执行结果：成功 / 失败
2. ...

### 深度优化（Perf）执行记录
迭代 1：
1. [策略名称] - 执行结果：成功 / 失败
2. ...
迭代 2：
...

### 性能对比
| Reference耗时 | 优化后耗时 | Reference带宽 | 优化后带宽 | 相对Reference加速比 |
|-------------|-----------|-------------|-----------|------------------|
| ...ms | ...ms | ...GB/s | ...GB/s | ...x |

### 最终代码路径
{output_dir}/Optimizer/cuda_optimized.cu

### 优化报告
{output_dir}/Optimizer/cuda_optimized.md
```

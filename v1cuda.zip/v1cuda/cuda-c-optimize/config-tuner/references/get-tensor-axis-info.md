# CUDA kernel 获取 tensor 轴信息详解

本文档说明如何从 `.cu` 中静态提取 CUDA kernel 的 tensor 轴、stride、thread/block tile 和循环覆盖关系。标准输出契约以 `../../kernel-info/strategy.md` 为准；这里只补充调参所需的推导方法，不运行输入源码。

## 返回格式

```json
{
  "a": {
    "type": "input",
    "shape": [32, 128],
    "stride": [128, 1],
    "axis": ["M", "N"],
    "has_loop": [false, true],
    "axis_type": ["PARALLEL", "REDUCE"],
    "block_size": [null, "blockDim.x"]
  }
}
```

- 顶层 key 是 `__global__` kernel 的 global-memory 指针参数。
- 只读指针为 `input`；发生写入的指针为 `output`。
- 六个数组严格等长；未知 shape/stride/tile 写 `null`。
- `axis_type` 只允许 `PARALLEL`、`REDUCE`。

## 分析步骤

### Step 1: 展开 offsets

定位目标 CUDA launch，将实参绑定到 kernel 形参。对每个 global load/store，把地址完全展开为：

```text
base_ptr + Σ(offset_i * stride_i)
```

基础变量包括 `blockIdx.{x,y,z}`、`threadIdx.{x,y,z}`、`blockDim`、`gridDim`、shape/stride 参数、编译期 tile 常量和 C/C++ 循环变量。必须区分 global、shared、local 地址；本 JSON 只记录 global 指针。

### Step 2: 依次分析 offset_i

- offset 依赖 block/thread 索引且不聚合时，该轴通常为 `PARALLEL`。
- offset 依赖 `for` 循环变量时，展开 init/condition/step；步长中的 tile 或 `gridDim*blockDim` 是候选 `block_size`，`has_loop=true`。
- 看到 shuffle/shared/atomic/accumulator 后，确认多个轴元素确实合并为更少输出，才把轴标记为 `REDUCE`。
- 多轴 flatten 时，先用 `/`、`%` 还原每个逻辑轴，再分别记录 tile 和循环属性。
- host 侧代表性测试优先取 performance 的首例，其次 accuracy 首例；从 allocation、shape、stride 参数和 launch 恢复真实布局。

### Step 3：绑定目标 kernel 与 launch

1. 收集所有 `__global__` 定义及其完整形参，包括指针的 `const`、类型和模板实例。
2. 收集所有 `<<<...>>>` 与 `cudaLaunchKernel` 调用，解析函数名、模板参数、实参顺序、`dim3`、dynamic shared bytes 和 stream。
3. 优先使用上游报告指定的 kernel 名；否则只能选择唯一实际 launch 的 kernel。
4. 同一 kernel 多次以不同 shape/config 启动时，按代表性测例选择对应 launch，并在报告中列出其他 launch。
5. 函数指针、宏或外部库使绑定不唯一时，不猜测；将歧义、候选和缺失证据写入报告。

形参绑定表必须显式记录：

| kernel 形参 | host 实参 | 类别 | shape 来源 | stride 来源 |
| --- | --- | --- | --- | --- |
| `x` | `d_input` | global input | 测例 allocation | contiguous/显式参数 |
| `y` | `d_output` | global output | wrapper allocation | contiguous/显式参数 |
| `M` | `rows` | scalar | 测例常量 | N/A |

### Step 4：确定 shape 与 stride

沿 host 数据流追踪：

- `cudaMalloc`/allocator 的元素数和字节数。
- wrapper 的 shape、leading dimension、pitch、batch stride 参数。
- contiguous buffer 的行主序 stride。
- transpose/view 只改变解释还是确实 materialize 新 buffer。
- slice、pitch、padding、broadcast/stride-zero、batch 间隔。

不能仅由 allocation 总字节数唯一推导多维 shape。若 shape 已知但 layout 不唯一，对未知 stride 写 `null`；不能把非连续输入默认成 contiguous。

代表性用例之外还需列出 shape 集合，用于判断 template/tile 是否对所有用例成立。例如 performance 首例用于输出 JSON 的具体数值，但 correctness 中的尾块、`N=1`、非整除尺寸仍进入候选验证。

### Step 5：global 指针分类

对每个指针建立读写集合：

| 特征 | 分类处理 |
| --- | --- |
| 仅通过 `const T*` 读取 | `input` |
| 发生普通写、vector store 或 atomic | `output` |
| 既读又写的 in-place 指针 | `output`，报告额外标记 in-place |
| 只传入未知 device helper | 展开 helper；无法展开则歧义 |
| 指向 shared/local | 不作为顶层 global tensor |

`const` 和 `__restrict__` 是辅助证据，不能覆盖实际写入或别名事实。结构体内部指针必须能展开到具体 global base 后才能记录。

### Step 6：建立逐访问地址表

每条访问分别记录，不要先把同一指针的不同表达式合并：

| 访问位置 | 读/写 | base | 展开后的 offset | guard | 循环 |
| --- | --- | --- | --- | --- | --- |
| line A | read | `x` | `row*ld + col` | `row<M && col<N` | col loop |
| line B | write | `y` | `row*out_ld` | `row<M && lane==0` | 无 |

展开时保留整数类型与运算顺序。`size_t/uint64_t` 地址不能无证据缩成 32 位；有符号除法、负 stride、指针字节偏移与元素偏移必须区分。

### Step 7：恢复逻辑轴

对 `row*ld + col`，若 host 证据给出 shape `[M,N]`、stride `[ld,1]`，映射为 M/N。若只有 `f`：

```cpp
int row = f / N;
int col = f % N;
```

可由 `/`、`%` 恢复两个逻辑轴。若访问是 `indices[f]` 再访问 `x[indices[f]]`，则是间接寻址；不能把 `indices[f]` 当作规则轴 offset，也不能做连续地址假设。

同一个 CUDA thread 可覆盖多个逻辑轴：

```cpp
int lane = threadIdx.x;
int local_m = lane / TILE_N;
int local_n = lane % TILE_N;
```

此时 M/N 的 block size 分别来自 tile，而不是把 `blockDim.x` 同时直接写入两个轴。

### Step 8：判断 `has_loop`

`has_loop` 表示该逻辑轴的 tile 起点或元素位置是否由 kernel 内循环推进：

- 普通一次 launch 的 `blockIdx*tile + threadIdx`：`false`。
- `i += blockDim.x`：该轴为 `true`。
- `tile += gridDim.x` 的 grid-stride/persistent：由 flat tile 恢复出的所有轴为 `true`。
- 仅用于软件流水、但不推进逻辑轴的循环：不要错误标记。
- 外层循环遍历不同输出，内层循环做归约时，各轴分别判断。

### Step 9：判断归约轴

只有多个输入元素被组合成更少输出时才标记 `REDUCE`。需要识别：

- 每线程 accumulator 加/乘/max/min。
- `__shfl_*_sync` 的 warp 合并。
- shared-memory tree 与 cooperative groups reduce。
- atomic 合并到同一输出。
- 两阶段归约的 partial buffer 与第二 kernel。
- mma/wmma/乘加中的 contraction 轴。

单独出现 `fmaxf(x,0)`、atomic counter 作为调度、shared-memory transpose 都不自动构成 tensor 归约。softmax 的 W 轴即使在最后逐元素写回，因前序 max/sum 阶段发生聚合，仍属于全局 `reduced_axis_set`。

### Step 10：多访问合并与 JSON 校验

同一指针在多处访问时：

1. 轴集合必须由 host layout 和全部地址表达式共同证明。
2. 同一轴存在多个 tile 时，`block_size` 记录主要目标访问使用的配置，并在报告附表列出其他访问；不能悄悄丢失冲突。
3. 任一访问沿某轴循环，则该指针该轴的 `has_loop=true`。
4. 任一阶段沿某轴归约，则该指针相关逻辑轴按全局集合标为 `REDUCE`。
5. 数组字段长度、顺序和值域逐项检查，随后用标准 JSON parser 验证。

歧义不会通过编造值解决。无法确定时用 `null` 并解释其对 config 搜索的影响：未知 tile/stride 的轴不得生成需要连续性或对齐保证的候选。

## 示例

### 示例1：一维简单拆分

```cpp
__global__ void relu(const float* x, float* y, size_t n) {
    size_t i = size_t(blockIdx.x) * blockDim.x + threadIdx.x;
    if (i < n) y[i] = fmaxf(x[i], 0.0f);
}
```

`x/y` 均为一维连续地址；offset 是 `i`，由一次 launch 覆盖，没有 kernel 内循环：

```json
{"axis":["N"],"has_loop":[false],"axis_type":["PARALLEL"],"block_size":["blockDim.x"]}
```

### 示例2：简单一维拆分

```cpp
for (size_t i = size_t(blockIdx.x) * blockDim.x + threadIdx.x;
     i < n; i += size_t(gridDim.x) * blockDim.x) {
    y[i] = x[i] + 1.0f;
}
```

同一 N 轴由 `blockDim.x` 分块，并在 kernel 内按全 grid 步长继续处理，因此 `has_loop=true`。是否 persistent 只描述实现形态，不代表性能更优。

### 示例3：二维简单拆分

```cpp
__global__ void row_sum(const float* x, float* y, int M, int N) {
    int row = blockIdx.x;
    float acc = 0.0f;
    for (int col = threadIdx.x; col < N; col += blockDim.x)
        if (row < M) acc += x[row * N + col];
    for (int d = 16; d; d >>= 1)
        acc += __shfl_down_sync(0xffffffff, acc, d);
    if (threadIdx.x == 0 && row < M) y[row] = acc;
}
```

M 轴 offset=`blockIdx.x`、无循环、`PARALLEL`；N 轴 offset=`threadIdx.x + iteration*blockDim.x`、有循环且被 shuffle 聚合，故为 `REDUCE`。

### 示例4：多维flatten之后拆分

```cpp
int flat_tile = blockIdx.x;
int tile_h = flat_tile % tiles_h;
int tile_n = flat_tile / tiles_h;
int n = tile_n * TILE_N + threadIdx.y;
int h = tile_h * TILE_H + threadIdx.x;
if (n < N && h < H) y[n * H + h] = x[n * H + h];
```

先按 host 端 `grid.x=tiles_n*tiles_h` 还原 `tile_n/tile_h`。N/H 都是并行轴，tile 分别为 `TILE_N/TILE_H`；无 grid-stride loop 时两者 `has_loop=false`。

### 示例 5：pitch/非连续二维输入

```cpp
int row = blockIdx.y * blockDim.y + threadIdx.y;
int col = blockIdx.x * blockDim.x + threadIdx.x;
if (row < M && col < N)
    y[row * out_ld + col] = x[row * in_ld + col];
```

若 host 给出 `in_ld=160`、`out_ld=128`、shape `[32,128]`，两个 buffer 的 stride 分别为 `[160,1]` 与 `[128,1]`。汇总轴时不能把 input 错写为 contiguous；连续 vector candidate 还要检查每一行起点对齐。

### 示例 6：broadcast 读取

```cpp
int m = blockIdx.y * blockDim.y + threadIdx.y;
int n = blockIdx.x * blockDim.x + threadIdx.x;
if (m < M && n < N) y[m * N + n] = x[m * N + n] + bias[n];
```

`x/y` 轴为 M/N；`bias` 只有 N 轴。不要为了输出 shape 给 bias 人工增加 stride-zero M 轴，除非上游契约明确要求按 broadcast view 表达。

### 示例 7：多 kernel 歧义

若 wrapper 先运行 `partial_reduce<<<...>>>`，再运行 `final_reduce<<<...>>>`，两者都写归约结果：目标 kernel 必须由上游指定。若目标是完整算子性能而非单 kernel，kernel-info 可分别输出两个命名报告，但单个 JSON 不得混合两个 kernel 的形参。

## 调参约束

该信息只用于生成离线候选。具体 block/thread、register、shared-memory、occupancy 上限读取 `.claude/skills/share/cuda-c/references/platform-rules.md`。候选必须独立 nvcc 编译并保存 ptxas 资源信息，最终只冻结真实 RTX 3090 上通过门禁的单一配置。

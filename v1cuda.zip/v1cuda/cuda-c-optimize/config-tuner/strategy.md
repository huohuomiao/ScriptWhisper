# Config-Tuner

RTX 3090 的 SM、warp、register、shared memory、Grid 和 occupancy 约束统一读取 `.claude/skills/share/cuda-c/references/platform-rules.md`；本文件保留通用调参流程。

## 职责概述

自动化微调 CUDA Kernel 配置。通过优先级策略在 **10 次**尝试内锁定最优 block dimensions、tile、vector width、unroll 与 dynamic shared-memory 配置。

## Step 1：提取与汇总轴信息

从 kernel 定义、wrapper 函数中提取 kernel 中输入输出 tensor 的轴信息，供后续所有步骤使用。

**加载参考**：阅读 [`get-tensor-axis-info.md`](references/get-tensor-axis-info.md) 查看如何获取输入 tensor 轴信息。


**示例**：
```json
{
    "a":
    {
        "axis": ["B", "M", "N"],
        "axis_type": ["PARALLEL", "PARALLEL", "PARALLEL"],
        "stride": [4096, 256, 1],
        "block_size": ["BLOCK_B", "BLOCK_M", "BLOCK_N"],
        "has_loop": [true, true, true]
    },
    "b":
    {
        "axis": ["B", "N", "M"],
        "axis_type": ["PARALLEL", "PARALLEL", "PARALLEL"],
        "stride": [4096, 16, 1],
        "block_size": ["BLOCK_B", "BLOCK_N", "BLOCK_M"],
        "has_loop": [true, true, true]
    }
}
```

汇总结果如下：

```json
{
    "axis": ["B", "M", "N"],
    "axis_type": ["PARALLEL", "PARALLEL", "PARALLEL"],
    "stride": [4096, 1, 1],
    "block_size": ["BLOCK_B", "BLOCK_M", "BLOCK_N"],
    "has_loop": [true, true, true],
    "priority": [1, 0, 0]
}
```
**汇总过程分析**：两个tensor总共有B、M和N三个轴，首先分析名字为'B'的轴，提取a和b tensor中'B'轴的信息，axis_type，stride，block_size，has_loop均相同；其次提取a和b tensor中'M'轴的信息，'M'轴在a tensor中为第1维度，在b tensor中为第2维，按位置提取a和b tensor中的轴信息，汇总axis_type，block_size，has_loop均相同，但stride在a tensor中为256，在b tensor中为1，所以'M'轴最终的stride为1；'N'轴在a tensor中为第2维度，在b tensor中为第1维，按位置提取a和b tensor中的轴信息，汇总axis_type，block_size，has_loop均相同，但stride在a tensor中为1，在b tensor中为16，所以'N'轴最终的stride为1；根据优先级判断原则，'B'，'M'，'N'的axis_type均相同，判断stride，stride_b > stride_m == stride_n，所以B轴低于M轴和N轴，且M轴和N轴的优先级相同，优先级最高的priority设为0，B轴的优先级次之，priority值为1。

**Priority 排序**：`REDUCE` 轴优先于 `PARALLEL`；同类型下 `Stride` 越小优先级越高（Priority 值越小）。

## Step 2：确定 block、tile 与流水候选

**说明**：persistent loop 是 CUDA kernel 内由少量 block 通过 grid-stride 反复处理多个 tile 的形态。它可能减少调度开销，也可能因 register/shared-memory 压力限制驻留 block，必须同时测试非 persistent 候选。

分析 kernel 以及 Step 1 提取的 tensor 轴信息，获取以下信息：

- 计算瓶颈还是 io 瓶颈：分析 kernel 中是计算密集型还是 io 密集型，判断依据是 kernel 中如果包含**矩阵乘法**、**卷积**等运算为计算密集，其它类别如简单的 **elementwise**、**归约**等都属于 io 密集型
- 是否存在 persistent loop：对于 step1 中的汇总结果，**只对于 axis type 为 "PARALLEL" 的轴，has_loop 为 True 则说明存在 persistent loop**；否在不存在
- 是否有输入升位宽（如 half 到 float）、布局变换、shared-memory staging、warp shuffle 或 Tensor Core 路径

根据上述结果生成少量候选；具体合法上限和初始值必须来自 share，而不是本表硬编码：

| 瓶颈 | 优先候选维度 | 必查证据 |
|:---:|:---|:---|
| 计算 | tile、unroll、warp 数、Tensor Core staging | 指令吞吐、register/thread、eligible warps |
| 访存 | contiguous block 维、vector width、shared staging | DRAM/L2 吞吐、sector/request、bank conflict |
| 归约 | warp 数、每线程元素数、shuffle/shared 分层 | active warps、同步、atomic 冲突 |
| persistent | grid blocks、tile、非 persistent 对照 | resident blocks/SM、occupancy、spill |

## Step 3：Try 出最优配置

**BLOCK_SIZE 微调方向**：

- 访存未饱和且资源允许时，尝试扩大连续轴 tile 或 vector width，高优先级轴优先
- occupancy 被 register/shared memory 限制或出现 spill 时，缩小 tile/unroll、减少动态 shared memory，并加入非 persistent 对照

**BLOCK_SIZE 约束说明**：

- 仅可调整 host 侧 launch/config 常量和对应模板参数，不改变算法语义
- block 线程数、维度、shared memory 与 grid 必须满足 share 中的 CUDA 限制；warp 相关维度应合理对齐
- 对于 `stride=1` 的轴，按 share 的合并访存/对齐规则和真实地址保证生成 tile/vector 候选；本流程不硬编码字节阈值

按照以上说明，try 出最优配置，要求如下：

- 每个候选必须独立使用相同 nvcc flags 编译，保存 `-Xptxas=-v` 输出；不能用一次编译后的运行时伪配置代替离线候选
- 精度测试通过是底线，任何精度测试不通过的尝试都为无效尝试
- 最大尝试次数为 10 次
- 清理try最优配置过程中产生的临时文件

## Step 4：结果输出

将真实 RTX 3090 CUDA Event median 最低且通过统一门禁的配置冻结到源码；差异位于噪声区间时保留改动更小的输入。输出不得包含运行时 autotune 搜索器或未验证候选。

# Div-to-mul

## 功能概述
识别 CUDA Kernel 中的浮点除法，并在语义与精度允许时重构为“计算一次倒数，再复用乘法”（即 $x / y \rightarrow x \times (1.0 / y)$）。CUDA math/fast intrinsic 规则只读取 `.claude/skills/share/cuda-c/references/libdevice.md`；不得默认 `--use_fast_math` 或在除数逐元素变化时重复计算倒数。

---

## Step 1：场景识别 (Pattern Recognition)

**识别准则**：在 device 代码与 ptxas/NCU 热点中搜索浮点除法；整数除法、可能为零/NaN/Inf 的除数以及严格 IEEE 舍入依赖必须单独证明。

只要出现张量除法，即标记为潜在优化点，并按以下位置逻辑执行重构：
1. **优先位置**：若除数被广播（如 `y[:, None]`）或位于循环内。
2. **常规位置**：普通元素级除法。

---

## Step 2：优化执行策略

### ：代码重构重写
1. **插入倒数计算**：在除数维度发生**任何扩张动作之前**，插入 `inv_D = 1.0 / D`。
2. **变换广播对象**：将后续的除法替换为对 `inv_D` 执行广播后的乘法。

**重构示例：**
```cpp
// [Original]
float row_sum = block_reduce_sum(x);
float result = x_i / row_sum;

// [Refactored]
float row_sum = block_reduce_sum(x);
float inv_row_sum = 1.0f / row_sum;  // 每个输出行只计算一次
float result = x_i * inv_row_sum;
```
```cpp
// [Original]

float y = 0.5f * x * (1.0f + erff(x / 1.4142135623730951f));

// [Refactored]

constexpr float inv_constant = 0.7071067811865475f;
float y = 0.5f * x * (1.0f + erff(x * inv_constant));

```

---

## Step 3：运行与验证逻辑

运行生成的代码
- 若精度测试未通过，若运行优化 kernel 抛出错误或精度不正确，则根据错误信息进行调试修改，最多尝试 3 次，如果 3 次修正后仍抛出错误或无法满足精度要求，则输出原始代码
- 若精度测试通过，如果代码性能提升则保留该代码，若下降则回退回初始代码。
运行精度测试与性能测试对优化 kernel 进行验证。

# CUDA kernel 获取 tensor 轴信息详解

离线配置生成先按 `../../kernel-info/strategy.md` 静态提取 `.cu` 中目标 `__global__` kernel 的轴信息；禁止运行输入源码来猜测 shape。本文只说明候选生成所需的映射。

## 返回格式

```json
{
  "a": {
    "type": "input",
    "shape": [32, 128],
    "stride": [128, 1],
    "axis": ["M", "N"],
    "has_loop": [false, true],
    "axis_type": ["PARALLEL", "REDUCE"],
    "block_size": [null, "blockDim.x"]
  }
}
```

顶层 key 是 global-memory 指针形参；六个数组严格等长，未知值写 `null`。

## 分析步骤

### Step 1: 展开 offsets

从 host 侧 CUDA launch 建立实参到形参的绑定，再把每个 global address 展开为：

```text
base_ptr + Σ(offset_i * stride_i)
```

基础变量包括 `blockIdx`、`threadIdx`、`blockDim`、`gridDim`、shape/stride 参数、tile 常量和循环变量。必须排除 shared/local 地址。

### Step 2: 依次分析 offset_i

- 依赖 block/thread 且不聚合的轴为 `PARALLEL`。
- 依赖 C/C++ `for` 的轴展开 init/condition/step；循环推进该轴时 `has_loop=true`。
- 只有出现 shuffle/shared/atomic/accumulator 且多个元素确实合为更少输出，才标记 `REDUCE`。
- flatten 轴先用 `/`、`%` 还原逻辑维，再分别记录 tile。
- shape/stride 优先取 performance 首例，其次 accuracy 首例。

### Step 3：选择目标 kernel

枚举 `.cu` 中所有 `__global__` 定义与所有 host launch。建立以下表格后再选择：

| kernel | launch 次数 | 代表性用例是否执行 | config 来源 | 是否目标 |
| --- | ---: | --- | --- | --- |
| `kernel_a<T>` | 1 | 是 | `dim3` + template | 上游指定 |
| `kernel_b` | 1 | 是 | 固定 launch | 否 |

优先使用上游 code-gen/review 报告中的目标 kernel。没有指定时，只有唯一 launch 才可自动选取。多 kernel pipeline 不能把不同 kernel 的轴/config 混进同一搜索空间；应分别生成 `kernel_info.json` 或停止并请求明确目标。

### Step 4：绑定参数与测试规格

从 launch 的实参顺序绑定 kernel 形参，继续追踪 wrapper 形参与测试 allocation：

```text
kernel.x <- wrapper.d_input <- test.input_buffer
kernel.M <- wrapper.rows <- test.shape[0]
kernel.ld <- wrapper.leading_dim <- test.stride[0]
```

记录所有 performance/correctness 用例。JSON 中的具体 shape 优先取 performance 首例，但候选必须覆盖全部用例，尤其是：

- 小于一个 block/tile 的尺寸。
- 不能整除 tile/vector width 的尾部。
- 不同 dtype、stride、alignment。
- in-place 输入恢复与别名。

### Step 5：恢复真实 shape/stride

不能只看 `cudaMalloc(bytes)` 猜多维 shape。优先级为：

1. 明确 shape/stride/leading-dimension 参数。
2. wrapper API 契约与代表性测试常量。
3. contiguous 行主序推导（仅在确有 contiguous 证据时）。
4. 无法唯一确定则写 `null`。

`cudaMallocPitch`、padding、slice、transpose materialization 和 batch stride 都会改变物理布局。vector width 候选尤其依赖基址、行起点、元素数同时对齐，未知时不得生成 vector load/store。

### Step 6：逐条解析 global address

对每个读写点保留一行原始证据：

| 位置 | base | offset | guard | memory op | loop |
| --- | --- | --- | --- | --- | --- |
| L1 | `x` | `row*ld+col` | `row<M&&col<N` | scalar read | col tile |
| L2 | `y` | `row*out_ld` | `row<M&&lane==0` | scalar write | 无 |

地址表达式要递归展开 helper，但保持整数类型、指针元素单位和有符号性。不能把 byte offset 与 element offset 混用；不能因一个测例不溢出就把 `size_t` 降为 `int`。

### Step 7：映射 block/thread/tile

常见映射：

```cpp
int m = blockIdx.y * TILE_M + threadIdx.y;
int n = blockIdx.x * TILE_N + threadIdx.x;
```

M/N 是独立并行轴，tile 为 `TILE_M/TILE_N`。若 lane flatten：

```cpp
int lm = threadIdx.x / TILE_N;
int ln = threadIdx.x % TILE_N;
```

则必须从除法/取余恢复两个 tile 内轴，不能把 `blockDim.x` 同时当作两轴的逻辑 tile。

若同一 tile 内每线程处理多个元素：

```cpp
int n0 = blockIdx.x * TILE_N + threadIdx.x * VEC;
```

`TILE_N` 是轴 tile，`VEC` 是每线程元素/vector 候选，两者要分别进入配置空间。

### Step 8：识别循环覆盖与 persistent

- `n += blockDim.x`：N 轴 `has_loop=true`。
- `tile += gridDim.x`：由 flat tile 恢复出的轴均 `has_loop=true`。
- 循环只做软件流水而 tile 坐标不变：对应轴不因该循环变为 true。
- 一个 block 依次处理多输出 tile 是 persistent/grid-stride 形态，候选空间必须包含普通非 persistent 对照。

persistent 会延长 accumulator/地址变量活跃期，可能增大 register/thread 与 spill。轴信息只标记形态，是否保留由 ptxas/NCU/CUDA Event 决定。

### Step 9：识别归约

从完整数据流建立 `reduced_axis_set`：

- 循环内 accumulator。
- warp shuffle 或 cooperative-groups reduce。
- shared-memory tree。
- atomic 合并到同一输出。
- 两阶段 partial/final kernel。
- mma/wmma contraction。

单个 `fmaxf(v,0)` 是逐元素，不是 reduce。atomic 用于计数/调度也不自动是 tensor 归约。argmax/argmin 的 value/index 必须作为同一归约语义追踪。

### Step 10：形成调优轴摘要

在不丢失每 buffer 原始 JSON 的前提下生成摘要：

| 逻辑轴 | 类型 | 最小 stride | 当前 tile | 循环 | 可调项 | 风险 |
| --- | --- | ---: | --- | --- | --- | --- |
| M | PARALLEL | 128 | TILE_M | false | tile/grid.y | 尾块 |
| N | REDUCE | 1 | TILE_N | true | block.x/unroll | 累加顺序 |

摘要中的“可调项”必须能追踪到 host launch/template/`constexpr`。如果值由复杂宏或外部构建生成、无法产生独立源码候选，则标为不可调，不要伪造搜索器。

### Step 11：JSON 质量门禁

1. 标准 JSON 可解析，禁止注释、NaN、尾逗号。
2. 顶层只含目标 kernel 的 global 指针。
3. 每个对象只含约定字段，数组严格等长。
4. axis_type/type 值域合法。
5. shape/stride 中未知值写 JSON `null`。
6. 每个非 null block_size 都能指向源码表达式。
7. 报告附带目标 kernel/launch 证据与代表性用例。

未知/歧义字段不能用常见默认值填充。包含未知 stride、alignment 或 tile 的轴需要从候选空间中删除依赖该事实的配置。

## 示例

### 示例1：一维简单拆分

```cpp
size_t i = size_t(blockIdx.x) * blockDim.x + threadIdx.x;
if (i < n) y[i] = fmaxf(x[i], 0.0f);
```

N 轴为 `PARALLEL`，`block_size=blockDim.x`，无 kernel 内循环时 `has_loop=false`。

### 示例2：简单一维拆分

```cpp
for (size_t i = size_t(blockIdx.x) * blockDim.x + threadIdx.x;
     i < n; i += size_t(gridDim.x) * blockDim.x) y[i] = x[i];
```

N 轴仍为并行轴，但由循环继续覆盖，故 `has_loop=true`。persistent/grid-stride 只描述映射，不自动成为首选配置。

### 示例3：二维简单拆分

```cpp
int row = blockIdx.x;
float acc = 0.0f;
for (int col = threadIdx.x; col < N; col += blockDim.x)
    if (row < M) acc += x[row * N + col];
for (int d = 16; d; d >>= 1)
    acc += __shfl_down_sync(0xffffffff, acc, d);
```

M 轴由 block 映射，`PARALLEL/has_loop=false`；N 轴由 lane 循环覆盖并经 shuffle 合并，`REDUCE/has_loop=true`。

### 示例4：多维flatten之后拆分

```cpp
int tile_h = blockIdx.x % tiles_h;
int tile_n = blockIdx.x / tiles_h;
int n = tile_n * TILE_N + threadIdx.y;
int h = tile_h * TILE_H + threadIdx.x;
```

按 host 的 `grid.x=tiles_n*tiles_h` 还原 N/H。两轴均为并行轴，tile 分别为 `TILE_N/TILE_H`。

### 示例 5：二维非连续布局

```cpp
int m = blockIdx.y * blockDim.y + threadIdx.y;
int n = blockIdx.x * blockDim.x + threadIdx.x;
if (m < M && n < N) y[m * out_ld + n] = x[m * in_ld + n];
```

代表性 shape `[32,128]`，若 `in_ld=160/out_ld=128`，input/output stride 必须分别记录 `[160,1]` 与 `[128,1]`。合并轴时可用最小 stride 判断连续轴优先级，但 vector 候选仍要对每个 buffer 单独证明行起点对齐。

### 示例 6：broadcast bias

```cpp
y[m * N + n] = x[m * N + n] + bias[n];
```

`x/y` 有 M/N 两轴，bias 只有 N 轴。摘要时 N stride 为 1；不能给 bias 虚构 M tile，从而错误扩大 bias 的搜索维度。

### 示例 7：间接寻址

```cpp
int src = indices[i];
y[i] = x[src];
```

`y/indices` 的 I 轴可静态恢复；`x` 访问由数据决定，无法声明连续 stride/tile。对 x 的 vector/coalescing 候选应禁用，除非额外契约证明 indices 模式。

## 候选约束

轴信息只决定搜索维度，不决定硬件数值。合法 block、register、shared-memory、occupancy 阈值读取 `.claude/skills/share/cuda-c/references/platform-rules.md`。每个候选必须离线 nvcc 编译并保存 ptxas 资源信息，最终源码只冻结真实 RTX 3090 上通过统一门禁的一个配置。

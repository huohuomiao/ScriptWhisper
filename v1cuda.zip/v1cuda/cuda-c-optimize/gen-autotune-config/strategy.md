# CUDA C/C++ 离线配置自动生成（RTX 3090 / sm_86）

设备限制、默认候选范围与数学/编译约束读取 `.claude/skills/share/cuda-c/references/platform-rules.md`。本策略只保留候选生成、独立编译、统一验证、选择和冻结流程。

## 职责概述

为 CUDA kernel 生成少量可归因的 block/tile/vector/unroll/shared-memory 候选，对每个候选使用相同 nvcc 和测试口径离线编译运行，最终在源码中只保留一个经过真实 RTX 3090 验证的最优配置。禁止生成运行时 autotuner，禁止把未测或在其他 GPU 上测得的配置标为最优。

## 工作流程

1. 检查工作目录中的 `input.cu`、EnvConfig、baseline 结果与 `kernel_info.json`。
2. 若为 `static_only` 或目标未确认是 RTX 3090/sm_86，原样输出输入并记录 `not_measured`。
3. 提取可调配置、瓶颈与资源信息，建立有限候选集合。
4. 每个候选独立生成源码、编译、执行 correctness/safety/benchmark。
5. 按统一门禁选择 best-so-far，并把单一配置冻结到 `cuda_optimized.cu`。

## 步骤

### Step 1：提取必要信息

#### 提取 tensor 轴信息

读取 [`get-tensor-axis-info.md`](references/get-tensor-axis-info.md) 与本轮 `kernel_info.json`。汇总字段仍为：

```json
{
  "axis": ["B", "M", "N", "K"],
  "axis_type": ["PARALLEL", "PARALLEL", "PARALLEL", "REDUCE"],
  "stride": [4096, 256, 1, 1],
  "block_size": [null, "TILE_M", "TILE_N", "TILE_K"],
  "has_loop": [false, false, false, true],
  "priority": [2, 1, 0, 0]
}
```

归约轴优先；同类型下 stride 越小优先级越高。多 buffer 对同一轴的 stride 取最有利于连续访问的事实，但报告必须保留每个 buffer 的原始布局，不能因汇总丢失非连续或 broadcast 风险。

#### 提取当前 CUDA 配置

从源码和 host launch 静态提取：

- `dim3 grid/block`、template/`constexpr` tile、vector width、unroll。
- static/dynamic shared memory、同步点、warp shuffle、atomic。
- grid-stride/persistent loop、每线程 accumulator 数量。
- 完整 nvcc 命令与 `-Xptxas=-v` 的 register/thread、shared、spill。
- baseline CUDA Event median/p20/p80、correctness 和 safety 结果。

若无法定位唯一目标 kernel 或 config 的数据流，停止本策略并回退，不能同时改多个 kernel 猜测结果。

#### 提取测试数据规格

固定 baseline 使用的全部 shape、dtype、stride、seed、stream、warmup、repeat、容差和参考实现。每个候选必须使用同一组数据；in-place 算子每次运行前恢复输入，恢复时间不计入 kernel event，但端到端时间可另列。

### Step 2：生成离线候选

#### 2.1 确定调优维度

只选择能由源码常量或 host launch 单独控制的维度：

- `block.x/y/z` 与每 block warp 数。
- 并行 tile、归约 tile、每线程元素数。
- 合法且对齐的 vector width。
- loop unroll、software pipeline/shared staging 层数。
- dynamic shared-memory 字节数。
- grid block 数；persistent kernel 必须包含非 persistent 对照。

不要在一次候选中同时改变算法、精度、编译器 fast-math 和 launch。Tensor Core、split-K、两阶段归约等架构变化属于独立策略候选，不能混入普通 config 搜索。

#### 2.2 根据资源裁剪

具体数值上限从 share 读取；每个候选在运行前至少满足：

1. block/thread、维度和 shared-memory 合法。
2. 连续轴访问保持合并，vector 类型满足地址和长度对齐。
3. 归约线程数与 shuffle mask 正确，尾部 lane 不读取无效值。
4. ptxas 没有资源超限；register/thread 和 spill 必须记录而非估算。
5. persistent 候选根据实际 occupancy/resident-block 证据裁剪；不能以 SM 数直接等同最佳 grid。

寄存器压力或 spill 可能使更大 tile 更慢。若 baseline 已表现为高 register + spill + 低 occupancy，优先加入缩小 tile/unroll、减少 accumulator、非 persistent 的候选；不要继续只调低并发 grid。

#### 2.3 生成候选源码

每个候选放在独立目录，保留父源码哈希和唯一变化：

```text
candidates/<id>/
├── candidate.cu
├── config.json
├── compile.stdout.txt
├── compile.stderr.txt
├── correctness.json
├── benchmark.json
└── result.json
```

`config.json` 至少记录 block、grid、tile、vector、unroll、shared bytes、compile flags、parent hash。候选使用相同：

```bash
nvcc -std=c++17 -O3 -lineinfo -arch=sm_86 -Xptxas=-v candidate.cu -o candidate
```

若上游 baseline 带有额外必须的 include/link flags，则完整沿用。`--use_fast_math`、`-maxrregcount`、LTO 等不是默认配置；只有独立策略明确要求时才能形成单独候选。

### Step 3：编译、验证与测量

按候选串行执行，最多测试由调用方预算允许且不超过有限集合的配置；禁止并发 benchmark 互相污染。

1. 编译并验证生成的是目标 `sm_86` 路径，保存 ptxas 资源输出。
2. 运行所有 correctness 用例，不放宽 atol/rtol；检查 CUDA API、launch 与同步错误。
3. 若 baseline 已有 Compute Sanitizer 门禁，候选不得新增问题。
4. 用相同 stream、warmup/repeat 和 CUDA Event 统计 median/p20/p80。
5. 性能下降、差异仅为噪声而代码更复杂、资源明显恶化或任一门禁失败时回退。

NVCC/driver/NCU 不可用属于环境失败，不得尝试修改 kernel 修复。真实设备不是 RTX 3090 时只生成静态候选计划，不产生“最佳配置”。

### Step 4：生成单一最优配置

在所有通过门禁的候选与输入 baseline 中选择 `median_ms` 最低的 best-so-far。置信区间重叠时依次选择：修改更小、spill 更少、occupancy 更稳定、资源更低者。

将选中配置冻结在 host launch/`constexpr`/template 中，删除候选搜索器和未选配置，生成：

- `{工作目录}/cuda_optimized.cu`
- `{工作目录}/cuda_optimized.md`
- `{工作目录}/result.json`

若无候选明确优于输入，`cuda_optimized.cu` 必须与 `input.cu` 逐字一致。报告列出每个候选的源码哈希、完整编译命令、正确性、安全性、CUDA Event 分布、ptxas 资源和 keep/revert 决策。

## 关键约束与边界条件

| 项目 | 约束 |
| --- | --- |
| 目标 | 仅真实 Linux RTX 3090 / sm_86 动态验证 |
| 配置方式 | 离线独立 nvcc 编译；最终冻结一个配置 |
| 计时 | CUDA Event；相同 stream/warmup/repeat；使用分布而非单次值 |
| 正确性 | 不放宽原容差；in-place 每轮恢复输入 |
| 资源 | ptxas + NCU 实测；阈值只读 share |
| 回退 | 未测、失败、回退或噪声内复杂化均输出输入源码 |

本策略不会承诺任何固定 block/tile 在 3090 上最优；最终配置必须由本次目标环境的真实证据决定。

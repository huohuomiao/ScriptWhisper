# 多维轴 Flatten 分析例子

## 示例代码

```cpp
template<int TILE_N, int TILE_H, int TILE_W>
__global__ void relu3d(const float* input, float* output,
                       int N, int H, int W, int tiles_h, int tiles_w,
                       uint64_t total_tiles) {
    for (uint64_t flat = blockIdx.x; flat < total_tiles; flat += gridDim.x) {
        int tw = flat % tiles_w;
        uint64_t q = flat / tiles_w;
        int th = q % tiles_h;
        int tn = q / tiles_h;
        int n = tn * TILE_N + threadIdx.z;
        int h = th * TILE_H + threadIdx.y;
        int w = tw * TILE_W + threadIdx.x;
        if (n < N && h < H && w < W) {
            size_t i = (size_t(n) * H + h) * W + w;
            output[i] = fmaxf(input[i], 0.0f);
        }
    }
}
```

代表性测例为 contiguous `[32,64,256]`，故 input/output 的 shape 都是 `[32,64,256]`，stride 都是 `[16384,256,1]`。

## Step 3 地址解析

`flat` 按 W tile 最快、H tile 次之、N tile 最慢展开：

| 轴 | tile index | element offset | stride | loop |
| --- | --- | --- | ---: | --- |
| N | `flat / (tiles_w*tiles_h)` | `tn*TILE_N+threadIdx.z` | 16384 | grid-stride flat loop |
| H | `(flat/tiles_w)%tiles_h` | `th*TILE_H+threadIdx.y` | 256 | grid-stride flat loop |
| W | `flat%tiles_w` | `tw*TILE_W+threadIdx.x` | 1 | grid-stride flat loop |

## Step 4 block_size 与 has_loop

三个轴由同一个 `flat += gridDim.x` 循环选择 tile，因此 `has_loop` 均为 true；block size 分别为 `TILE_N/TILE_H/TILE_W`。threadIdx 只是 tile 内坐标，不单独形成另一逻辑轴。

## Step 5 reduced_axis_set

只有逐元素 `fmaxf`，没有把多个逻辑元素聚合为更少输出，因此集合为空，三轴均为 `PARALLEL`。

## 输出

```json
{
  "input": {
    "type": "input",
    "shape": [32, 64, 256],
    "stride": [16384, 256, 1],
    "axis": ["N", "H", "W"],
    "has_loop": [true, true, true],
    "axis_type": ["PARALLEL", "PARALLEL", "PARALLEL"],
    "block_size": ["TILE_N", "TILE_H", "TILE_W"]
  },
  "output": {
    "type": "output",
    "shape": [32, 64, 256],
    "stride": [16384, 256, 1],
    "axis": ["N", "H", "W"],
    "has_loop": [true, true, true],
    "axis_type": ["PARALLEL", "PARALLEL", "PARALLEL"],
    "block_size": ["TILE_N", "TILE_H", "TILE_W"]
  }
}
```

## Launch 绑定

```cpp
int tiles_n = ceil_div(N, TILE_N);
int tiles_h = ceil_div(H, TILE_H);
int tiles_w = ceil_div(W, TILE_W);
uint64_t total = uint64_t(tiles_n) * tiles_h * tiles_w;
dim3 block(TILE_W, TILE_H, TILE_N);
dim3 grid(profile_grid);  // 普通或 grid-stride 候选
relu3d<TILE_N,TILE_H,TILE_W>
    <<<grid, block, 0, stream>>>(input, output, N, H, W,
                                tiles_h, tiles_w, total);
```

形参绑定：`input/output` 为 global 指针；N/H/W 为 shape；`tiles_h/tiles_w/total` 为索引辅助标量。只有两个指针进入 JSON 顶层。

## Flatten 顺序证明

定义：

```text
flat = (tn*tiles_h + th)*tiles_w + tw
```

代码先 `%tiles_w` 得 tw，再 `/tiles_w % tiles_h` 得 th，剩余商得 tn，与定义一致。若 host 计算使用另一顺序，即使 total 相同也会访问错误 tile；因此 kernel-info 必须记录商余数公式，而不只记录“flatten”。

`flat += gridDim.x` 使同一 block 遍历多个 tile。由于每个 flat 的商余数唯一，tile 不重不漏；block 内 threadIdx 再覆盖 tile 内元素。

## Block Size 细化

`dim3 block(TILE_W,TILE_H,TILE_N)` 时：

- W tile 由 `threadIdx.x` 覆盖，block_size=`TILE_W`。
- H tile 由 `threadIdx.y` 覆盖，block_size=`TILE_H`。
- N tile 由 `threadIdx.z` 覆盖，block_size=`TILE_N`。

若实际实现把三轴 flatten 到一维 lane，则需从 lane 的 `/`、`%` 恢复 tile；不能照搬上述 thread 维映射。

## 访问分类

`input[i]` 是 read，`output[i]` 是 write。`fmaxf` 只组合单个输入与常数 0，不减少元素数，所以不是 reduce。global 地址 i 同时包含 N/H/W，stride 由代表性 contiguous 测例确定。

## 歧义处理

- 若 `profile_grid` 来源不可追踪，has_loop 仍可由 device 的 for 确定，但不能生成 grid 数值候选。
- 若 input/output 有 pitch 参数，stride 必须改用实际参数。
- 若 `TILE_*` 是模板实例但 launch 不可见，block_size 可记录符号名，具体数值未知。
- 若多个 relu3d 实例用于不同 dtype/shape，应按目标 launch 分别分析。

## 校验清单

1. JSON 可解析且只有 input/output 顶层项。
2. shape/stride/axis 数组长度为 3。
3. 三轴 has_loop 均来自 flat grid-stride，而非 thread 内元素循环。
4. reduced_axis_set 为空。
5. 64 位 total/address 不被错误缩窄。

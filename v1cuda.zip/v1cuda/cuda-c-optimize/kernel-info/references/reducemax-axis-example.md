# Reducemax 轴分析例子

本例展示 2D 输入 `[M, N]` 沿 `dim=1`（N 轴）分块求 max。M 轴无分块参数，N 轴使用 `BLOCK_N` 分块 + for loop 做 tiled reduction，输出为 `[M]`。

## 示例代码

```cpp
constexpr int BLOCK_N = 32;

__global__ void max_kernel(const float* x_ptr, float* y_ptr, int M, int N) {
    int row = blockIdx.x;
    int lane = threadIdx.x;
    float acc_val = -CUDART_INF_F;
    for (int n = lane; n < N; n += BLOCK_N) {
        if (row < M) acc_val = fmaxf(acc_val, x_ptr[row * N + n]);
    }
    for (int d = 16; d > 0; d >>= 1)
        acc_val = fmaxf(acc_val, __shfl_down_sync(0xffffffff, acc_val, d));
    if (row < M && lane == 0) y_ptr[row] = acc_val;
}

void max_wrapper(const float* input, float* output, int M, int N,
                 cudaStream_t stream) {
    max_kernel<<<dim3(M), dim3(BLOCK_N), 0, stream>>>(input, output, M, N);
}
```

## Launch 与代表性规格

```cpp
constexpr int BLOCK_N = 32;
dim3 block(BLOCK_N);
dim3 grid(M);
max_kernel<<<grid, block, 0, stream>>>(input, output, M, N);
```

代表性规格 M=32、N=128。`BLOCK_N` 是 thread/block tile，不是 N 的 shape；N 由标量形参和测试共同确定。

## 完整访问表

| 位置 | base | 读写 | offset | guard | loop |
| --- | --- | --- | --- | --- | --- |
| loop load | `x_ptr` | read | `row*N+n` | `row<M && n<N` | `n+=BLOCK_N` |
| final store | `y_ptr` | write | `row` | `row<M && lane==0` | 无 |

M 轴在 load/store 间一致；N 只存在于 input。输出 y shape `[M]` 不应人为添加一个已归约的 N 维。

## Reduce 证明

每个 lane 对序列 `lane + q*BLOCK_N` 做 local max；这些序列按模 BLOCK_N 划分 `[0,N)`。shuffle 再把各 lane local max 合成一个值，由 lane 0 写 y[row]。因此 N 的多个元素合为一个输出，N 是 REDUCE。

`fmaxf`/shuffle 的具体 NaN 与 signed-zero 行为必须匹配实际 helper；轴分类不代表数值语义已经验证。

## `block_size=null` 的含义

M 由一个 block 对应一个 row，没有名为 BLOCK_M 的 block 内 M tile，因此 JSON 写 null。这不表示 M 没有并行映射；`axis_type=PARALLEL` 和 `blockIdx.x` 地址表已经描述其并行性。

N 的 block_size 记录 `BLOCK_N`，has_loop=true。若实际 blockDim.x 运行时可变而没有命名常量，可记录 `blockDim.x`。

## 多 Kernel 情况

若 max 采用 partial/final 两阶段：

- 对 partial kernel，输出指针 shape 可能是 `[M,num_partials]`。
- 对 final kernel，输入 partial 的第二轴为 REDUCE。
- 不把两个 kernel 的指针混入一个 JSON；目标由上游指定。

## 校验

1. JSON 顶层仅 x_ptr/y_ptr。
2. x 的六个数组长度 2，y 的长度 1。
3. M/PARALLEL、N/REDUCE 与地址/计算一致。
4. 代表性 shape/stride 有 host 证据。
5. N 尾部和 M=0/1 行为不靠运行猜测。
6. 输出文档 fence 与 JSON 均可解析。

代表性测例：

```text
shape=[32, 128], dtype=float32, contiguous=true
```

根据 wrapper 中的 kernel launch，`x_ptr` 绑定到 wrapper 的 `input` 参数；代表性测例为 contiguous `[32,128]`，因此真实 `shape` 是 `[32,128]`，真实 `stride` 是 `[128,1]`。

`y_ptr` 绑定到 wrapper 分配的连续 `M` 元素输出 buffer，真实 `shape` 是 `[32]`，真实 `stride` 是 `[1]`。
## Step 3 地址解析

`x_ptr` 的完整地址计算为：

```cpp
x_ptr + row * N + n

= x_ptr
  + blockIdx.x * N
  + (threadIdx.x + iteration * BLOCK_N) * 1
```

根据最后一层展开式，可以得到 `x_ptr` 的地址解析表：

| 逻辑轴 | offset | stride | loop |
|--------|--------|--------|------|
| `M` | `blockIdx.x` | `N` | 无 |
| `N` | `threadIdx.x + iteration * BLOCK_N` | `1` | `for (n=threadIdx.x; n<N; n+=BLOCK_N)` |

M 轴的 offset 为标量 `blockIdx.x`，无 for loop 依赖。N 轴由 lane 起始并按 `BLOCK_N` 循环推进。

`y_ptr` 的完整地址计算为：

```cpp
y_ptr + row

= y_ptr + blockIdx.x * 1
```

| 逻辑轴 | offset | stride | loop |
|--------|--------|--------|------|
| `M` | `blockIdx.x` | `1` | 无 |

## Step 4 block_size 与 has_loop

对 `x_ptr`：

| 逻辑轴 | block_size | has_loop | 判断依据 |
|--------|------------|----------|----------|
| `M` | `null` | `false` | 由 block 映射单个输出行，无 loop 依赖 |
| `N` | `BLOCK_N` | `true` | 由 `threadIdx.x` 覆盖 tile，并按 `BLOCK_N` 循环推进 |

对 `y_ptr`：

| 逻辑轴 | block_size | has_loop | 判断依据 |
|--------|------------|----------|----------|
| `M` | `null` | `false` | 由 block 映射单个输出行，无 loop 依赖 |

## Step 5 reduced_axis_set

kernel 沿 N 轴分块求 max：每个 lane 循环累积局部 max，再由 `__shfl_down_sync` 合并为标量：

```text
reduced_axis_set = {"N"}
```
## 输出

```json
{
  "x_ptr": {
    "type": "input",
    "shape": [32, 128],
    "stride": [128, 1],
    "axis": ["M", "N"],
    "has_loop": [false, true],
    "axis_type": ["PARALLEL", "REDUCE"],
    "block_size": [null, "BLOCK_N"]
  },
  "y_ptr": {
    "type": "output",
    "shape": [32],
    "stride": [1],
    "axis": ["M"],
    "has_loop": [false],
    "axis_type": ["PARALLEL"],
    "block_size": [null]
  }
}
```

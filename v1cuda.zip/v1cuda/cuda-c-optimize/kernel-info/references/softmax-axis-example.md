# Softmax 轴分析例子

本例处理 contiguous `[N,H,W]`，每个 block 对一个 `(n,h)` 行沿 W 做 softmax。

## 示例代码

```cpp
__global__ void softmax_w(const float* x, float* y, int N, int H, int W) {
    int row = blockIdx.x;
    int n = row / H;
    int h = row % H;
    float local_max = -CUDART_INF_F;
    for (int w = threadIdx.x; w < W; w += blockDim.x)
        local_max = fmaxf(local_max, x[(n * H + h) * W + w]);
    float max_v = block_reduce_max(local_max);
    float local_sum = 0.0f;
    for (int w = threadIdx.x; w < W; w += blockDim.x)
        local_sum += expf(x[(n * H + h) * W + w] - max_v);
    float sum_v = block_reduce_sum(local_sum);
    for (int w = threadIdx.x; w < W; w += blockDim.x)
        y[(n * H + h) * W + w] = expf(x[(n * H + h) * W + w] - max_v) / sum_v;
}
```

## Launch 与形参绑定

```cpp
dim3 block(BLOCK);
dim3 grid(uint64_t(N) * H);
softmax_w<<<grid, block, shared_bytes, stream>>>(x, y, N, H, W);
```

`x/y` 为 global 指针，N/H/W 为 shape。blockIdx.x flatten N/H 输出行，threadIdx.x 沿 W 协作。`shared_bytes` 只用于 block reduce，不进入 tensor JSON。

## 三阶段访问表

| 阶段 | 指针 | 访问 | offset | loop | 聚合 |
| --- | --- | --- | --- | --- | --- |
| max | x | read | `(n*H+h)*W+w` | W loop | block max |
| sum | x | read | 同上 | W loop | block sum |
| normalize | x | read | 同上 | W loop | 无新增归约 |
| normalize | y | write | 同上 | W loop | 一对一写 |

虽然 y 写入是逐元素，y 的逻辑 W 轴仍与算子归约轴集合相关；该 schema 将 axis_type 表示 kernel 的全局逻辑语义，而非单条 store 是否聚合。报告要说明这一选择，避免调用方误把 y 的 W 当成完全独立轴调 tile。

## N/H Flatten 恢复

```text
row = n*H+h
n = row/H
h = row%H
```

对 `row in [0,N*H)` 商余数唯一。N/H 不由 kernel 内循环推进，故 has_loop=false；它们共享同一 block id，但没有命名 tile 常量时 block_size=null。

## W 归约识别

W 满足两种证据：

1. 每个线程用 `w += blockDim.x` 遍历同一行的不同元素。
2. max/sum helper 将各 lane partial 合为一个标量，并被整行 normalization 使用。

因此 `reduced_axis_set={W}`。不能仅看最后一次逐元素 store 得出 PARALLEL。

## Helper 展开要求

`block_reduce_max/sum` 必须展开或由受信契约确认：

- 是否使用 shuffle/shared。
- 是否所有线程一致到达同步。
- inactive lane 的单位元。
- max 的 NaN/signed-zero 规则。
- accumulator dtype。

helper 不可读取时，仍可由其签名/调用推测“可能归约”，但最终 axis_type 应标记歧义并停止依赖精确归约结构的优化。

## 多次读取与 Retiling 风险

x 在 max、sum、normalize 三次读取。它们地址相同但中间计算依赖不同阶段结果，不能简单跨 `__syncthreads()`/block reduce 全部复用在寄存器中；那可能需要保存整行并造成高 register/shared 压力。kernel-info 只报告地址轴，不自动提出冗余 load 消除。

## 验证用例

- W=1、小于 warp、非 warp 倍数、大于 block。
- N/H 为 1 和多行。
- 非 contiguous stride（若 API 支持）。
- 大幅值、Inf、NaN，匹配 reference 行为。
- block/shared 配置合法且 ptxas 资源可记录。

JSON 中的 `[32,64,256]` 只是代表性首例；候选必须验证整个输入测试集合。

代表性输入 `[32,64,256]` 的 stride 为 `[16384,256,1]`。

## Step 3 地址解析

| 轴 | offset | stride | loop |
| --- | --- | ---: | --- |
| N | `blockIdx.x / H` | 16384 | 无 |
| H | `blockIdx.x % H` | 256 | 无 |
| W | `threadIdx.x + iteration*blockDim.x` | 1 | 三个 W 循环 |

## Step 4 block_size 与 has_loop

N/H 共同由一维 block id flatten，按一个输出行映射，`has_loop=false`；无独立编译期 tile 时 block_size 可写 `null`。W 由 `blockDim.x` 线程协作并循环覆盖，`block_size=blockDim.x`、`has_loop=true`。

## Step 5 reduced_axis_set

max 与 sum 两次 block reduce 都沿 W 合并多个元素，因此 `reduced_axis_set={"W"}`。第三个循环虽逐元素写回，也不改变 W 已属于归约轴的全局判断。

## 输出

```json
{
  "x": {
    "type": "input",
    "shape": [32, 64, 256],
    "stride": [16384, 256, 1],
    "axis": ["N", "H", "W"],
    "has_loop": [false, false, true],
    "axis_type": ["PARALLEL", "PARALLEL", "REDUCE"],
    "block_size": [null, null, "blockDim.x"]
  },
  "y": {
    "type": "output",
    "shape": [32, 64, 256],
    "stride": [16384, 256, 1],
    "axis": ["N", "H", "W"],
    "has_loop": [false, false, true],
    "axis_type": ["PARALLEL", "PARALLEL", "REDUCE"],
    "block_size": [null, null, "blockDim.x"]
  }
}
```

## 情况 C：单维度 Grid，加核心数上限

原始 CUDA 映射通常是一个线程处理一个元素：

```cpp
__global__ void kernel(const float* x, float* y, size_t n) {
    size_t i = size_t(blockIdx.x) * blockDim.x + threadIdx.x;
    if (i < n) y[i] = x[i] * 2.0f;
}

dim3 block(BLOCK);
dim3 grid((n + BLOCK - 1) / BLOCK);
kernel<<<grid, block, 0, stream>>>(x, y, n);
```

## 优化分析步骤 (Modified Analysis)

1. 确认每个输出元素独立、无跨 block 同步和唯一写入风险。
2. 普通 grid 保持为首个候选；不要将 grid 无条件裁剪为 SM 数。
3. 只有真实 profile 支持任务复用时，增加 grid-stride 候选：

```cpp
__global__ void kernel_stride(const float* x, float* y, size_t n) {
    for (size_t i = size_t(blockIdx.x) * blockDim.x + threadIdx.x;
         i < n; i += size_t(gridDim.x) * blockDim.x)
        y[i] = x[i] * 2.0f;
}
```

4. grid-stride 的 `grid.x` 作为离线候选测试；合法范围与设备事实读取 share。
5. 比较 ptxas register/spill、NCU occupancy 与 CUDA Event 分布。若 persistent/grid-stride 造成驻留 block 下降或 spill，则保留普通 grid。
6. correctness、CUDA 错误或性能门禁失败时原样回退。

## 完整 Before/After

### Before：普通一线程一元素

```cpp
#include <cuda_runtime.h>
#include <cstddef>

__global__ void scale_before(const float* __restrict__ x,
                             float* __restrict__ y,
                             size_t n, float alpha) {
    size_t i = size_t(blockIdx.x) * blockDim.x + threadIdx.x;
    if (i < n) y[i] = alpha * x[i];
}

void launch_before(const float* x, float* y, size_t n, float alpha,
                   cudaStream_t stream) {
    constexpr unsigned BLOCK = 256; // 示例现有值，不代表推荐值
    unsigned grid = static_cast<unsigned>((n + BLOCK - 1) / BLOCK);
    scale_before<<<grid, BLOCK, 0, stream>>>(x, y, n, alpha);
    CUDA_CHECK(cudaGetLastError());
}
```

### After：仅作为独立 grid-stride 候选

```cpp
__global__ void scale_stride(const float* __restrict__ x,
                             float* __restrict__ y,
                             size_t n, float alpha) {
    size_t first = size_t(blockIdx.x) * blockDim.x + threadIdx.x;
    size_t step = size_t(gridDim.x) * blockDim.x;
    for (size_t i = first; i < n; i += step)
        y[i] = alpha * x[i];
}

void launch_candidate(const float* x, float* y, size_t n, float alpha,
                      cudaStream_t stream, unsigned candidate_grid) {
    constexpr unsigned BLOCK = 256;
    scale_stride<<<candidate_grid, BLOCK, 0, stream>>>(x, y, n, alpha);
    CUDA_CHECK(cudaGetLastError());
}
```

`candidate_grid` 来自离线候选，不在 kernel 中读取硬编码设备 SM 数。最终源码冻结一个经验证的值或回退原 launch。

## 覆盖证明

令 `T=gridDim.x*blockDim.x`，每个线程初值 `i0=blockIdx.x*blockDim.x+threadIdx.x`，因此 `i0` 在 `[0,T)` 唯一。线程访问集合为：

```text
S(i0) = { i0 + q*T | q >= 0 且 i0+q*T < n }
```

任意 `i in [0,n)` 可唯一写为 `i=(i mod T)+floor(i/T)*T`，故至少被一个线程访问；不同 `i0` 的余数不同，集合不交叉，故无重复写。该证明依赖 `T>0` 与乘法不溢出，host 必须拒绝 zero grid，device 使用足够宽的 `size_t`。

## 不适用场景

- 访问顺序影响随机数状态或浮点 atomic 顺序。
- 每个 block 对应唯一 shared-memory 任务，不能跨 tile 复用同一初始化。
- kernel 含 cooperative grid synchronization。
- 普通 grid 已足够并行，而 grid-stride 增加变量活跃期/分支。
- `candidate_grid` 太小导致 occupancy/latency hiding 下降。

## Launch 与边界验证

逐一测试：`n=1`、`n<BLOCK`、`n=BLOCK±1`、非整除大尺寸和最大生产尺寸。检查：

1. `grid>0`，转换到 `dim3.x` 前范围合法。
2. `size_t step` 无 32 位溢出。
3. 输入输出可能 alias 时与原语义相同。
4. 同一 stream、相同错误检查和同步点。
5. baseline/candidate 的编译 flags 完全一致。

## 性能选择

保存 CUDA Event median/p20/p80、ptxas register/spill、NCU active/eligible warps 与 memory throughput。若两者区间重叠，保留普通 grid；若 grid-stride 更快，也必须确认不是因不同 warmup、stream 或输入导致。

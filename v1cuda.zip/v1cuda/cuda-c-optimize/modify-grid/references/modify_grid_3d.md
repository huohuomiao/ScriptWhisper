# CUDA Kernel 多维 Grid 优化示例

## 初始代码

```cpp
__global__ void kernel3d(const float* x, float* y, int X, int Y, int Z) {
    int ix = blockIdx.x * blockDim.x + threadIdx.x;
    int iy = blockIdx.y * blockDim.y + threadIdx.y;
    int iz = blockIdx.z;
    if (ix < X && iy < Y && iz < Z)
        y[(iz * Y + iy) * X + ix] = x[(iz * Y + iy) * X + ix];
}

dim3 block(BX, BY);
dim3 grid(ceil_div(X, BX), ceil_div(Y, BY), Z);
```

CUDA 原生三维 grid 是合法基线，不能仅为“一维更简单”而修改。

## 优化分析步骤 (Modified Analysis)

当 profile 显示映射/调度问题且乘积满足 grid 限制时，可生成 flatten 候选：

```cpp
__global__ void kernel_flat(const float* x, float* y, int X, int Y, int Z,
                            int tiles_x, int tiles_y, uint64_t total) {
    for (uint64_t flat = blockIdx.x; flat < total; flat += gridDim.x) {
        int tx = flat % tiles_x;
        uint64_t q = flat / tiles_x;
        int ty = q % tiles_y;
        int iz = q / tiles_y;
        int ix = tx * blockDim.x + threadIdx.x;
        int iy = ty * blockDim.y + threadIdx.y;
        if (ix < X && iy < Y && iz < Z)
            y[(iz * Y + iy) * X + ix] = x[(iz * Y + iy) * X + ix];
    }
}
```

Host 使用 64 位计算 `total=tiles_x*tiles_y*Z`，转换到 `dim3` 前检查合法性。普通三维 grid 与 flatten/grid-stride 必须使用同一 block、stream、flags 和数据实测；若无明确收益或资源恶化，保留初始代码。

## Host Launch Before

```cpp
void launch_3d(const float* x, float* y, int X, int Y, int Z,
               cudaStream_t stream) {
    constexpr int BX = 32;
    constexpr int BY = 8;
    dim3 block(BX, BY, 1);
    dim3 grid((X + BX - 1) / BX,
              (Y + BY - 1) / BY,
              Z);
    kernel3d<<<grid, block, 0, stream>>>(x, y, X, Y, Z);
    CUDA_CHECK(cudaGetLastError());
}
```

示例值只用于展示数据流。实际 block/grid 保留输入值，不能因示例把 BX/BY 改为固定“最佳”。

## 修改后的代码

```cpp
bool launch_flat(const float* x, float* y, int X, int Y, int Z,
                 cudaStream_t stream, unsigned grid_candidate) {
    constexpr int BX = 32;
    constexpr int BY = 8;
    uint64_t tiles_x = (uint64_t(X) + BX - 1) / BX;
    uint64_t tiles_y = (uint64_t(Y) + BY - 1) / BY;
    uint64_t total = tiles_x * tiles_y;
    if (tiles_x != 0 && total / tiles_x != tiles_y) return false;
    if (uint64_t(Z) != 0 && total > UINT64_MAX / uint64_t(Z)) return false;
    total *= uint64_t(Z);
    if (total == 0) return true; // 是否允许空输入服从原 API
    dim3 block(BX, BY, 1);
    dim3 grid(grid_candidate, 1, 1);
    kernel_flat<<<grid, block, 0, stream>>>(
        x, y, X, Y, Z, int(tiles_x), int(tiles_y), total);
    CUDA_CHECK(cudaGetLastError());
    return true;
}
```

`grid_candidate` 必须非零且满足 share 中 grid 限制；普通 flatten 可取 total（合法时），grid-stride 候选可取更小值。二者分别测量。

## Flatten/Unflatten 等价证明

原 tile 坐标范围：

```text
0 <= tx < tiles_x
0 <= ty < tiles_y
0 <= z  < Z
```

定义：

```text
flat = (z * tiles_y + ty) * tiles_x + tx
```

还原：

```text
tx = flat % tiles_x
q  = flat / tiles_x
ty = q % tiles_y
z  = q / tiles_y
```

对 `flat in [0,total)`，商余数唯一，故一一对应。grid-stride 进一步按 `flat += gridDim.x` 覆盖该区间，证明与一维示例相同。host/device 必须使用同样的轴快慢顺序；交换 `tiles_x/tiles_y` 会产生静默错位。

## Thread 映射与地址

tile 内：

```text
ix = tx*BX + threadIdx.x
iy = ty*BY + threadIdx.y
linear = (z*Y + iy)*X + ix
```

只有 `ix<X && iy<Y && z<Z` 时访问。地址乘法用 `size_t/uint64_t`，避免 `int` 在大 tensor 上溢出。若输入/输出 stride 不是 contiguous，应完整保留原 stride 参数，而不是使用上述紧凑公式。

## 需要回退的结构

- kernel 使用 `blockIdx.z` 选择不同指针、随机 seed 或算法分支，而该语义没有完整映射。
- 依赖三维 grid 的 cooperative launch/同步契约。
- host 代码对 grid 维有外部可见假设。
- flatten 增加整数除法/取余并降低性能。
- grid-stride 扩大变量活跃期，导致 register/spill 或 occupancy 恶化。

## 验证矩阵

| Shape | 目的 |
| --- | --- |
| `1×1×1` | 最小映射 |
| 小于 BX/BY | 无效线程 mask |
| `BX±1, BY±1` | 两轴尾 tile |
| Z 多层 | z 恢复顺序 |
| 大 total | 64 位乘积与 grid-stride |
| 非连续 stride | 地址保持 |

每个 shape 比较逐元素输出和错误状态，再用真实 RTX 3090 测量。仅静态证明不足以保留候选。

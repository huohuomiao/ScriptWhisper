## 情况 B：所有维度都是常数 1，使用 constexpr 参数乘积

```cpp
__global__ void single_task(const float* x, float* y, int n) {
    // 原实现可能依赖一个 block 内的 shared-memory 协作。
}

single_task<<<dim3(1), dim3(BLOCK), shared_bytes, stream>>>(x, y, n);
```

## 优化分析步骤 (Modified Analysis)

1. 追踪单 block 是否承担全局初始化、shared-memory 归约或“仅一个线程写最终值”的语义。
2. 若跨 block 后需要全局同步，不允许只扩大 grid；应退出本策略并建议两阶段 kernel/合法 atomic。
3. 若输出任务天然独立，可把任务索引映射为 `blockIdx.x`，但要同步改写地址、mask 和写入所有权。
4. `constexpr`/template 只用于编译期 tile，host 仍需从真实 shape 计算 grid；不能把未知维度假定为 1。
5. 新候选独立 nvcc 编译并执行完整门禁。没有真实 RTX 3090 收益时保持单 block 原实现。

## 单 Block 依赖分析

建立表格：

| 结构 | 单 block 扩展为多 block 的风险 |
| --- | --- |
| `__shared__` 中间数组 | 只在 block 内可见，无法合并跨 block partial |
| `__syncthreads()` | 只同步本 block |
| thread 0 写最终标量 | 多 block 会重复写 |
| 全局 atomic | 可能允许多 block，但顺序/冲突改变 |
| cooperative grid sync | 需要特殊 launch 与 residency 条件 |
| 一次全局初始化 | 扩大 grid 后会重复执行 |

若任何输出依赖“整个问题由同一个 block 完成”，普通 grid 修改不适用。

## Before：单 Block 归约

```cpp
template<int BLOCK>
__global__ void reduce_one_block(const float* x, float* out, int n) {
    float acc = 0.0f;
    for (int i = threadIdx.x; i < n; i += BLOCK) acc += x[i];
    acc = block_reduce_sum(acc);
    if (threadIdx.x == 0) out[0] = acc;
}

reduce_one_block<BLOCK><<<1, BLOCK, shared_bytes, stream>>>(x, out, n);
```

直接把 grid 从 1 改大将产生多个 block 写 `out[0]`，错误。

## 修改后的代码

两阶段：

```cpp
partial_reduce<<<grid1, block, shared1, stream>>>(x, partial, n);
final_reduce<<<1, block, shared2, stream>>>(partial, out, grid1.x);
```

或在操作/类型/精度语义允许时使用 atomic。两者都改变算法、workspace、launch 数和累加顺序，应交给 reduce 架构策略；modify-grid 只报告建议。

## Before：单任务但输出可拆分

```cpp
__global__ void serial_map(const float* x, float* y, int n) {
    if (blockIdx.x == 0 && threadIdx.x == 0)
        for (int i = 0; i < n; ++i) y[i] = op(x[i]);
}
```

该循环的每个输出独立，理论上可改为：

```cpp
__global__ void parallel_map(const float* x, float* y, int n) {
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i < n) y[i] = op(x[i]);
}
```

但这不仅改变 grid，还改变线程所有权和控制流，必须逐访问证明无状态/顺序依赖。若 `op` 使用共享状态、随机序列或跨元素递推，则不适用。

## Host 与空输入

```cpp
if (n == 0) return; // 仅当原 API 对空输入定义为 no-op
unsigned grid = unsigned((uint64_t(n) + BLOCK - 1) / BLOCK);
parallel_map<<<grid, BLOCK, 0, stream>>>(x, y, n);
```

CUDA 不允许 zero-block launch。是否对空输入返回、写单位元或报错必须沿用原实现，不能由优化自行决定。

## 验证

检查单元素、一个 block 边界、多个 block、尾块、in-place alias 和最大地址。动态候选还要保存 register/shared/spill 与 CUDA Event；扩并行后若 launch overhead 主导小 shape，允许保留原单 block dispatch。

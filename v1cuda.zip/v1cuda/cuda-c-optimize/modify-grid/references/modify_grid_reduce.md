## 情况 D 扩展：规约操作（Reduction）

归约 grid 改写必须保持“谁拥有最终输出”和同步层级。普通行归约示例：

```cpp
__global__ void row_sum(const float* x, float* y, int M, int N) {
    int row = blockIdx.x;
    float acc = 0.0f;
    for (int col = threadIdx.x; col < N; col += blockDim.x)
        if (row < M) acc += x[row * N + col];
    acc = warp_reduce_sum(acc);
    // 多 warp 时再经 shared memory 合并；仅唯一线程写 y[row]。
}
```

## 优化分析步骤 (Modified Analysis)

1. 确认每个输出由一个 block、多个 block+atomic，或两阶段 kernel 中哪种方式完成。
2. 仅 flatten 非归约输出轴时，可把 `blockIdx` 展平再还原；block 内 shuffle/shared 结构保持不变。
3. 不得用普通 grid-stride 循环让同一 block 在缺少重新初始化/同步时连续处理多个归约输出。
4. split-K 会改变累加顺序并引入 atomic 或临时 workspace/第二次 launch，属于独立架构候选：
   - sum 可在类型与原子支持合法时比较 atomic 与两阶段方案；
   - max/min/argmax 等需处理初值、NaN 和 value/index 一致性；
   - 必须包含 workspace 初始化与额外 launch 成本；
   - 必须重新执行完整精度门禁。
5. 当 persistent kernel 因 register/spill 使 occupancy 过低，优先生成“一 block 一 tile”的非 persistent 对照；不要继续只降低 grid 并发。
6. 所有方案用真实 RTX 3090 CUDA Event 与 NCU/ptxas 证据比较，无收益即回退。

## 修改后的完整代码

```cpp
template<int BLOCK>
__global__ void row_sum_block(const float* __restrict__ x,
                              float* __restrict__ y,
                              int M, int N, int ld) {
    int row = blockIdx.x;
    float local = 0.0f;
    if (row < M) {
        for (int col = threadIdx.x; col < N; col += BLOCK)
            local += x[size_t(row) * ld + col];
    }
    float total = block_reduce_sum<BLOCK>(local);
    if (threadIdx.x == 0 && row < M) y[row] = total;
}

template<int BLOCK>
void launch_rows(const float* x, float* y, int M, int N, int ld,
                 cudaStream_t stream) {
    if (M == 0) return;
    row_sum_block<BLOCK><<<dim3(M), dim3(BLOCK),
                            block_reduce_smem<BLOCK>(), stream>>>(x, y, M, N, ld);
    CUDA_CHECK(cudaGetLastError());
}
```

普通 grid 中每个 row 由唯一 block 拥有。将二维输出轴 flatten 时，只能修改 `row` 的恢复方式，不能拆散 `block_reduce_sum` 的线程协作。

## 多输出轴 Flatten

对输出 `[B,M]`：

```cpp
int flat_row = blockIdx.x;
int m = flat_row % M;
int b = flat_row / M;
size_t base = (size_t(b) * M + m) * N;
```

host `grid.x=B*M`；使用 64 位计算乘积并检查 grid 合法。映射证明与多维 grid 相同，归约轴 N 不参与 flatten。

## Persistent Row 候选

```cpp
for (int flat_row = blockIdx.x; flat_row < B * M; flat_row += gridDim.x) {
    int m = flat_row % M;
    int b = flat_row / M;
    float local = 0.0f;
    for (int n = threadIdx.x; n < N; n += blockDim.x)
        local += x[(size_t(b) * M + m) * N + n];
    float total = block_reduce_sum(local);
    if (threadIdx.x == 0) y[size_t(b) * M + m] = total;
    __syncthreads(); // 仅当 block_reduce helper 的下一轮需要一致重置 shared
}
```

是否需要循环尾部同步取决于 helper 是否在下一轮读取旧 shared 值；必须审查实现。所有线程要执行相同 row 循环次数，否则包含 `__syncthreads()` 会死锁。更安全的形式让循环条件只依赖 blockIdx/gridDim 和总 row 数，对同一 block 所有线程一致。

Persistent 会让地址、accumulator 和循环变量更长时间活跃。若 baseline 已有 255 register/thread、spill 或一 block/SM 一类证据，必须优先非 persistent；不能用减少 grid blocks 掩盖低 occupancy。

## Split-K / Split-N 两阶段模板

第一阶段每个 `(row,split)` 输出 partial：

```cpp
__global__ void row_sum_partial(const float* x, float* partial,
                                int rows, int N, int splits) {
    int row = blockIdx.y;
    int split = blockIdx.x;
    int begin = (int64_t(N) * split) / splits;
    int end = (int64_t(N) * (split + 1)) / splits;
    float acc = 0.0f;
    for (int n = begin + threadIdx.x; n < end; n += blockDim.x)
        acc += x[size_t(row) * N + n];
    acc = block_reduce_sum(acc);
    if (threadIdx.x == 0) partial[size_t(row) * splits + split] = acc;
}
```

第二阶段沿 splits 归约。必须计入 workspace、两个 launch 与数值顺序。atomic 版本可省第二 kernel 但引入初始化与争用；作为不同候选，不可在同一次修改中混杂。

## Max/Min/Arg Reduce 注意

- max/min 的单位元、NaN 与 signed zero 服从 reference。
- argmax/argmin 必须保持 value/index tie-breaking。
- 不支持的 atomic 类型不能用 CAS 伪实现后跳过正确性/性能验证。
- 空归约输出的值或错误行为保持原 API。

## 覆盖与唯一写证明

对普通 row grid：`blockIdx.x` 在 `[0,rows)` 一一对应输出；每个 lane 访问 `lane+q*blockDim.x`，按模 blockDim.x 唯一覆盖 N。block reduce 后只有 thread 0 写输出。

对 split 方案：split 边界使用整数比例划分，区间连续、互不相交并覆盖 `[0,N)`；partial 索引 `(row,split)` 唯一。第二阶段才能产生最终输出。

## 验证矩阵

| 场景 | 检查 |
| --- | --- |
| N=1 / 小于 warp | inactive lane 与单位元 |
| N 非 warp/block 倍数 | 尾元素覆盖 |
| rows 很少、N 很大 | split 是否增加并行度 |
| rows 很多 | atomic/persistent 是否过度 |
| NaN/Inf/±0 | 操作语义 |
| 非连续 ld | 地址正确 |

所有候选用统一 CUDA Event 分布选择；资源下降不等于性能必升，性能升而正确性/安全失败也必须回退。

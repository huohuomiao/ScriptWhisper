## 情况 A：无法提取 Grid，使用默认表达式

```cpp
__global__ void hidden_launch_kernel(...);
// 当前输入中没有对应 host launch，或 launch 位于无法读取的外部模块。
```

# 无调用语句，无法提取 grid

## 优化分析步骤 (Modified Analysis)

1. 搜索 `<<<...>>>`、`cudaLaunchKernel`、函数指针和模板实例化，确认不是简单遗漏。
2. 若无法绑定唯一 launch，不能知道 grid/block、dynamic shared memory、stream 和参数顺序。
3. 不生成默认 `dim3`，不根据 shape 猜测 block，也不修改 device 索引。
4. 原样输出 `input.cu`，报告列出缺失的 host 调用证据，并建议用户提供完整可独立编译的 `.cu`。

这是安全回退，不是优化失败；不得伪造性能或资源数据。

## 完整歧义示例

```cpp
template<class T>
__global__ void hidden_launch_kernel(const T* x, T* y, int n) {
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i < n) y[i] = x[i];
}

// 当前文件只有 device 定义。真实调用可能位于另一个 translation unit，
// 也可能通过函数指针、driver API 或生成代码发起。
```

仅凭 device 定义无法确定：

- `T` 的实际实例、元素大小和对齐。
- `blockDim` 与 grid 是否普通或 persistent。
- dynamic shared memory、stream 与 cooperative launch。
- `n` 对应哪些生产 shape。
- 是否存在多个不同 launch 配置。

## 搜索清单

1. 当前 `.cu/.cuh` 的 `<<<` 调用。
2. `cudaLaunchKernel` 与 function pointer 表。
3. 模板显式实例化及 wrapper。
4. 宏展开可见的 launch helper。
5. 上游 `cuda_report.md` 或测试记录中的目标 kernel 名。
6. 编译命令列出的同项目源文件（仅在 Optimizer 读取权限允许时）。

若 launch 位于权限范围外，不扩大读取范围；报告请求调用方提供完整单文件输入。

## 禁止的伪修复

```cpp
// 禁止凭经验添加：
hidden_launch_kernel<<<(n + 255) / 256, 256>>>(x, y, n);
```

即使该 launch 对简单 elementwise 看似合理，也可能遗漏 stream、模板类型、shared bytes、错误检查、空输入和现有调度契约。

## 回退产物

`cuda_optimized.cu` 与 `input.cu` 哈希必须一致；报告字段：

```json
{
  "strategy": "modify-grid",
  "status": "skipped",
  "decision": "revert",
  "reason": "target launch is not uniquely available",
  "performance_status": "not_measured"
}
```

不能把“无 launch”解释为 `grid=(1,1,1)`，也不能生成零证据的 NCU/occupancy 建议。

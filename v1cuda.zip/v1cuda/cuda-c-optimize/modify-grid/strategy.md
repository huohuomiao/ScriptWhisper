# CUDA Kernel Grid 优化（modify-grid）

## 职责概述

分析 host launch 与 device 索引，将 `dim3 grid/block`、多维 tile 映射或 grid-stride/persistent 循环改写为可验证的 CUDA C/C++ 候选。目标是提高并行度、负载均衡和占用率，不是机械地把多维 grid 展平，也不是把 grid 强制限制为 SM 数。

设备 SM 数、grid/block 限制、register/shared-memory 与 occupancy 判断只读取 `.claude/skills/share/cuda-c/references/platform-rules.md`。本策略保留结构分析、候选生成、正确性验证、性能选择和回退。

## 步骤

### Step 1：提取原始 Grid 结构

#### 1.1 定位 kernel 定义与调用

1. 定位目标 `__global__` 函数。
2. 找到对应 `kernel<<<grid, block, shared_bytes, stream>>>(...)` 或 `cudaLaunchKernel`。
3. 追踪 `dim3` 各维到 shape/tile 的数据流。
4. 记录 kernel 内 `blockIdx/threadIdx/blockDim/gridDim` 的所有使用点。
5. 多 kernel 时必须沿用上游指定目标；仍有歧义则回退。

#### 1.2 识别 Grid 的写法形式

- 常量 `dim3`。
- 由 `(extent + tile - 1) / tile` 计算的一至三维 grid。
- 多逻辑轴 flatten 到 `grid.x` 后用 `/`、`%` 还原。
- grid-stride loop。
- grid 被人为截断形成 persistent loop。
- cooperative launch、cluster 或跨 block 同步依赖：默认不改。

#### 1.3 拆解各维度

生成映射表：

| 逻辑轴 | grid 维 | block/thread 维 | tile | kernel 内循环 | 边界条件 |
| --- | --- | --- | --- | --- | --- |
| M | x | y | TILE_M | 否 | `m < M` |
| N | y | x | TILE_N | 否 | `n < N` |

同时记录总 tile 数、当前 grid block 数、每 block 线程数、dynamic shared bytes、ptxas register/spill，以及 NCU 的 achieved occupancy/active warps。没有真实指标时只做保守候选，不声称收益。

### Step 2 ：生成推荐 Grid 表达式

#### 情况 A：无法提取到 grid

保持源码不变并报告阻塞。禁止凭 shape 猜测 launch，因为 blockIdx 的隐藏语义、动态 shared memory 或 stream 均可能影响正确性。

参考 [`modify_grid_without_grid.md`](references/modify_grid_without_grid.md)。

#### 情况 B：所有维度都是常数 1

若 kernel 确实只处理单个任务，保持 `dim3(1)`；若源码内存在可并行的输出循环，才能生成映射到 block/thread 的独立候选。

参考 [`modify_grid_constexpr.md`](references/modify_grid_constexpr.md)。

#### 情况 C：单维度 grid

标准元素/块映射优先保留足够 grid 并行度。只有在启动开销或任务复用有真实证据时才比较 grid-stride 候选；不可直接用 SM 数作为 grid 上限。

参考 [`modify_grid_1d.md`](references/modify_grid_1d.md)。

#### 情况 D：多维度 grid

CUDA 原生支持三维 grid。多维 grid 与一维 flatten 在语义等价时均可作为候选；flatten 的目的应是改善调度/映射或支持统一 grid-stride，而不是形式上的简化。

```cpp
int flat = blockIdx.x;
int tile_n = flat % tiles_n;
int tile_m = flat / tiles_n;
```

当 `tiles_m * tiles_n` 可能溢出 32 位时，host 与 device 均使用经验证的 64 位无符号计算，并在 launch 前检查 grid 合法性。

参考 [`modify_grid_3d.md`](references/modify_grid_3d.md)。

#### Persistent 与非 persistent 选择

persistent/grid-stride 候选必须与普通“一个 block 对应一个 tile”候选成对比较。若 ptxas/NCU 显示高 register/thread、spill、低 resident blocks/SM 或低 occupancy，优先保留非 persistent；对 K 归约并行不足可提出 split-K，但它属于架构候选，必须单独处理临时输出/atomic、数值顺序和额外 launch 成本。

### Step 3：改写Kernel 代码

#### 3.1 Wrapper 函数改写

1. 使用相同 stream 和 dynamic shared bytes。
2. 只修改与候选映射相关的 `dim3 grid/block` 与显式 tile 常量。
3. 保留 CUDA API/launch/sync 错误检查。
4. 所有候选使用相同 nvcc flags 独立编译。

普通二维 grid：

```cpp
dim3 block(BLOCK_N, BLOCK_M);
dim3 grid((N + BLOCK_N - 1) / BLOCK_N,
          (M + BLOCK_M - 1) / BLOCK_M);
kernel<<<grid, block, shared_bytes, stream>>>(...);
```

flatten 候选：

```cpp
uint64_t total = uint64_t(tiles_m) * tiles_n;
dim3 grid(static_cast<unsigned>(total));
kernel<<<grid, block, shared_bytes, stream>>>(..., tiles_n, total);
```

#### 3.2 Kernel 函数体改写 — 通用转换规则

- 对每个旧 `blockIdx.{x,y,z}` 建立明确的新表达式。
- 地址、mask、输出所有权与归约范围必须同时更新。
- grid-stride 步长使用 `gridDim.x`，不能使用硬编码 SM 数。
- 循环内存在 `__syncthreads()` 时，所有 block 线程必须以一致控制流到达；不能让部分线程提前 `return`。
- atomic、随机数、浮点归约顺序或跨 block 依赖会改变语义时，必须单独验证或放弃。

#### 3.3 非规约场景的改写方式

每个逻辑输出只能由一个线程/block 写入；边界 mask 使用还原后的逻辑坐标。grid-stride 不得重复或遗漏 tile。

#### 3.4 规约场景的改写方式

保持每个归约输出的唯一所有者与同步层级。flatten grid 不能把原本同一 block 内协作的归约拆散；split-K/atomic 不是普通 grid 重写，参考 [`modify_grid_reduce.md`](references/modify_grid_reduce.md)。

#### 3.5 grid=(1,1,1) 单 block 场景的改写方式

只有当输出规模和同步语义允许时才扩大 grid。若原实现依赖单 block shared-memory 归约或一次初始化，不能机械拆分；可能需要两阶段 kernel，此时退出本策略并作为架构级建议记录。

### Step 4：验证生成代码，输出最终结果

1. nvcc 编译并保存 `-Xptxas=-v` 的 register/shared/spill。
2. 运行全部 correctness、CUDA 错误检查和既有 sanitizer 门禁。
3. 使用同一 CUDA Event stream/warmup/repeat 比较 median/p20/p80。
4. 检查每个 shape（包括尾块、极小/极大尺寸）不重不漏。
5. 仅当真实 RTX 3090 上性能不回退且修改可归因时保留；否则 `cuda_optimized.cu` 原样等于 `input.cu`。

## 硬性约束（优化改写时必须遵守）

### 禁止项

- 禁止把 grid 无条件裁剪为 SM 数。
- 禁止根据静态估算宣称 occupancy 或性能提升。
- 禁止改变 stream、输入、编译 flags、容差来使候选胜出。
- 禁止在普通 grid 策略中暗中加入 split-K、fast math 或算法变化。
- 禁止 persistent 候选没有非 persistent 对照。

### 类型约束

用于总 tile、flatten 和 stride 的中间值按可证明范围选择 `uint64_t/size_t`；转换为 `dim3` 前显式检查。device 除法/取余的类型和有符号性必须与 host 一致。

### 保守原则

不能证明映射等价、动态执行不可用或目标非 RTX 3090 时保持输入不变，并在报告中写明证据缺口。

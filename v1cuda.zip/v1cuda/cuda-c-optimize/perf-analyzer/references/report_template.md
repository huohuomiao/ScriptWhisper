# CUDA Kernel 性能分析报告

## 1. CUDA kernel 与环境信息

### 1.1 输入规模
- **Shape**: (M, N)
- **Dtype**: float32

### 1.2 launch 与 ptxas 信息

- **block.x/y/z**：XX
- **grid.x/y/z**：XX
- **block/grid/shared bytes**：XX
- **tile/vector/unroll**：XX

## 2. NCU 指标与瓶颈证据

- 目标设备/CC/UUID：
- kernel 名与 launch：
- registers/thread、shared memory、spills：
- achieved/theoretical occupancy、active/eligible warps：
- DRAM/L2 throughput、warp stalls、计算吞吐：
- 原始 NCU/ptxas 日志路径：

- **register/thread、static/dynamic shared**：XX
- **spill、achieved/theoretical occupancy**：XX

## 3. 优化策略建议

- 建议策略：
- 指标证据：
- 预期作用与风险：
- 若未实测：`not_measured` 与原因

- `decision`：profiled | not_measured | invalid

# CUDA Kernel 性能分析

## 职责概述

使用 ptxas 与 Nsight Compute（NCU）对目标 CUDA C/C++ 代码进行性能分析，解析性能指标，并生成深度优化建议。

CUDA 专属采集实现位于 `.claude/skills/share/cuda-c/perf-analyzer/`，本文件只保留可复用的分析、验证和报告流程。RTX 3090 阈值从 share 的 `platform-rules.md` 读取。

## 执行契约

所有涉及 CUDA 代码、nvcc 或 NCU 命令的执行必须先确认当前工作流的 EnvConfig 产物，不允许直接猜测本地执行环境或 Worker。

执行前从本轮 perf-analyzer 的 `output_dir` 向上推断工作流 `{output_dir}`，读取 `{output_dir}/EnvConfig/config.md` 中的 `execution_backend`：

- `execution_backend=local`：直接在 Linux 本地执行环境执行 `bash analyzer.sh ...`
- `execution_backend=worker`：通过 `submit_task_to_worker.py` 提交 Worker Task 执行同一条 `bash analyzer.sh ...` 命令
- EnvConfig 缺失或无法判断后端：记录环境错误并终止 perf-analyzer，**不要修改 kernel 代码**

Worker 执行示例（必须前台同步执行，等待 `submit_task_to_worker.py` 退出后再判断结果；禁止 `&` 后台、禁止并发提交多个 Worker Task）：

```bash
python .claude/skills/cuda-c-main/subagents/scripts/submit_task_to_worker.py \
    --workdir <仓库根目录的绝对路径> \
    --command "env NCU_KERNEL_NAME='<exact-or-regex-filter>' bash .claude/skills/share/cuda-c/perf-analyzer/analyzer.sh <output_dir> <binary> [binary_args...]" \
    --timeout-sec 1800 \
    --task-type custom

```

**Worker 模式结果分类**（以 `submit_task_to_worker.py` 退出码为准）：
- `0` → 执行成功
- `1` → 业务错误（Traceback / 精度不达标）
- `2` → 基础设施错误（输入路径不存在 / Worker 不可达等）→ **不要修改 kernel 代码**，先修 EnvConfig 或路径，终止本 Skill 并提示用户

- 禁止为了测试或 benchmark 另建 Job。
- 判断优化是否有效时，必须以实际执行环境的真实 stdout/stderr/result 为准。

## 输入输出说明

**输入**：
- `input_file`：可独立编译运行的 `.cu` 文件，包含 CUDA kernel、host launch、正确性及 CUDA Event 性能测试
- `output_dir`：生成文件存储目录

**输出**：
- `{output_dir}/report.md`：对 `input_file` 的性能分析报告

**要求**：
- 性能分析不修改源码；若采集失败或目标不是 RTX 3090，报告必须写明 `not_measured`，不得推断指标或建议动态候选

## 现有深度优化策略

|      策略      |     策略名称     |                            说明                             |
|---------------|-----------------|-------------------------------------------------------------|
| Libdevice 优化 | `libdevice-opt` | 按精度契约选择 CUDA math intrinsic 或 fast intrinsic |
| Config 微调    | `config-tuner`  | 调整 block、tile、vector width、unroll、shared staging |
| 除法指令优化 | `div-to-mul` | 将除法指令修改为乘倒数 |
## 性能分析步骤

### Step 1：使用性能分析脚本生成性能数据

1. 使用与 baseline 完全相同的命令编译 `.cu`，保留 `-lineinfo -arch=sm_86 -Xptxas=-v` 与全部 stdout/stderr。生成只执行目标 CUDA kernel 一次的 profile 路径；不得改变 kernel 参数、输入或 stream。

提取正确性/性能测试的输入规模，包括 `Shape`、`Dtype`、stride、seed 和目标 kernel 名：

例如：
```text
Shape = [134217728]
Dtype = float
Kernel = vector_kernel
```

单次 profile 入口只运行已通过正确性门禁的输入，并保存在 `{output_dir}/run_once`；性能基准仍由原 CUDA Event 路径单独执行。

2. 运行脚本获取性能数据

```bash
env NCU_KERNEL_NAME='{exact_or_regex_kernel_filter}' \
  bash .claude/skills/share/cuda-c/perf-analyzer/analyzer.sh \
  {output_dir} {output_dir}/run_once [binary_args...]
rm -f {output_dir}/run_once
```

上述命令也必须按本文件“执行契约”选择后端：local 直接执行，worker 通过 `submit_task_to_worker.py --task-type custom` 执行。

### Step 2：性能数据解析

#### 2.1：占用率、寄存器、spill 与吞吐瓶颈

解析 share 解析器产生的结构化指标，并与 ptxas 输出交叉核对：achieved/theoretical occupancy、eligible/active warps、register/thread、local-memory spill、shared memory、DRAM/L2 throughput、warp stall、Tensor Core/FP 指令和 kernel duration。

**低占用率或延迟隐藏不足的可能原因**：

  - block 过大、register/thread 或动态 shared memory 过高
  - persistent grid 使每个 SM 驻留 block/warp 太少
  - spill 引入 local-memory 流量；内存不合并或同步过多

**优化建议**：

  - block/tile/occupancy 或资源压力 → `config-tuner`
  - 数学函数吞吐且精度契约允许 → `libdevice-opt`
  - 除法确认为热点且语义允许 → `div-to-mul`
  - persistent 受 occupancy 限制 → 建议回到 `modify-grid` 比较非 persistent；K 归约并行不足时可提出 split-K，但必须作为独立候选验证

不得仅凭单一百分比提出策略。报告必须引用具体指标和采集日志；NCU replay 改变语义、kernel 名歧义或采样不完整时标记分析无效。

### Step 3：生成性能分析报告

根据以上信息，生成性能分析报告，并存储在 `{output_dir}/report.md`。

性能分析报告模版见：[`report_template.md`](references/report_template.md)

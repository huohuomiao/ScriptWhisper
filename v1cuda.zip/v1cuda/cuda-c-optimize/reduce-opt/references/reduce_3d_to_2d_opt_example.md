# CUDA 归约三维 tile 转二维 tile 示例

场景：输入 `[M,N,K]` 沿 N 归约，原 kernel 每个 block 同时维护多个 M/K 输出的 accumulator，导致 register/shared-memory 压力。

## 原始映射

```cpp
template<int TILE_M, int TILE_N, int TILE_K>
__global__ void reduce3d(const float* x, float* y, int M, int N, int K) {
    int m0 = blockIdx.y * TILE_M;
    int k0 = blockIdx.x * TILE_K;
    float acc[TILE_M_PER_THREAD][TILE_K_PER_THREAD] = {};
    for (int n0 = 0; n0 < N; n0 += TILE_N) {
        // cooperative load；沿 N 累积 TILE_M × TILE_K 组输出
    }
    // 写 y[(m0+m)*K + (k0+k)]
}
```

## 优化后候选

把非归约 M tile 标量化为一个 block 对应一个 M tile 行，只维护 K 方向 accumulator：

```cpp
template<int TILE_N, int TILE_K>
__global__ void reduce2d(const float* x, float* y, int M, int N, int K) {
    int m = blockIdx.y;
    int k0 = blockIdx.x * TILE_K;
    float acc[TILE_K_PER_THREAD] = {};
    for (int n0 = 0; n0 < N; n0 += TILE_N) {
        // 对 [TILE_N,TILE_K] tile 协作加载并沿 N 归约
    }
    // 写 y[m*K + (k0+k)]
}

dim3 grid(ceil_div(K, TILE_K), M);
reduce2d<TILE_N,TILE_K><<<grid, block, shared_bytes, stream>>>(x, y, M, N, K);
```

## 示例说明

1. M 是非归约轴，N 是归约轴，K 是并行输出轴。
2. 候选减少每线程活跃 accumulator 数，可能降低 register/thread 和 spill、提高 resident blocks；也会减少跨 M 的数据复用。
3. host grid 的 y 维相应扩大为 M，边界、stride、stream 和输出所有权保持不变。
4. 只有 ptxas/NCU 明确显示原实现受 register/shared/occupancy 限制时才生成该候选。
5. 与原三维 tile 使用相同 flags、输入和 CUDA Event 口径实测；若吞吐下降或差异为噪声，回退原实现。

TILE/block 的合法范围与 RTX 3090 资源阈值只从 share 读取，不在示例中给出固定“最优值”。

## 地址与输出所有权推导

原 contiguous 地址：

```text
input[m,n,k] = input[(m*N+n)*K+k]
output[m,k]  = output[m*K+k]
```

原三维 tile 中每个 block 覆盖：

```text
m in [blockIdx.y*TILE_M, (blockIdx.y+1)*TILE_M)
k in [blockIdx.x*TILE_K, (blockIdx.x+1)*TILE_K)
n in [0,N)
```

候选令 `TILE_M=1`，`m=blockIdx.y`。对任意合法 `(m,k)`，存在唯一 `blockIdx.y=m` 与唯一 K tile，因此没有输出冲突；N 仍只被该 block 内线程归约。

非连续输入时使用显式 `stride_m/stride_n/stride_k`：

```cpp
size_t input_idx = size_t(m) * stride_m
                 + size_t(n) * stride_n
                 + size_t(k) * stride_k;
```

不能因示例 contiguous 而在候选中删除 stride 参数。

## Host Launch 对照

```cpp
// Before
dim3 grid3(ceil_div(K, TILE_K), ceil_div(M, TILE_M));
reduce3d<TILE_M,TILE_N,TILE_K>
    <<<grid3, block3, smem3, stream>>>(x, y, M, N, K);

// Candidate
dim3 grid2(ceil_div(K, TILE_K), M);
reduce2d<TILE_N,TILE_K>
    <<<grid2, block2, smem2, stream>>>(x, y, M, N, K);
```

除与降维直接相关的 block/shared 配置外，compile flags、stream、输入和测试保持一致。若必须同时改变 block 才能使候选合法，在报告中明确记录为耦合变化，优先生成能单独归因的版本。

## 资源预期与反例

预期变化：

- accumulator 数从 M×K 降为 K。
- 地址/mask 临时值减少。
- grid.y 增大，可能提供更多 blocks。
- 跨 M 数据复用消失，global/shared load 可能增加。

反例：若原 tile 把同一 N/K 数据复用于多个 M，且 register 无 spill、occupancy 已足够，二维候选可能更慢。静态“更少寄存器”不能决定保留。

## 边界与同步

1. `M=1` 时两映射应退化等价。
2. `M` 不整除原 TILE_M 时，比较尾 tile mask。
3. `K` 不整除 TILE_K 时保持 K mask。
4. `N` 尾 tile 的归约单位元正确。
5. `__syncthreads()` 不位于部分线程分支。
6. 每轮处理新 m/k tile 时 shared/accumulator 重新初始化。

## 完整结果表

| 指标 | Before 3D | Candidate 2D | 来源 |
| --- | ---: | ---: | --- |
| registers/thread | | | ptxas |
| static/dynamic shared | | | ptxas/launch |
| spill load/store | | | ptxas/NCU |
| achieved occupancy | | | NCU |
| median/p20/p80 ms | | | CUDA Event |
| max abs/rel error | | | correctness |

缺少真实 RTX 3090 任一动态证据时填 `N/A/not_measured`，候选不进入最终输出。

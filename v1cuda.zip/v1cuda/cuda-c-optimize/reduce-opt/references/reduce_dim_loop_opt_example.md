# CUDA 归约轴循环优化示例

## 示例 1：每线程串行归约改为 block 归约

### 原始代码

```cpp
__global__ void row_sum_serial(const float* x, float* y, int M, int N) {
    int row = blockIdx.x * blockDim.x + threadIdx.x;
    if (row >= M) return;
    float acc = 0.0f;
    for (int n = 0; n < N; ++n) acc += x[row * N + n];
    y[row] = acc;
}
```

### 优化后候选

```cpp
__inline__ __device__ float warp_sum(float v, unsigned mask) {
    for (int d = 16; d; d >>= 1)
        v += __shfl_down_sync(mask, v, d);
    return v;
}

__global__ void row_sum_block(const float* x, float* y, int M, int N) {
    int row = blockIdx.x;
    float acc = 0.0f;
    for (int n = threadIdx.x; n < N; n += blockDim.x)
        if (row < M) acc += x[row * N + n];
    // 多 warp block：先各 warp shuffle，再经 shared 由首 warp 合并。
    acc = block_reduce_sum(acc);
    if (threadIdx.x == 0 && row < M) y[row] = acc;
}
```

### 示例说明

原实现让一个线程串行读取整行；候选让 block 分担 N 轴。改写改变浮点累加顺序，必须用原容差验证。`block_reduce_sum` 必须处理尾 warp、有效 mask、shared 初始化和一致到达的 `__syncthreads()`。

## 示例 2：已有有效 grid-stride 局部归约

```cpp
for (int n = threadIdx.x; n < N; n += blockDim.x)
    acc += x[row * N + n];
acc = block_reduce_sum(acc);
```

该形式已经并行覆盖归约轴。除非 NCU 显示 shuffle/shared/线程配置是瓶颈，否则不要仅为“消除循环”改为一次读取；CUDA 不存在任意长轴的一次向量化语义。

## 示例 3：循环遍历输出而非归约轴

```cpp
for (int row = blockIdx.x; row < M; row += gridDim.x) {
    float v = x[row];
    y[row] = f(v);
}
```

循环变量选择不同输出，不把多个元素聚合到同一输出，因此是并行轴 grid-stride loop，不触发归约轴循环优化。

## 示例 4：超大归约与 split-K 建议

当归约轴很大、输出行很少，单 block 归约可能并行不足。不能在本策略内硬编码阈值或直接强制 atomic；应根据 share 的硬件规则和真实 NCU 证据，提出独立 split-K/两阶段候选，包含 workspace/atomic、额外 launch 和数值顺序成本。

## 验证清单

- 输入地址连续性与 stride 正确。
- inactive lane 不参与未定义 shuffle。
- 每个输出唯一写入，或 atomic/两阶段所有权清晰。
- `float/half/double` accumulator 与原实现一致。
- ptxas register/shared/spill、NCU occupancy 与 CUDA Event 分布均保存。
- 无明确收益时 `cuda_optimized.cu` 与 `input.cu` 逐字一致。

## 示例 5：多 Warp Block Reduce 的完整实现骨架

```cpp
template<int BLOCK>
__device__ float block_sum(float v) {
    constexpr int WARPS = BLOCK / 32;
    __shared__ float warp_sum[WARPS];
    int lane = threadIdx.x & 31;
    int warp = threadIdx.x >> 5;

    for (int d = 16; d; d >>= 1)
        v += __shfl_down_sync(0xffffffffu, v, d);
    if (lane == 0) warp_sum[warp] = v;
    __syncthreads();

    float out = (threadIdx.x < WARPS) ? warp_sum[lane] : 0.0f;
    if (warp == 0) {
        for (int d = 16; d; d >>= 1)
            out += __shfl_down_sync(0xffffffffu, out, d);
    }
    return out;
}

template<int BLOCK>
__global__ void row_sum_block(const float* x, float* y,
                              int rows, int cols, int ld) {
    int row = blockIdx.x;
    float local = 0.0f;
    if (row < rows) {
        for (int col = threadIdx.x; col < cols; col += BLOCK)
            local += x[size_t(row) * ld + col];
    }
    float total = block_sum<BLOCK>(local);
    if (threadIdx.x == 0 && row < rows) y[row] = total;
}
```

### 模板前提

- `BLOCK` 是 32 的整数倍且不小于一个 warp。
- 全 block 线程都到达 `__syncthreads()`，不能让 `row>=rows` 的线程提前返回。
- 第二层 shuffle 中非 warp partial 的 lane 使用 sum 单位元 0。
- `WARPS` 与 shared 数组大小在 share 的资源限制内。
- 其他操作需替换单位元和 combine，不能复用 sum 模板名称掩盖语义。

## 示例 6：非满 Warp 的安全模式

当 block 线程数或归约有效 lane 不是完整 warp 时，避免使用错误 full mask：

```cpp
int lane = threadIdx.x & 31;
bool valid = lane < valid_lanes;
unsigned mask = __ballot_sync(0xffffffffu, valid);
float v = valid ? input_value : 0.0f;
for (int d = 16; d; d >>= 1) {
    float other = __shfl_down_sync(mask, v, d);
    if (lane + d < valid_lanes) v += other;
}
```

所有 mask 中的线程必须执行同一 shuffle。若控制流复杂、mask 证明困难，选择完整 warp 加单位元或 shared 归约，而不是冒险生成候选。

## 示例 7：Max 与 NaN

```cpp
float combine_max(float a, float b) {
    // 这里只是结构示意。具体 NaN/signed-zero 行为必须匹配 reference。
    return fmaxf(a, b);
}
```

在生成 max 候选前记录 reference 对以下输入的行为：普通值、全负值、`+0/-0`、一个/多个 NaN、全 NaN。若 host reference 与 `fmaxf` 规则不同，需要显式 combine 或跳过。

## 示例 8：In-place 与输入恢复

归约通常输出 shape 更小，但 workspace 或测试可能复用输入。若候选对输入有写入，benchmark 每轮前必须在同一 stream 恢复相同数据；恢复事件不能混入 kernel-only CUDA Event，端到端口径则应如实包含。baseline 与候选必须一致。

## 报告结构

```markdown
### reduce-axis-loop
- target_kernel:
- source_hash_before / after:
- reduction_axes:
- mapping_before:
- mapping_after:
- accumulation_type / order_change:
- nvcc_command:
- registers / shared / spills:
- accuracy_pass / max_abs / max_rel:
- cuda_error / sanitizer:
- median / p20 / p80:
- decision: keep | revert | not_measured
- reason:
```

如果 block 归约正确但性能下降，`decision=revert`，最终源码必须回到原串行实现；报告可保留候选及其证据，不能把“并行度更高”当作成功。

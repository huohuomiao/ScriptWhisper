# CUDA C/C++ reduce 类算子综合优化

循环、访存和归约改写保留在本策略；RTX 3090 的 warp、register、shared-memory、atomic、occupancy 与阈值只读取 `.claude/skills/share/cuda-c/references/platform-rules.md`。不得把其他架构或静态估算当作 3090 实测。

## 职责概述

本优化套件按顺序检查多个 CUDA 归约策略。每次只执行可证明语义等价、可单独归因的一项改写；所有候选最终统一执行 nvcc、正确性、安全和 CUDA Event 性能门禁。

| 顺序 | 优化策略 | 核心适用场景 | 优化目标 |
| ---: | --- | --- | --- |
| 1 | while 转 for | 固定起点/边界/步长的计数型 `while` | 规范循环，便于编译器分析/unroll |
| 2 | 归约轴循环优化 | 每线程串行归约或 block 归约映射不合理 | warp shuffle/shared 分层归约 |
| 3 | 三维 tile 转二维 tile | 三维临时 tile 沿中间轴归约，资源压力高 | 降低每线程活跃值和 shared/register 压力 |
| 4 | 单次 for 消除 | 编译期可证明只执行一次的循环 | 消除控制流与冗余索引 |
| 5 | 冗余访存消除 | 等价 global load 间无写入/别名风险 | 复用寄存器或 shared 数据 |
| 6 | 全维度 Load+Reduce+Atomic | 标量全归约且 atomic 语义/类型合法 | 减少中间 buffer/launch；与两阶段方案比较 |
| 7 | layout 变换消除 | host/device 间存在可融合 transpose/permute | 融合索引，减少额外搬运 |

> 按顺序做准入校验。通过则生成一个独立候选，统一验证后只有 keep 的源码才能成为下一策略输入；失败、无收益或无法实测均回退为该轮 `input.cu`。

## 综合优化执行流程

1. **输入准备**：读取完整 `.cu`、EnvConfig、baseline 与本轮 `kernel_info.json`。
2. **静态模式**：目标未确认 RTX 3090/sm_86 或执行后端不可用时，不生成动态候选，原样输出并写 `not_measured`。
3. **策略遍历**：按表顺序完成准入、单项改写、独立 nvcc 编译与统一门禁。
4. **证据保存**：每轮保存源码哈希、diff、编译命令、ptxas register/shared/spill、正确性、安全、CUDA Event 分布和决策。
5. **结果选择**：维护 best-so-far，不把最后一个候选自动当作最优。

**重要提醒**

- 一次候选只实施当前策略，不暗中调整 block/tile、fast math 或 grid。
- 浮点归约顺序变化可能产生误差，必须沿用原 atol/rtol，不能放宽门禁。
- 有 `__syncthreads()` 的控制流必须 block 一致；inactive lane 的 shuffle 值必须正确处理。
- shared/register/atomic 的具体限制和支持类型只读 share。

## 策略1：while循环转for循环优化

### 优化原理

对于固定步长计数循环，C/C++ `for` 能更明确表达 induction variable，便于 nvcc 做 unroll 和循环不变量分析。但编译器可能生成相同 SASS，因此本策略不是必然收益。

### 功能说明

1. 准入校验：识别**可确定分析为固定步长的计数型 while 循环**，即循环变量、边界、步长能被识别，循环变量在每轮迭代中按固定步长单调推进，且循环体内不存在会改变循环次数语义的控制流。若不存在满足上述条件的 `while` 循环，则跳过该优化策略。
2. 核心优化：将满足条件的 `while` 循环改写为语义等价的 `for` 循环，并删除原循环体中的循环变量更新语句，保证计算结果与原代码完全一致。

### 优化准入校验

仅当初值、单调比较、固定净步长和终止性都可静态证明，且不存在改变迭代次数的 `break/continue/goto`、循环变量别名写入、溢出差异或循环后最终值依赖时允许改写。

遍历 kernel 函数体，判断是否存在可确定分析为固定步长的计数型 `while` 循环。

#### 检测方法

1. **识别循环条件**：循环条件必须能够解析为循环变量与边界表达式之间的单调比较关系，并能确定比较方向是正向收敛还是反向收敛。
2. **识别循环变量来源**：循环变量必须在进入循环前具有可确定的起始表达式，且该起始表达式在循环改写过程中可以作为 `for` 循环的起点。
3. **识别循环变量更新**：循环体内必须存在对同一循环变量的更新操作，且该更新操作能够抽象为固定步长的增量或减量。
4. **确认固定净步长**：必须能确定每轮迭代中循环变量的净变化量固定不变。若循环体中存在多处更新，必须能合并为确定的固定净步长。
5. **匹配比较方向与步长方向**：循环条件的收敛方向必须与固定净步长方向一致，确保循环变量每轮迭代都朝终止边界推进；若方向不一致，则跳过该循环。
6. **确认循环变量用途**：若循环体后续语句依赖循环结束后的循环变量最终值，则不优化该循环，避免改变循环后变量值语义。

#### 判断原则

仅当循环变量初值、边界、比较方向和固定净步长均可确定，循环变量每轮按同一方向单调推进，循环结束后的循环变量最终值不被后续语句依赖，并且能够证明该 `while` 循环可以被安全、等价地改写为 `for` 循环时，才允许执行优化。若上述任一条件不满足，或存在会改变循环执行次数的控制流，则跳过该循环。

#### 结果判断

- 如果检测到至少一个可优化的计数型 `while` 循环，记录循环位置、循环变量名、起始表达式、边界表达式、比较操作符、净步长表达式，并进入优化执行流程。
- 如果未检测到可优化循环，则跳过该优化策略。

### 优化执行流程

#### 步骤1：生成等价 for 循环

针对每个通过准入校验的 `while` 循环执行以下改写：

1. **保留循环前变量定义**：保留循环起始表达式、边界表达式和步长表达式相关的定义语句，避免影响循环体外或后续代码对这些变量的使用。
2. **计算 for 循环边界**：根据原 `while` 循环的比较方向、循环变量等于终止边界时是否仍会执行循环体以及固定净步长，推导等价 `for` 循环的起点、终点和步长；若需要为保持边界语义调整终点表达式，必须确保调整后的表达式可安全生成。
3. **替换循环外壳**：将 `while` 控制结构改写为使用同一循环变量、等价起点、等价终点和等价步长的 `for` 控制结构，保证循环变量的取值序列与原 `while` 完全一致。
4. **删除循环变量更新语句**：删除原循环体内用于推进循环变量的固定步长更新语句。若循环体中存在多处可合并的固定更新，删除这些更新语句，并确保删除后循环体其余语句顺序不变。
5. **保持循环体语义**：除删除循环变量更新语句外，循环体内其余语句顺序、缩进、变量名、访存、mask、归约操作均保持不变。
6. **多循环处理**：若 kernel 内存在多个互不嵌套的计数型 `while` 循环，逐个改写；若存在嵌套 `while`，仅改写可以独立证明等价的循环。

**重要提醒**

- 仅修改必要代码。

### 优化示例（while循环转for循环优化）

#### 原始代码

```cpp
int k = threadIdx.x;
while (k < K) { acc += x[k]; k += blockDim.x; }
```

#### 优化后代码

```cpp
for (int k = threadIdx.x; k < K; k += blockDim.x)
    acc += x[k];
```

#### 示例说明：

循环变量、边界与步长保持相同，唯一删除的是循环体内的更新语句。有符号范围和循环后变量使用仍按本节准入条件检查。

若 ptxas/SASS 与性能无变化，保留改动更小的输入。

## 策略2：归约轴循环优化

### 优化原理

CUDA 中通常让多个 lane 分担归约轴，每线程先累积局部值，再用 `__shfl_down_sync` 完成 warp 归约；多 warp block 通过 shared memory 做第二层合并。它替代的是低并行的串行归约，而不是把任意大轴“一次向量化”。

### 功能说明

该优化用于分析输入的 CUDA kernel 代码，自动检测归约轴上的显式循环计算。只有当现有循环并行度不足、目标归约语义可安全映射为 warp/block 分层归约且存在真实性能证据时，才生成候选；无法提取归约轴或已有实现合理时返回原始实现。

### 优化准入校验

#### 步骤1：检测归约轴循环

##### 检测方法

1. **识别潜在归约循环**：观察kernel中是否存在循环结构，循环边界通常由归约轴大小相关的参数决定。
2. **分析循环体操作**：检查循环体内是否包含与循环变量线性相关的加载操作以及归约操作，且循环结束后中间结果变量被写入输出。
3. **验证循环变量关联性**：确认循环变量用于索引归约轴上的不同位置，加载属于同一个输出位置的归约集合元素（典型形式：`ptr + i * stride_reduce`）。
4. **区分归约与非归约循环**：排除仅用于遍历输出元素的循环，以及已经由 warp/block 协作完成的归约。
5. **处理分块归约**：即使循环以块为单位遍历归约轴，只要执行归约操作，仍判定为存在归约循环。

##### 判断原则

- **存在归约轴循环**：kernel中包含至少一个循环，其迭代范围覆盖归约轴（或分块覆盖），循环变量用于索引归约轴，并在循环体内执行归约操作。
- **不存在归约轴循环**：kernel中无上述循环；或循环变量不参与归约轴索引；或归约已经通过 warp/block 协作完成。

##### 结果判断

根据步骤1的检测结果：

- 如果检测到**存在归约轴循环**，记录循环位置信息，并继续执行步骤2。
- 如果检测到**不存在归约轴循环**，则终止流程，直接返回原始代码。

#### 步骤2：提取归约轴大小并判断

若步骤1检测到存在归约轴循环，则进入本步骤，尝试**提取归约轴大小**，并决定是否生成优化 kernel。

##### 2.1 提取测试数据规格

从给定的测试数据规格中提取输入 tensor 形状、数据类型等信息，供后续步骤使用。

##### 2.2 定位归约轴并根据测试数据规格提取归约轴大小

- **定位归约轴**：利用步骤1记录的循环位置，确定归约轴对应的参数名或维度索引（如 `dim`）。
- **从测试规格提取大小**：在测试代码和 host wrapper 调用处获取输入形状或直接传入的常量值，计算归约轴具体数值。

##### 2.3 决策规则

不在本策略硬编码归约长度阈值。结合轴大小、当前 block 映射、ptxas 资源和真实 NCU 瓶颈，判断是否生成 warp/block 候选；无法从全部测试规格证明合法时返回原始代码。

1. 确认循环变量只遍历同一输出的归约集合。
2. 确认操作满足需要的结合/交换性质，或原容差允许改变求和顺序。
3. 确认输出所有权、NaN/Inf、初值和尾部元素语义。
4. argmax/argmin 必须同步处理 value/index 与 tie-breaking。
5. 已使用有效 warp/block 归约且无 profile 瓶颈时跳过。

### 优化执行流程

#### 步骤1：生成优化kernel

##### 1.1 定位归约轴循环并识别归约轴和分块参数名

- **定位归约轴循环**：直接使用**优化准入校验**时记录的归约轴循环位置信息，定位 kernel 中遍历归约轴的 for 循环。
- **识别归约轴参数名**：确定归约循环依赖的归约轴大小参数名（如 `reduce_size`、`N`、`K`），或其在 wrapper 中对应的维度索引（如 `dim` 参数）。
- **识别分块参数名**：分析归约循环的 block/tile 步长，记录对应的 `blockDim`、template 或 `constexpr` 配置。

候选保留原 kernel 函数名、参数顺序、host stream 与测试契约，只改变归约线程协作结构。

### 优化示例（归约轴循环优化）

#### 原始代码（存在分块归约循环的场景）

```cpp
__global__ void row_sum_serial(const float* x, float* y, int M, int K) {
    int row = blockIdx.x * blockDim.x + threadIdx.x;
    if (row >= M) return;
    float acc = 0.0f;
    for (int k = 0; k < K; ++k) acc += x[row * K + k];
    y[row] = acc;
}
```

#### 优化后代码

```cpp
__inline__ __device__ float warp_sum(float v, unsigned mask) {
    for (int d = 16; d > 0; d >>= 1)
        v += __shfl_down_sync(mask, v, d);
    return v;
}

__global__ void row_sum(const float* x, float* y, int M, int K) {
    int row = blockIdx.x;
    float acc = 0.0f;
    for (int k = threadIdx.x; k < K; k += blockDim.x)
        if (row < M) acc += x[row * K + k];
    // 对完整 warp 可用全 mask；尾 warp 必须用 __activemask() 或显式有效 mask。
    acc = warp_sum(acc, __activemask());
    // 多 warp 时写 shared，__syncthreads()，再由首 warp 合并。
}
```

#### 示例说明：

原始实现让一个线程串行覆盖 K；候选让一个 block 的 lane 分担 K，再分层合并。输出所有权、尾 lane、浮点累加顺序和全部边界用例必须重新验证。

block/tile 值由后续 config 策略离线搜索，本策略仅改变归约结构。详细边界例见 [`reduce_dim_loop_opt_example.md`](references/reduce_dim_loop_opt_example.md)。

## 策略3：归约三维tile转二维tile优化

### 优化原理

当每线程/每 block 同时持有 `[TILE_M,TILE_K]` 多组 accumulator 并沿 N 归约时，三维 tile 会扩大变量活跃范围与 shared/register 使用。可以把外层 M tile 标量化/循环化，让 block 处理二维 `[N,K]` 归约，降低资源压力；但可能降低数据复用，必须实测。

### 功能说明

1. 准入校验：识别**归约计算作用于三维tile + 沿中间维度(axis=1)归约**的归约操作，若不满足优化特征，直接返回原始代码。
2. 核心优化：将非归约首维度 tile 标量化为一个输出行/任务，只保留归约轴与非归约尾维度的二维协作映射。
3. 逻辑适配：修改 kernel 内部非归约首维度的索引生成、边界判断、访存偏移、mask 规则等，适配分块大小为 1 的标量计算，保证数学结果与原代码完全等价。

### 优化准入校验

- 中间 M 维是非归约轴，输出间独立。
- 标量化后没有跨 M 的共享或同步依赖。
- 新映射不会重复写输出，边界与 stride 可严格重建。
- 先有 ptxas/NCU 证据表明 register/shared/spill 或 occupancy 是瓶颈。

### 优化执行流程

#### 步骤1：关键信息提取

提取优化所需核心信息：

1. 分块信息：三维tile在三个维度上的大小、定义方式、分块参数名。
2. 归约信息：算子类型、原归约轴、输入/输出张量名、keepdim参数值、附加参数。
3. 循环信息：外层遍历循环的变量、范围、步长；程序ID映射逻辑。
4. 访存信息：global/shared 地址、stride、mask 与同步点。
5. 中间结果变量信息：中间结果变量是归约计算中承载累加 / 聚合结果的核心变量，记录中间结果变量的初始化形状、数据类型。
6. 维度分类：
  - 非归约首维度：三维tile中「归约轴（axis=1）左侧」的维度，对应的分块参数将被设为 1。
  - 归约轴维度：三维tile中 axis=1 对应的维度，是归约操作要消除的维度。
  - 非归约尾维度：三维tile中「归约轴（axis=1）右侧」的维度，是归约后保留的维度。

#### 步骤2：优化kernel生成

**核心约束**：函数名兼容、数学结果完全等价，核心修改如下：

##### 2.2 非归约首维度的索引重构（标量化）

1. 非归约首维度：
   - 将原非归约首维度的并行偏移生成逻辑替换为标量偏移计算。
   - 移除该维度的向量广播逻辑，改为标量直接参与地址计算。
2. 归约轴维度、非归约尾维度：
   - 保留原维度的索引和循环含义。
   - 保留原维度的广播规则，仅适配降维后的张量形状。

##### 2.3 中间结果变量重构

1. 中间结果变量识别：定位归约计算中承载累加 / 聚合结果的核心变量。
2. 移除中间结果变量中对应非归约首维度的轴：
  - 原中间结果变量形状（如`[非归约首维度， 非归约尾维度]`）→ 优化后形状（如`[非归约尾维度]`）。
  - 归约操作`keepdim=true`时，保留归约轴的size=1维度，保证张量形状与原代码对齐。
3. 中间结果变量初始化适配新形状，删除与非归约首维度相关的广播逻辑。

##### 2.4 边界判断适配

适配标量索引与降维形状，完成边界判断逻辑的重构，规避越界风险。CUDA 候选仍保留 `m<M` 保护，不能仅因 grid 计算推断无边界风险；归约轴和尾维度保持原 guard。

##### 2.5 访存逻辑适配

核心原则：移除非归约首维度的广播冗余，适配降维后的张量形状，保证load/store逻辑与原代码数学等价。

1. **偏移重构**：移除非归约首维度的向量广播偏移，改为标量偏移直接参与地址计算，消除广播冗余。
2. **Mask适配**：移除向量广播 mask 维度；各逻辑轴的边界语义完整保留。
3. **兼容保留**：完整保留原load/store的所有参数，保证访存数据范围、计算结果与原代码完全一致。

##### 2.6 归约轴适配

1. 归约操作从三维 `[M,N,K]` tile 沿 N，适配为二维 `[N,K]` tile 仍沿 N；
2. 保留归约操作的所有语义，仅调整线程/索引映射以匹配降维后的 tile。

host grid 相应扩大 M tile 数，不改变 stream/shared bytes 以外的无关参数。对比资源、CUDA Event 与所有 shape。

### 优化示例（归约三维tile转二维tile优化）

#### 原始代码（存在外层任务循环的场景）

```cpp
float acc[TILE_M_PER_THREAD][TILE_K_PER_THREAD] = {};
// block 同时维护多个 M/K 输出并沿 N 累积。
```

#### 优化后代码

```cpp
int m = blockIdx.y;
float acc[TILE_K_PER_THREAD] = {};
// block 只维护一个 M 行的 K 输出并沿 N 累积。
```

#### 示例说明：

维度角色、输出所有权、host grid、stride 和尾部 guard 必须一一对应；资源下降只是候选依据，最终仍按真实门禁选择。

归约三维tile转二维tile优化的更多示例见[references/reduce_3d_to_2d_opt_example.md](references/reduce_3d_to_2d_opt_example.md)

## 策略4：for循环消除优化

### 优化原理

只消除编译期可证明恰好执行一次的循环；运行时 shape 等于 tile 的一个测例不足以证明所有用例都单次。

### 功能说明

该优化识别已由 CUDA template/`constexpr` 配置证明只执行一次的分块循环，移除循环外壳与仅为循环服务的冗余变量；不能把某个测试 shape 恰好单次当作静态证明。

### 优化准入校验

#### 步骤1：提取 heuristic 分块映射

这里的 heuristic 映射指 host/template 已冻结的“分块参数 → 循环边界”关系。提取每个配置的定义、实例化、launch 传值和适用 shape。

##### 结果判断

- 如果存在至少一个有效的 heuristic 分块参数设置，记录映射关系并继续步骤2。
- 如果配置无法追踪到编译期常量，停止该循环的优化。

#### 步骤2：分析 kernel 中的所有分块循环

遍历 kernel 函数体中的所有 `for` 循环，判断是否存在可消除的分块循环。

##### 检测方法

1. **识别分块循环结构**：定位以分块参数作为步长、按区间分批遍历某个维度或数据范围的 `for` 循环。
2. **提取循环边界与步长**：从循环范围中提取下界、上界和步长表达式，重点记录作为步长使用的分块参数及其对应的遍历边界。
3. **匹配配置映射**：判断该分块参数是否由编译期配置设置为循环范围全长。
4. **验证循环变量用途**：确认循环变量只用于生成当前分块偏移、mask 或地址表达式，且循环体没有依赖多次迭代累积才正确的副作用。

##### 可消除判断原则

- **可消除**：循环步长参数已通过编译期配置设置为循环上界，且循环下界为 `0` 或可安全化简为起始边界；循环实际只执行一次。
- **不可消除**：循环步长参数未冻结；或配置目标与循环上界不一致；或循环体存在必须多次迭代才等价的复杂副作用；或无法确定循环实际只执行一次。

##### 结果判断

- 如果检测到至少一个可消除分块循环，记录所有可消除循环的循环位置、循环变量名、循环上界、分块参数名，并进入优化执行流程。
- 如果所有分块循环均不可消除，则终止流程，返回原始代码。

- 起点、条件、步长由 template/`constexpr` 决定，迭代次数恒为 1。
- 无 `break/continue`、循环变量最终值依赖或 RAII 生命周期差异。
- 展开后 `__syncthreads()` 仍由所有 block 线程一致到达。

### 优化执行流程

#### 步骤1：分析并改写可消除的分块循环

针对每个可消除循环执行以下改写：

1. **移除 for 循环外壳**：将循环体整体提升到原循环所在位置，保持循环体内部语句顺序不变。
2. **替换循环变量**：将循环体内对循环变量的引用替换为该循环的起始边界，并同步化简由此产生的偏移表达式。
3. **处理中间结果变量**：
   - 分析原循环外的中间结果变量（如 `acc`、`result_sum`）是否仅用于承载该单次循环的结果。
   - 如果能证明删除该变量后语义等价，则删除变量初始化和累加更新，直接将单次归约结果作为最终值（或直接赋值）。
   - 如果无法安全删除，则保留原中间结果变量与更新形式。
4. **多循环处理**：若 kernel 内存在多个可消除循环，逐个改写；若存在嵌套循环，仅消除满足条件的循环，不影响其他循环。

- 仅消除可以证明实际只执行一次的分块循环；如果循环下界、上界、步长之间的关系无法静态确认，则直接跳过该循环。
- kernel 入参不变，host wrapper 中调用不变。
- 仅修改必要代码。

### 优化示例（for循环消除优化）

#### 原始代码

```cpp
// before: constexpr int TILES = 1;
#pragma unroll
for (int t = 0; t < TILES; ++t) consume(t);
```

#### 优化后代码

```cpp
consume(0);
```

#### 示例说明：

循环边界和 `TILES==1` 均为编译期事实，循环变量只作为 `consume(0)` 的索引，故可移除外壳；运行时才知道的 tiles 不适用。

删除循环后同步清理只服务该循环的索引，但不改变地址宽度、mask 和访存顺序。

## 策略5：冗余访存消除优化

### 优化原理

在同一线程中，两次 global load 地址、类型和可见内存版本完全相同时，可复用第一次加载值。对 block 共享数据可考虑 cooperative load 到 shared，但那是独立候选并需同步。

### 功能说明

该策略收集同一线程控制流中的重复 global load，只有在地址、guard、类型、内存版本和别名关系均可证明等价时复用首次加载结果。

### 优化准入校验

#### 步骤1：收集候选 global load

对每条 load 记录：

1. 基址指针和完整地址表达式。
2. 访问数据类型、对齐与 vector width。
3. `mask`、`other` 以及所有关键字参数。
4. load 语句所在的控制流路径与顺序位置。
5. load 结果变量在后续语句中的使用范围。

#### 步骤2：判断 load 等价性

1. 基址指针完全相同，地址表达式语义等价。
2. `mask` 表达式等价，越界替代值等价。
3. 数据类型、volatile/atomic 属性和地址空间相同。
4. 两次 load 位于同一个确定执行路径上；若位于不同 `if` 分支、不同循环迭代，或控制流关系不明确，则不优化。
5. 首次 load 的结果变量在第二次 load 使用点之前没有被重新赋值。

#### 步骤3：检查中间写入与别名风险

在首次 load 与后续重复 load 之间检查是否存在可能影响该内存值的操作：

1. 若存在对同一指针、可能别名指针或未知 helper 的写入，保守跳过。
2. 若写操作只写入明确不同的输出指针（如 `output_ptr`），且该指针与被加载指针不同，可继续优化。
3. 若 kernel 参数中输入指针和输出指针可能来自同一 tensor，且无法从 wrapper 或调用约束证明无别名，则保守跳过。
4. 若 load 使用 `volatile` 或其他要求每次实际访存的语义，直接跳过。

##### 结果判断

- 如果至少发现一组可安全复用的重复 load，则进入优化执行流程。
- 如果所有候选都无法证明等价或存在写入/别名风险，则终止流程，返回当前代码。

1. 展开并规范化两个地址表达式，证明对所有执行路径等价。
2. 中间不存在通过该指针或别名的写入、atomic、未知函数调用或跨线程可见更新。
3. 指针的 `const/restrict` 只作为辅助证据，不能替代别名分析。
4. 复用不会显著延长变量活跃期导致 register/spill 恶化；必须检查 ptxas。

### 优化执行流程

#### 步骤1：选择复用变量

对每组等价 load，选择顺序上最早的 load 结果变量作为复用变量。

#### 步骤2：删除冗余 load

删除后续重复 load，并将其使用点替换为首次加载结果；不得跨同步或内存版本边界移动计算。

#### 步骤3：清理冗余索引与 mask

删除重复 load 后，如果紧邻该 load 之前存在仅为该 load 服务的重复索引、mask 或 offset 计算，且这些变量已经在首次 load 前以等价形式定义并且后续无其他用途，则可以删除重复定义并复用已有变量。但必须确保这些变量不会被任何不同语义的语句使用，否则应保留重复计算，以保证正确性。

- 不要为了制造等价性而重排计算语句；仅删除可证明冗余的 load 及其专属索引/mask。

### 优化示例（冗余访存消除优化）

#### 原始代码（for循环消除后存在重复 load）

```cpp
float a = x[idx];
float p = f(a);
float b = x[idx];
float q = g(b);
```

#### 优化后代码

```cpp
float a = x[idx];
float p = f(a);
float q = g(a);
```

#### 示例说明：

两次地址和控制流相同，中间没有可见写入，因此复用 `a`；若指针可能别名、load 为 volatile 或 helper 可能写入，则该改写不成立。

若复用使 spill 或 median 变差，回退，即使 load 数减少也不能保留。

## 策略6：全维度Reduce改写Load + Reduce + Atomic模式优化

### 优化原理

全维度标量 reduce 可由每 block 分块 load、warp/shared 局部归约，再 atomic 合入一个输出。它能减少中间 buffer 和第二次 launch，但 atomic 冲突可能成为瓶颈；必须与两阶段方案、原实现同时比较。

### 功能说明

该优化检测当前全维度 reduce 是否已采用单 kernel、load + 局部 Reduce + atomic 模式。如果不是且原子类型、数值语义、输出初始化和纯归约逻辑均可证明，则生成独立候选；无法确认语义或原子操作不支持时，回退到原始代码。

### Atomic 指令白名单与归约映射

只使用 share 文档明确支持的 CUDA atomic 与类型。`atomicAdd` 不等价于所有 sum 精度；max/min 的 NaN、signed zero，arg reduce 的 value/index，半精度/双精度支持均需单独验证。没有合法 atomic 时保留两阶段归约。

### 优化准入校验

#### 步骤1：检测全维度 reduce 操作并提取语义

- 确认所有输入逻辑轴都被规约为一个标量或少量独立标量。
- 提取 sum/max/min/mean/norm 等语义、累加类型、单位元与后处理。
- 规约语义必须属于可结合、可交换且支持目标合并方式的类型。

#### 步骤2：判断当前实现是否已是 Load+Reduce+Atomic 形式

检查是否已经由单个 kernel 完成分块 global load、block 内归约和一次 atomic 写；若已满足该模式，准入失败，原样返回代码。

#### 步骤3：检查改写可行性

在生成新 kernel 前，进一步确认：

- 输出初始化在同一 stream 上有明确顺序，且计时口径公平。
- 被改写代码块只负责全维度 reduce，不含其他输出、副作用或数据相关分支。
- 原始 wrapper 中不存在与输出标量相关的别名风险（如输入和输出为同一内存），若无法排除风险，则保守跳过。

一旦通过以上校验，进入优化执行流程。

1. 输出确为单标量或少量独立标量。
2. 输出初始化在同一 stream 上严格发生在 kernel 前，且初始化成本计入端到端对比。
3. atomic 类型和操作合法，数值容差允许非确定顺序。
4. 目标无跨 kernel 中间结果复用需求。

### 优化执行流程

#### 步骤1：生成 Load+Reduce+Atomic 单 kernel

按 grid-stride 分块读取，每线程局部累积，warp/shared 分层归约，最后仅由 block leader 发出合法 atomic。

#### 步骤2：改写 wrapper 函数

保留原始 wrapper 中与规约无关的预/后处理逻辑，将旧规约调用替换为候选 kernel；初始化、launch、错误检查和结果类型均保持 API 契约。

#### 步骤3：清理原始实现残留

移除只为旧规约实现服务的中间 buffer 和 launch；候选目录仍保存原输入及完整 diff，以便门禁失败逐字回退。

### 优化示例（full_reduce_load_atomic_opt）

#### 原始代码（两级 kernel 实现，sum 规约）

```text
stage1: input -> partial buffer
stage2: partial buffer -> scalar output
```

#### 优化后代码

```cpp
__global__ void full_sum(const float* x, float* out, size_t n) {
    float acc = 0.0f;
    for (size_t i = size_t(blockIdx.x) * blockDim.x + threadIdx.x;
         i < n; i += size_t(gridDim.x) * blockDim.x) acc += x[i];
    acc = block_reduce_sum(acc);
    if (threadIdx.x == 0) atomicAdd(out, acc);
}
```

#### 示例说明：

候选消除中间 buffer 和第二次 launch，但增加 atomic 冲突与非确定累加顺序；初始化及端到端成本必须纳入比较，门禁失败则保留两阶段实现。

初始化、atomic kernel 与额外同步/launch 全部纳入公平测量。只有 kernel 时间和端到端口径均清楚时报告收益。

## 策略7：layout 变换消除

### 优化原理

若 host 先 materialize transpose/permute 再归约，可把逻辑坐标映射融入 CUDA 地址计算，避免额外 kernel 和内存流量。它不意味着 global 访问仍合并，必须分析实际 stride。

### 功能说明

该优化用于分析 host wrapper，检测是否存在可安全融合到 CUDA kernel 内部的二维 transpose/permute 或等价 layout materialization。若符合条件，则移除搬运并同步修改 device 索引和归约轴；不存在冗余变换或融合有风险时返回原始代码。

### 优化准入校验

#### 步骤1：检测冗余 transpose/permute 操作

定位 wrapper 中可能存在的冗余转置模式：二维维度交换、紧随其后的 contiguous/materialize，以及功能等价的自定义搬运 kernel。

#### 步骤2：判断当前实现是否已融合或无需优化

- 若 wrapper 中不存在此类转置，或转置与归约之间存在无法忽略的复杂逻辑（如多个分支、写操作等），则判定当前实现无需优化，准入失败，直接返回原始代码。
- 若归约 kernel 可以直接作用于原始维度顺序，而 wrapper 仍显式执行了转置，则属于候选冗余场景。

#### 步骤3：检查改写可行性

在决定改写前，进一步确认：

- 输入张量必须为 **2 维**，归约操作作用在其中一个维度（axis=0 或 axis=1）。
- 转置仅交换两个维度，不涉及更高维或复杂的维度排列。
- 归约操作属于常见的可简单改变轴的类型（如 sum、mean、max、min 等），其语义不受轴变换影响。
- 去除转置后，kernel 内部的 data loading 逻辑可安全调整，且不影响边界处理与其他相关逻辑。
- 不存在依赖原始转置结果的后续运算（即 wrapper 中后续代码使用的是归约输出，而非转置中间量）。

若任一条件不满足，视为风险过高，放弃改写。

- 变换只是 layout 重排，不包含 dtype 转换、广播复制或副作用。
- 归约前后轴映射、shape、stride 可严格恢复。
- 融合后地址不会越界，输出布局与 API 契约一致。
- 若输入来自外部且已经 materialized，不能假设可访问其变换前 buffer。

### 优化执行流程

#### 步骤1：移除冗余转置

在 wrapper 函数中删除目标 transpose/permute 及专门为其服务的 materialization；确保不误删其他必要的连续化操作。

#### 步骤2：适配 kernel 内部的索引与加载逻辑

若 kernel 内有基于转置后形状的索引计算，需同步修改为基于原始 shape/stride 的地址，保证每个 block 加载的数据范围与逻辑边界等价。

#### 步骤3：调整归约轴参数

建立旧坐标到新坐标的双射，将原临时布局的归约轴映射回源 buffer 逻辑轴。

#### 步骤4：验证语义一致性

优化后，归约输出的形状、数值精度及边界行为必须与原始实现完全一致。最终返回值的数据类型也应保持不变。

### 重要提醒

- **严格限制变换**：只能修改归约轴和相关索引，禁止改变归约语义（如将 sum 改为 max）或输出形状。
- **复杂 layout 回退**：对于涉及三维及以上、或使用非常规维度交换的情况，本优化不适用，必须原样返回。
- 比较端到端（含被移除的搬运）和目标 kernel 两种口径，报告不得混用。

### 优化示例（reduce_trans_fusing）

#### 原始代码（冗余 transpose + reduce）

```text
source [N,M] -> materialize transpose [M,N] -> reduce N
```

#### 优化后代码

```text
source [N,M] -> CUDA kernel 以原 stride 直接 reduce 逻辑 N
```

#### 示例说明：

候选移除 host/device 搬运，以源 shape/stride 重写地址。若融合使归约访问严重跨步或真实端到端无收益，按统一门禁回退。

## 各策略的完整分析与生成细则

### A. while/for 等价性证明表

对每个候选循环先填写：

| 项目 | 原表达式 | 证明 |
| --- | --- | --- |
| induction variable | `k` | 单一标量、无地址逃逸 |
| 初值 | `threadIdx.x` | 循环前固定 |
| 条件 | `k < K` | 正向开区间 |
| 更新 | `k += blockDim.x` | 正步长且非零 |
| 溢出 | `int` 范围 | 由 K 上界证明 |
| 退出后使用 | 无 | 改写不影响后续 |

以下情况直接拒绝：

```cpp
while (k < K) {
    if (predicate(x[k])) break;       // 数据相关退出
    k += step[k];                     // 数据相关步长
}
```

反向循环需要保持边界是否包含：

```cpp
int k = K - 1;
while (k >= 0) { consume(k); k -= STEP; }
```

仅当有符号类型和 `K/STEP` 范围证明不会下溢时，才可改写：

```cpp
for (int k = K - 1; k >= 0; k -= STEP) consume(k);
```

无符号 `size_t k >= 0` 永远为真，属于原始 bug，不能以优化名义“修复”并进入性能链；应停止并交回 code-review。

嵌套循环逐层证明。外层 tile 与内层归约若共享 induction variable、修改边界或存在条件同步，则整体跳过；不能只改外壳留下不同迭代序列。

### B. Warp Reduce 模板与有效 lane

对完整 warp 的 sum：

```cpp
__device__ __forceinline__ float warp_sum_full(float v) {
    constexpr unsigned full = 0xffffffffu;
    v += __shfl_down_sync(full, v, 16);
    v += __shfl_down_sync(full, v, 8);
    v += __shfl_down_sync(full, v, 4);
    v += __shfl_down_sync(full, v, 2);
    v += __shfl_down_sync(full, v, 1);
    return v;
}
```

如果只有部分 lane 有效，先给无效 lane 单位元，并保证 mask 中所有 lane 都执行同一组 shuffle。不能在 shuffle 前让无效线程 `return`，也不能把 `__activemask()` 从发生分歧后的分支里随意传播。

常见单位元：

| 操作 | 单位元/初值 | 额外语义 |
| --- | --- | --- |
| sum | `0` | 累加类型与舍入 |
| product | `1` | overflow/underflow |
| max | `-inf` 或类型最低值 | NaN、signed zero |
| min | `+inf` 或类型最高值 | NaN、signed zero |
| all | `true` | bool 表示 |
| any | `false` | bool 表示 |

### C. 多 Warp Block Reduce 模板

```cpp
template<int BLOCK>
__device__ float block_sum(float v) {
    static_assert(BLOCK % 32 == 0, "BLOCK must contain whole warps");
    __shared__ float warp_values[BLOCK / 32];
    int lane = threadIdx.x & 31;
    int warp = threadIdx.x >> 5;
    v = warp_sum_full(v);
    if (lane == 0) warp_values[warp] = v;
    __syncthreads();
    float out = (threadIdx.x < BLOCK / 32) ? warp_values[lane] : 0.0f;
    if (warp == 0) out = warp_sum_full(out);
    return out;
}
```

该模板只适用于一维完整 warp block。若 `blockDim.x` 不是编译期常量、block 为二维、线程数不是 32 倍数或操作不是 sum，必须生成相应安全版本，而不是照抄。第二次 warp reduce 的无效 lane 要使用单位元。

使用动态 shared memory 时：

```cpp
extern __shared__ unsigned char smem_raw[];
float* warp_values = reinterpret_cast<float*>(smem_raw);
```

host 的 `shared_bytes` 必须同步调整，并由 share 中设备限制校验。增大 shared 可能降低 resident blocks/SM；必须记录 occupancy 影响。

### D. Max/Argmax 成对归约

argmax 的 combine 不仅比较 value，还要规定相等值和 NaN 时的 index：

```cpp
struct Pair { float value; int index; };

__device__ Pair combine_argmax(Pair a, Pair b) {
    if (b.value > a.value) return b;
    if (b.value < a.value) return a;
    return (b.index < a.index) ? b : a;  // 仅当 reference 也是最小 index 优先
}
```

`__shfl_down_sync` 要分别传 value/index，再用同一 predicate 更新两者。reference 若有 NaN propagation 或“首个最大值”规则，combine 必须显式复现。无法证明时跳过，不能只优化 value 而破坏 index。

### E. 三维到二维映射证明

原输出坐标：

```text
out[m,k] = reduce_n input[m,n,k]
```

候选把 `m` 从每线程 accumulator 数组移到 `blockIdx.y`：

| 项目 | 原映射 | 候选映射 |
| --- | --- | --- |
| M tile | `blockIdx.y*TILE_M + local_m` | `blockIdx.y` |
| K tile | `blockIdx.x*TILE_K + local_k` | 不变 |
| N reduce | `for n0 ...` | 不变 |
| 输出所有者 | `(block,m,k)` | `(block,k)` |
| accumulator 数 | M×K per thread | K per thread |

必须检查 grid.y 从 `ceil_div(M,TILE_M)` 改为 M 后未超出 grid 限制；M/K 末尾 mask 与 64 位地址保持。若原实现跨 M 复用同一输入或 shared tile，候选会增加 load，报告必须记录这一取舍。

候选生成只改变这一映射。不能同时改变 TILE_N、BLOCK、vector width，否则无法判断收益来自降维还是调参。

### F. 单次循环静态证明

以下可以作为候选：

```cpp
template<int TILES>
__global__ void k(...) {
    static_assert(TILES == 1);
    for (int t = 0; t < TILES; ++t) body(t);
}
```

以下不可以，仅代表某次输入恰好单次：

```cpp
int tiles = (N + TILE - 1) / TILE;
for (int t = 0; t < tiles; ++t) body(t);
```

即使 performance 首例 `N<=TILE`，其他 correctness shape 仍可能多次。若想专门化 shape，必须作为显式 dispatch/config 候选，包含 fallback 路径和分派成本，超出本策略的单次循环消除范围。

循环体存在声明对象、volatile/atomic 或同步时还需检查移除作用域是否改变生命周期与可见性。`#pragma unroll` 本身不保证循环只有一次。

### G. 冗余 Load 等价性表

对每对候选 load 记录：

| 属性 | Load A | Load B | 必须关系 |
| --- | --- | --- | --- |
| base pointer | `x` | `x` | 同一对象/可证明别名 |
| element type | float | float | 相同 |
| address | `base+idx` | `base+idx` | 对所有路径相等 |
| predicate | `i<n` | `i<n` | 相同或 B 的域是 A 子集 |
| memory version | V0 | V0 | 中间无可见写 |

拒绝示例：

```cpp
float a = x[i];
if (threadIdx.x == 0) x[i] = update;
__syncthreads();
float b = x[i];  // 不等价
```

未知 helper：

```cpp
float a = x[i];
device_helper(x);
float b = x[i];
```

除非展开 helper 并证明无写，否则不能复用。atomic、volatile、memory fence、cooperative groups 与跨线程生产者都属于阻断证据。

复用变量延长活跃区间时，ptxas 可能提高 register/thread 或 spill。代码层 load 减少不等于 GPU global transaction 必然减少，编译器也可能已经做 CSE；以 SASS/NCU 与性能为准。

### H. Atomic 与两阶段 Full Reduce

Atomic 候选 host 流程：

```cpp
cudaMemsetAsync(d_out, 0, sizeof(float), stream);
full_sum<<<grid, block, shared_bytes, stream>>>(d_x, d_out, n);
CUDA_CHECK(cudaGetLastError());
```

若计时只包 kernel event，要另行报告初始化成本；端到端对比必须包含初始化。复用已有零初始化只有在 API 契约保证每次输入前都发生时才可排除。

两阶段候选：

```cpp
partial_sum<<<grid1, block, shared1, stream>>>(x, partial, n);
final_sum<<<grid2, block, shared2, stream>>>(partial, out, grid1.x);
```

需要计入 workspace allocation 策略、两个 launch 和全部 kernel 时间。workspace 可在 wrapper 外复用时，报告区分 steady-state 与首次调用；不得用 atomic 的 steady-state 对比两阶段的含 allocation 时间。

不同操作检查：

- sum：累加顺序、精度和 atomic 类型。
- max/min：初始化、NaN、signed zero 与 atomic 实现合法性。
- product：通常没有通用浮点 atomic product，默认保留两阶段。
- arg reduce：需要打包 value/index 和一致 CAS，风险高，默认不自动改写。
- mean：先 sum 后除以 count；count/空输入语义保持。

### I. Layout 融合坐标映射

例如原逻辑先把 `[A,B,C]` permute 为 `[A,C,B]`，再沿最后一轴 B 归约。若直接从原 buffer 读取：

```text
logical[a,c,b] -> source[(a*B+b)*C+c]
```

候选地址：

```cpp
size_t source_idx = (size_t(a) * B + b) * C + c;
```

验证表：

| 项目 | 原 pipeline | 融合候选 |
| --- | --- | --- |
| 输入 shape | A,B,C | A,B,C |
| 临时 shape | A,C,B | 无临时 |
| 归约轴 | temp B | source B |
| 输出 shape | A,C | A,C |
| 全局访问 | temp 连续 B | source stride C |

融合去掉搬运，但归约读取可能从连续变为跨 stride，性能不一定提升。必须同时记录被消除的 transpose 时间、融合 kernel 时间和端到端总时间。若上游只提供已经 permute 的指针而没有原 buffer，无法融合。

### J. Correctness 用例矩阵

每类归约至少覆盖：

| 维度类别 | 示例性质 | 目的 |
| --- | --- | --- |
| 空/零元素（API 允许时） | reduce size 0 | 初值/错误语义 |
| 单元素 | reduce size 1 | 单位元与写入 |
| 小于 warp | 非满 lane | shuffle mask |
| 非 32 倍数 | 尾 warp | lane 有效性 |
| 大于 block | 多轮循环 | 完整覆盖 |
| 极大轴 | 64 位地址 | overflow 与性能 |
| 非连续 | leading dimension/pitch | stride |
| 特殊值 | ±0、Inf、NaN | 操作语义 |

实际 shape 以输入测试为准，不能凭空新增改变 API 契约的用例；但报告要指出缺少哪些边界证据。随机测试固定 seed，候选与 baseline 使用相同数据。

### K. 性能与资源报告结构

每个候选写入：

```json
{
  "strategy": "reduce-axis-loop",
  "parent_sha256": "...",
  "candidate_sha256": "...",
  "compile_command": "...",
  "target": {"gpu": "RTX 3090", "cc": "8.6", "uuid": "..."},
  "correctness": {"passed": true, "atol": 0, "rtol": 0},
  "resources": {"registers_per_thread": 0, "static_smem": 0,
                 "dynamic_smem": 0, "spill_bytes": 0},
  "timing": {"method": "cuda_event", "median_ms": 0,
             "p20_ms": 0, "p80_ms": 0},
  "decision": "keep"
}
```

数值只能来自真实日志；示例中的 0 不是默认填充值。未测时使用 `null`/`not_measured` 并回退源码。报告同时保存 baseline 和候选，不能只列速度更快的一方。

## 统一结果测试

所有候选均按 `utils/Optimizer.md` 执行：

1. 使用 baseline 完全相同的 nvcc/host compiler/flags，并保存 `-Xptxas=-v`。
2. 运行全部 correctness 用例，保持 atol/rtol、seed、shape/dtype/stride 不变。
3. 检查 CUDA API、launch 和同步错误；已有 sanitizer 门禁时不得新增问题。
4. 使用相同 stream、warmup、repeat 和 CUDA Event，比较 median/p20/p80。
5. 记录 register/thread、static/dynamic shared、spill、block/grid；必要时读取真实 NCU occupancy/stall。
6. 候选只有在真实 RTX 3090 上通过全部门禁且明确无回退时才 keep；否则输出逐字回退到该轮输入。

最终报告列出每一策略的准入依据、唯一 diff、测量证据和 keep/revert；不得仅因“代码更像 CUDA 最佳实践”而声称优化成功。

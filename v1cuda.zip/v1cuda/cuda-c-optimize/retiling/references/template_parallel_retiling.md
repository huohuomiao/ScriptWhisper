# CUDA 并行轴 Retiling 模板

以下模板说明逻辑轴如何映射到 CUDA block/thread。它们是候选形态，不包含 RTX 3090 的固定数值；资源限制和初始候选从 share 读取，最终由真实测试决定。

## 独立分块——相邻不同名

```cpp
int m = blockIdx.y * TILE_M + threadIdx.y;
int n = blockIdx.x * TILE_N + threadIdx.x;
if (m < M && n < N) y[m * N + n] = op(x[m * N + n]);
```

对应 `block_size=["TILE_M","TILE_N"]`。适合二维地址、每轴需要独立边界或后续共享 tile 的场景。

## 合并分块——相邻同名

```cpp
size_t f = size_t(blockIdx.x) * blockDim.x + threadIdx.x;
if (f < size_t(M) * N) y[f] = op(x[f]);
```

对应两个逻辑轴共同使用线性 `BLOCK_MN`。只有连续布局且 flatten 不破坏语义时采用；非标准 stride、broadcast、transpose 或按轴归约不能机械合并。

## 归约 + 并行

```cpp
int row = blockIdx.x;
float acc = 0.0f;
for (int k = threadIdx.x; k < K; k += blockDim.x)
    if (row < M) acc += x[row * K + k];
acc = warp_reduce_sum(acc);
```

M 是并行轴，K 是归约轴。K 的循环 tile 与 shuffle/shared 分层必须一起设计；不能只改 `blockDim.x` 而忽略 accumulator、同步和尾 lane。

## Persistent 与普通映射

普通映射：一个 block 负责一个 tile。

```cpp
int tile = blockIdx.x;
process_tile(tile);
```

grid-stride/persistent 候选：

```cpp
for (int tile = blockIdx.x; tile < total_tiles; tile += gridDim.x)
    process_tile(tile);
```

两者必须成对编译和测试。persistent 可能增加变量活跃期和 register 压力；若 ptxas/NCU 显示 spill、低 resident blocks/SM 或低 occupancy，保留普通映射。

## 验证

- 检查每个 shape 的尾 tile、极小维度和非整除尺寸。
- 检查 global load/store 是否合并、shared memory 是否有 bank conflict。
- 保存 register/thread、shared、spill、occupancy 和 CUDA Event 分布。
- correctness/safety/性能任一门禁失败时，输出原输入。

## 二维独立 Tile 完整模板

```cpp
template<int TILE_M, int TILE_N>
__global__ void map2d(const float* __restrict__ x,
                      float* __restrict__ y,
                      int M, int N, int ld_in, int ld_out) {
    int m = blockIdx.y * TILE_M + threadIdx.y;
    int n = blockIdx.x * TILE_N + threadIdx.x;
    if (m < M && n < N)
        y[size_t(m) * ld_out + n] = op(x[size_t(m) * ld_in + n]);
}

dim3 block(TILE_N, TILE_M);
dim3 grid(ceil_div(N,TILE_N), ceil_div(M,TILE_M));
map2d<TILE_M,TILE_N><<<grid,block,0,stream>>>(...);
```

合法性检查：block 线程总数/各维合法，`TILE_M/TILE_N` 与 block 维一致，尾块 guard 完整，地址使用足够宽类型。非 contiguous 输入保留 leading dimensions。

## 一维合并 Tile 完整模板

```cpp
template<int BLOCK>
__global__ void map_flat(const float* x, float* y, size_t elements) {
    size_t f = size_t(blockIdx.x) * BLOCK + threadIdx.x;
    if (f < elements) y[f] = op(x[f]);
}
```

只有 input/output 都按同一 contiguous linear order 解释时，与二维模板等价。若 y 是 transpose 输出、x 有 pitch、操作依赖 row/col、mask 按轴不同或存在 broadcast，flatten 可能不等价。

## Vector Load 候选

```cpp
using Vec = float4;
size_t vec_i = size_t(blockIdx.x) * blockDim.x + threadIdx.x;
size_t base = vec_i * 4;
if (base + 3 < n) {
    Vec v = reinterpret_cast<const Vec*>(x)[vec_i];
    reinterpret_cast<Vec*>(y)[vec_i] = op_vec(v);
} else {
    for (int j = 0; j < 4 && base + j < n; ++j)
        y[base+j] = op(x[base+j]);
}
```

必须证明 x/y 基址、每行起点和 vector index 对齐；尾部 scalar 路径不越界。vector width 是独立候选，不能仅凭 stride=1 自动启用。

## Shared-Memory Tile 候选

对于复用型 stencil/matmul，可协作 load：

```cpp
extern __shared__ float tile[];
int linear_lane = threadIdx.y * blockDim.x + threadIdx.x;
for (int i = linear_lane; i < tile_elements; i += blockDim.x*blockDim.y)
    tile[i] = guarded_global_load(i);
__syncthreads();
// compute using tile
```

shared bytes、bank conflict、同步与 occupancy 需实测。纯 elementwise 无复用时 shared staging 往往无益，不生成默认候选。

## 归约 Tile 组合

| 并行轴 | 归约轴 | 常见映射 | 关键风险 |
| --- | --- | --- | --- |
| M | K | block→M，lane loop→K | shuffle mask/尾 K |
| M,N | K | block→M/N tile，lane→K | accumulator register 压力 |
| B,M | N | flatten B/M，block reduce N | 商余数与 stride |

归约 tile 增大可能提高单 block 工作量，也会增加 accumulator/寄存器/共享内存。persistent + 大 tile 的组合尤其要检查 spill 和 resident blocks/SM。

## Candidate Diff 约束

Retiling 一轮只改变 tile/mapping。保持：

- 算法和数学函数。
- nvcc flags 与 fast-math 状态。
- stream、输入和 benchmark。
- 精度容差。
- 非相关 grid 策略。

若 tile 合法性迫使 block 同时变化，报告要把它们作为一个不可分配置说明；不要再加入其他策略。

## 结果报告

```markdown
- mapping_before / mapping_after:
- axis_to_block_thread:
- coalescing/alignment proof:
- register/shared/spill before/after:
- occupancy evidence:
- correctness/safety:
- CUDA Event median/p20/p80:
- decision and rollback hash:
```

# retiling 优化

分块分析与改写属于通用 CUDA 逻辑；RTX 3090 的 register、shared memory、warp 和运行时约束读取 `.claude/skills/share/cuda-c/references/platform-rules.md`。

## 职责概述

该策略针对 CUDA Kernel 当前的 thread/block 分块方案做修正：

1. 保证各个轴都被 `block_size` 覆盖且 `block_size` 有效参与张量构建
2. 归约轴必须指定 tile，且要么在 kernel 内循环处理，要么由 block/warp 一次覆盖并采用正确的 shuffle/shared 归约

## 步骤

### 步骤1：Kernel Info 提取

参考 `.claude/skills/cuda-c-optimize/kernel-info/strategy.md`，从 CUDA kernel 中提取轴信息。

### 步骤2：`block_size` 全覆盖

查看步骤 1 的轴信息；若可并行轴 `block_size` 为 `null`，为其选择与 `threadIdx`/`blockIdx` 对应的 tile，并使该维度明确参与 global address 与边界判断。不能仅新增常量而不改变线程映射。

详细参考 `references/template_parallel_retiling.md`。

**重要提示**：若 kernel 存在 persistent/grid-stride loop，当引入新的并行轴分块，需保证循环步长覆盖全 grid 且不重不漏。persistent 不是默认优化；当 NCU/ptxas 显示 register、spill 或低 occupancy 时必须生成非 persistent 对照。

`单并行轴`：

```cpp
__global__ void xxx_kernel(...) {
    int total_blocks = (M + BLOCK_M - 1) / BLOCK_M;
    for (int flat_bid = blockIdx.x; flat_bid < total_blocks;
         flat_bid += gridDim.x) {
        // 使用 flat_bid 映射 tile；线程协作与边界检查保持不变。
    }
}
```

`多并行轴`：

```cpp
__global__ void xxx_kernel(...) {
    int tiles_m = (M + BLOCK_M - 1) / BLOCK_M;
    int tiles_n = (N + BLOCK_N - 1) / BLOCK_N;
    for (int flat_bid = blockIdx.x; flat_bid < tiles_m * tiles_n;
         flat_bid += gridDim.x) {
        int tile_m = flat_bid / tiles_n;
        int tile_n = flat_bid % tiles_n;
        // 由 tile_m/tile_n 和 threadIdx 构造地址。
    }
}
```
### 步骤3：归约轴规范化

检查归约轴是否在 kernel 内循环分块；若没有，确认 block/warp 是否一次覆盖该轴，并在 host 配置中冻结 tile。轴过大时不得强行单 block 覆盖，应使用循环分块或分层/split 归约。

示例如下：

```cpp
template<int BLOCK_N>
__global__ void xxx_kernel(const float* x_ptr, float* y_ptr, int M, int N) {
    int row = blockIdx.x;
    float local = CUDART_INF_F;
    for (int n = threadIdx.x; n < N; n += blockDim.x)
        if (row < M) local = fminf(local, x_ptr[row * N + n]);
    // warp/shared 分层归约后由一个线程写 y_ptr[row]。
}
```

若 `BLOCK_N` 是 reduce tile，则由 host launch/template 显式冻结经验证的值，结果如下：

```cpp
constexpr int BLOCK_N = /* 离线候选实测后冻结 */;
dim3 block(BLOCK_N);
dim3 grid(M);
xxx_kernel<BLOCK_N><<<grid, block, 0, stream>>>(x_ptr, y_ptr, M, N);
```
**重要提示**：CUDA C/C++ 不在运行时生成 autotune 装饰器。每个 tile/block 候选必须独立 nvcc 编译、验证和测量，最终源码只保留一个冻结配置。

### 步骤4：验证结果，输出代码

若上面对 kernel 有任何修改，则需运行修改后代码，声明如下：

- 若 nvcc/ptxas 显示 shared memory、register 或 launch 资源超限，优先减小 tile/unroll；具体限制读取 share
- 本优化策略仍必须遵守统一 no-regression 门禁；无收益即回退
- 优化后 kernel 必须通过精度测试，误差应在测试代码设定的阈值范围内，且与原始 kernel 数学等价
- 若精度不正确或执行报错，根据错误信息进行修复，最多尝试 3 次；如果 3 次修复后仍无法通过精度测试，则回退至原始代码并记录原始性能。调试过程中的中间文件保存在本地

以上没有问题，则输出修改后代码。

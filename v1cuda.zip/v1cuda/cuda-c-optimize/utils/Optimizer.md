# Optimizer

## 职责概述

作为指定优化策略的包装器，对策略文档进行读取，执行。最重要地，对优化策略提出诸多约束，保证其可以正确的执行。

## 核心原则

⚠️⚠️⚠️ **非常重要**：优化策略要严格按照策略文档中的工作流程进行，所有调优必须在对应策略文档中有说明，不得做出越界行为。

⛔ **禁止**：凭空捏造，按自己想法进行盲目调优。

## 工作原则

- **保证有输出**：无论优化结果如何，都必须有输出代码 `cuda_optimized.cu` 和调优过程 `cuda_optimized.md`；失败或无实测收益时输出代码必须与 `input.cu` 逐字一致。

## 执行契约（benchmark / 精度验证的统一入口）

所有涉及 CUDA C/C++ 代码的执行必须先确认当前工作流的 EnvConfig 产物，不允许策略自己猜测本地执行环境或 Worker。设备事实与阈值读取 `.claude/skills/share/cuda-c/references/platform-rules.md`。

### 执行后端选择

执行 benchmark / 精度验证前，先从当前策略 `工作目录` 向上推断 `{output_dir}`，并读取：

```text
{output_dir}/EnvConfig/config.md
```

后端判定：

- `execution_backend=local`：直接在本地执行环境执行代码
- `execution_backend=worker`：通过 `submit_task_to_worker.py` 提交 Worker Task
- EnvConfig 缺失或无法判断后端：记录环境错误并终止当前策略，**不要修改 kernel 代码**

若目标设备不是经探测确认的 RTX 3090/sm_86，或上游报告标记 `blocked=true`，当前策略进入 `static_only`：不得编译、运行或 profile；直接复制 `input.cu` 为 `cuda_optimized.cu`，报告写 `decision=not_measured`、`target_verified=false`。动态模式每个候选保存完整 nvcc 命令和 `-Xptxas=-v` 的 register/shared/spill 输出；occupancy、spill 与设备阈值只按 share 文档和真实 NCU 数据判断。

本地执行：

```bash
nvcc -std=c++17 -O3 -lineinfo -arch=sm_86 -Xptxas=-v input.cu -o input && ./input
```

Worker 兜底执行（必须前台同步执行，等待 `submit_task_to_worker.py` 退出后再判断结果；禁止 `&` 后台、禁止并发提交多个 Worker Task）：

```bash
python .claude/skills/cuda-c-main/subagents/scripts/submit_task_to_worker.py \
    --workdir <当前工作目录绝对路径> --command "nvcc -std=c++17 -O3 -lineinfo -arch=sm_86 -Xptxas=-v input.cu -o input && ./input" \
    --timeout-sec 1800 \
    --task-type {accuracy|performance}

```

**Worker 模式结果分类**（以 `submit_task_to_worker.py` 退出码为准）：
- `0` → 执行成功
- `1` → 业务错误（Traceback / 精度不达标）
- `2` → 基础设施错误（输入路径不存在 / Worker 不可达等）→ **不要修改 kernel 代码**，先修 EnvConfig 或路径，终止本 Skill 并提示用户

- 禁止为了测试或 benchmark 另建 Job。
- 判断优化是否有效时，必须以实际执行环境的真实 stdout/stderr/result 为准。

## Optimizer 包装器输入说明

| 参数 | 说明 |
|------|------|
| 策略名称 | 当前执行的优化策略 |
| 策略文档路径 | 当前策略的对应文档 |
| 工作目录 | 当前策略的工作目录 |

## 优化策略输入输出路径说明

- 输入 CUDA C/C++ 代码：`{工作目录}/input.cu`
- 输出 CUDA C/C++ 代码：`{工作目录}/cuda_optimized.cu`
- 输出优化策略报告：`{工作目录}/cuda_optimized.md`

## 优化策略执行步骤

目标平台为 CUDA 时，在读取具体策略前先读取 `.claude/skills/share/cuda-c/references/platform-rules.md`。若策略名称为 `libdevice-opt`，策略文档固定为 `.claude/skills/share/cuda-c/optimize/libdevice-opt.md`；其他策略继续使用调用方传入的文档路径。

### 步骤 1：读取策略文档

使用 Read 工具读取优化策略的操作指引

```bash
Read {策略文档路径}
```

### 步骤 2：执行优化策略

根据输入指定的 `策略名称`，按照策略 `strategy.md` 中的操作指引，严格按步骤执行优化。

### 步骤 3：输出优化结果文件

先将候选写为 `{工作目录}/candidate.cu`，使用与 baseline 完全一致的 nvcc flags、输入、stream、warmup/repeat 和 CUDA Event 统计口径执行门禁。只有编译成功、正确性与 CUDA 错误检查通过且真实 RTX 3090 median 不回退时，才将候选写入 `{工作目录}/cuda_optimized.cu`；否则原样复制 `input.cu`。将真实过程写入 `{工作目录}/cuda_optimized.md`。

每个策略的报告块格式如下：

```markdown
## 策略：{策略名称}
- 状态：{成功/失败}

### 优化说明
{简要描述本策略做了什么修改、修改了哪些部分}

### 精度结果
- 精度是否通过：{accuracy_pass}
- 绝对误差容限 (atol)：{accuracy_atol}
- 相对误差容限 (rtol)：{accuracy_rtol}

### 性能测量
| 指标 | Reference | 优化前 CUDA | 优化后 CUDA |
|------|---------|-------------|-------------|
| 耗时 (ms) | {reference_ms} | {original_cuda_ms} | {opt_cuda_ms} |
| 带宽 (GB/s) | {reference_bandwidth} | {original_cuda_bandwidth} | {opt_cuda_bandwidth} |

### 加速比
- 优化后 vs 优化前：{speedup_opt_vs_original}x
- 优化后 vs Reference：{speedup_opt_vs_reference}x

### 最终代码
- 文件：`{工作目录}/cuda_optimized.cu`
```

**注意事项**：
- 若策略回退为输入代码，报告中需标注状态为`失败`或`无收益`，性能数据使用输入代码的真实数据（opt 值 = original 值，加速比 = 1.0）
- 每个策略的报告块以 `---` 分隔线开头，便于主 agent 解析

---

## 约束

### 1. 调试规范

- 运行代码若出错，请根据错误信息进行调试修改，尝试修复次数最多为3

### 2. 文件权限

- **只能读取**以下文件：
  1. 当前 CUDA C/C++ 代码路径指定的文件
  2. 当前策略的 `strategy.md`
  3. 当前策略的 references 目录下的参考文档（若存在）
  4. 当前工作目录内的 `kernel_info.json` 与其它由本轮主流程预先生成的输入证据
  5. 当前工作目录向上推断出的 `{output_dir}/EnvConfig/config.md` 与 `{output_dir}/Optimizer/baseline.json`
  6. `.claude/skills/share/cuda-c/references/platform-rules.md`；`libdevice-opt` 另可读取 share 中对应策略文档
- **可以写入**以下文件：
  1. 当前工作目录下的文件
- **禁止读取**以下文件：
  1. 其他优化策略目录下的文件
  2. 其他工作目录下的文件
- 读取文件时必须使用绝对路径

#!/usr/bin/env bash
set -euo pipefail

usage() {
    echo "Usage: NCU_KERNEL_NAME='regex:.*kernel_name.*' bash analyzer.sh <output_dir> <cuda_binary> [binary arguments...]" >&2
}

if [[ $# -lt 2 ]]; then
    usage
    exit 2
fi

output_dir=$1
binary_path=$2
shift 2

if ! command -v ncu >/dev/null 2>&1; then
    echo "ERROR: NVIDIA Nsight Compute CLI (ncu) was not found on PATH." >&2
    exit 3
fi

if [[ ! -f "$binary_path" ]]; then
    echo "ERROR: CUDA binary does not exist: $binary_path" >&2
    exit 2
fi

if [[ ! -x "$binary_path" ]]; then
    echo "ERROR: CUDA binary is not executable: $binary_path" >&2
    exit 2
fi

if [[ -z "${NCU_KERNEL_NAME:-}" ]]; then
    echo "ERROR: NCU_KERNEL_NAME is required; never profile an arbitrary helper kernel." >&2
    usage
    exit 2
fi

python_executable=${PYTHON_EXECUTABLE:-python3}
if ! command -v "$python_executable" >/dev/null 2>&1; then
    if command -v python >/dev/null 2>&1; then
        python_executable=python
    else
        echo "ERROR: neither '$python_executable' nor 'python' was found on PATH." >&2
        exit 3
    fi
fi

mkdir -p "$output_dir"
output_dir=$(cd "$output_dir" && pwd -P)
binary_dir=$(cd "$(dirname "$binary_path")" && pwd -P)
binary_path="$binary_dir/$(basename "$binary_path")"
script_dir=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)

report_base="$output_dir/kernel"
report_path="$report_base.ncu-rep"
csv_path="$output_dir/kernel.ncu.csv"
summary_path="$output_dir/kernel.ncu.summary.txt"
json_path="$output_dir/kernel.ncu.summary.json"
device_path="$output_dir/device_info.json"

"$python_executable" "$script_dir/../runtime/get_device_info.py" \
    --device "${CUDA_DEVICE_INDEX:-0}" --indent 2 >"$device_path"

echo "Profiling: $binary_path"
echo "Kernel:    $NCU_KERNEL_NAME"
echo "Output:    $output_dir"

# Kernel replay can execute the selected launch repeatedly. The CUDA program must
# initialize state deterministically and tolerate replay of that launch.
ncu \
    --force-overwrite \
    --target-processes all \
    --replay-mode kernel \
    --kernel-name-base function \
    --kernel-name "$NCU_KERNEL_NAME" \
    --launch-count 1 \
    --section LaunchStats \
    --section Occupancy \
    --section SpeedOfLight \
    --section MemoryWorkloadAnalysis \
    -o "$report_base" \
    "$binary_path" "$@"

if [[ ! -f "$report_path" ]]; then
    echo "ERROR: ncu completed but report was not created: $report_path" >&2
    exit 4
fi

# The raw page preserves stable metric identifiers for analyzer_ncu.py. Keep the
# .ncu-rep as the source of truth when a metric is absent from this compact view.
ncu --import "$report_path" --page raw --csv >"$csv_path"

"$python_executable" "$script_dir/analyzer_ncu.py" \
    "$csv_path" \
    --device-json "$device_path" \
    --json-out "$json_path" | tee "$summary_path"

echo "NCU report:   $report_path"
echo "NCU raw CSV:  $csv_path"
echo "Device JSON:  $device_path"
echo "Text summary: $summary_path"
echo "JSON summary: $json_path"

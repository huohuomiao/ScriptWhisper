# CUDA C/C++ Device Math 与 libdevice 参考

CUDA C/C++ 通常直接调用 CUDA Math API 中的 device 函数和 intrinsic；`nvcc` 在需要时把这些调用降低到 NVVM libdevice、硬件指令或编译器展开。不要在 `.cu` 中导入 Triton 的 `libdevice` wrapper，也不要手写 `__nv_*` 内部符号。函数是否可用、签名和误差界限以当前 Toolkit 的 CUDA Math API 与真实编译为准。

## 1. 选择顺序

1. 先保持普通 CUDA C++ 表达式或标准 device math 函数，例如 `x * y + z`、`sqrtf`、`expf`。
2. 数值稳定性需要时使用专用函数，例如 `log1pf`、`expm1f`、`erfcf`、`hypotf`。
3. 接口需要明确舍入时使用 `__fadd_rn`、`__fdiv_rd`、`__fmaf_rz` 等受支持 intrinsic。
4. 只有明确允许近似并通过边界精度测试时，才尝试 `__expf`、`__logf`、`__sinf` 或 `__fdividef`。
5. `--use_fast_math` 是全局候选，不是默认配置；必须作为独立 build 与精确 baseline 对比。

函数名带 `f` 通常表示 `float`，无 `f` 版本通常表示 `double`。不要依赖隐式提升：FP16/BF16 输入先按接口明确转换和累加类型，避免无意调用 double overload。

## 2. 常用函数族

### 2.1 指数、对数和幂

常用 `float` / `double` 家族：

- `expf` / `exp`、`exp2f` / `exp2`、`exp10f` / `exp10`
- `expm1f` / `expm1`
- `logf` / `log`、`log2f` / `log2`、`log10f` / `log10`
- `log1pf` / `log1p`、`logbf` / `logb`
- `powf` / `pow`、`cbrtf` / `cbrt`
- `ldexpf` / `ldexp`、`scalbnf` / `scalbn`

优先使用稳定形式：

| 易失稳表达式 | CUDA 候选 | 必测范围 |
| --- | --- | --- |
| `logf(1.0f + x)` | `log1pf(x)` | 小 `x`、`x == -1`、`x < -1` |
| `expf(x) - 1.0f` | `expm1f(x)` | 小 `x`、overflow/underflow |
| `powf(x, 1.0f / 3.0f)` | `cbrtf(x)` | 负数、零、极值 |

`powf` 对负底数和非整数指数有定义域约束。不要把它机械改写成 `expf(y * logf(x))`；后者改变负数、零、NaN/Inf 和误差行为。

### 2.2 舍入、余数和分解

- `ceilf`、`floorf`、`truncf`、`roundf`、`rintf`、`nearbyintf`
- `fmodf`、`remainderf`、`remquof`
- `frexpf`、`modff`、`ilogbf`
- `fminf`、`fmaxf`、`fdimf`、`fabsf`、`copysignf`

`fmodf` 与 `remainderf` 的商舍入规则不同，不能互换。`fminf`/`fmaxf` 的 NaN 和 signed-zero 行为应与接口/reference 一致；普通三元表达式或模板 `min/max` 不一定等价。

### 2.3 三角和双曲函数

- `sinf`、`cosf`、`tanf`、`sincosf`
- `sinpif`、`cospif`、`sincospif`
- `asinf`、`acosf`、`atanf`、`atan2f`
- `sinhf`、`coshf`、`tanhf`、`asinhf`、`acoshf`、`atanhf`

计算 `sin(pi*x)` / `cos(pi*x)` 时可评估 `sinpif` / `cospif`，它们可能改善 argument reduction，但仍需覆盖 integer、half-integer、大参数、signed zero 和 NaN。`atan2f(y, x)` 不能替换为 `atanf(y/x)`，后者丢失象限和零符号信息。

### 2.4 误差、概率、Gamma 与 Bessel

- `erff`、`erfcf`、`erfinvf`、`erfcinvf`、`erfcxf`
- `normcdff`、`normcdfinvf`
- `lgammaf`、`tgammaf`
- `j0f`、`j1f`、`jnf`、`y0f`、`y1f`、`ynf`
- `cyl_bessel_i0f`、`cyl_bessel_i1f`

这些函数通常是选择 CUDA device math 的重要原因。先确认当前 Toolkit 头文件存在相应 overload，再用高精度 host/reference 覆盖 tail、pole、定义域边界和大参数；不能仅靠均匀随机样本得出精度结论。

### 2.5 其他稳定函数

- `hypotf(x, y)`：避免直接 `sqrtf(x*x + y*y)` 的部分 overflow/underflow。
- `fmaf(x, y, z)`：一次融合舍入；与分离的乘加可能数值不同。
- `rsqrtf(x)`、`rcbrtf(x)`：倒数根函数，先核对精度契约。
- `nextafterf`、`isfinite`、`isinf`、`isnan`、`signbit`：构建边界测试和分类逻辑。

## 3. 单精度快速 intrinsic

CUDA Math API 中常见的近似 `float` intrinsic 包括：

```cpp
__sinf(x);       __cosf(x);       __tanf(x);
__expf(x);       __exp10f(x);
__logf(x);       __log2f(x);      __log10f(x);
__powf(x, y);    __fdividef(x, y);
__sincosf(x, &s, &c);
```

规则：

1. 它们是近似函数，不是普通函数的别名。只传入受支持的 `float` 参数，不把 `double` 静默降精度。
2. 大参数 argument reduction、subnormal、NaN/Inf、signed zero 和定义域边界可能与普通函数不同。
3. 只局部替换一个候选，保留同输入的精确 baseline；记录 max absolute/relative error，必要时记录 ULP。
4. 查看 PTX/SASS，确认替换确实改变目标指令。编译器可能已经生成相同路径，也可能因为上下文无法应用。
5. 不存在统一的 `__fast_gelu`、`__fast_silu`、`__fast_sigmoid` 或 `__ultra_*` CUDA API；高层激活函数仍由表达式实现。

## 4. 明确舍入 intrinsic

常用单精度家族：

- 加法：`__fadd_rn`、`__fadd_rz`、`__fadd_rd`、`__fadd_ru`
- 乘法：`__fmul_rn`、`__fmul_rz`、`__fmul_rd`、`__fmul_ru`
- 除法：`__fdiv_rn`、`__fdiv_rz`、`__fdiv_rd`、`__fdiv_ru`
- 倒数：`__frcp_rn`、`__frcp_rz`、`__frcp_rd`、`__frcp_ru`
- 平方根：`__fsqrt_rn`、`__fsqrt_rz`、`__fsqrt_rd`、`__fsqrt_ru`
- FMA：`__fmaf_rn`、`__fmaf_rz`、`__fmaf_rd`、`__fmaf_ru`

`rn` 为 round-to-nearest，`rz` 为 toward zero，`rd` 为 toward negative infinity，`ru` 为 toward positive infinity。double 有对应的 `__d*` 家族，但具体签名以当前 CUDA Math API 为准。

这些 intrinsic 用于明确数值语义，不保证更快。`a*b+c` 是否 contraction 受编译器选项影响；若接口要求或禁止 FMA，同时控制 build flags、检查生成代码并测试边界值。

数值 conversion（如 `__float2int_rn`）与 bit reinterpret（如 `__float_as_int`）语义不同，不得互换；对越界、NaN 和 Inf 按官方定义测试。

## 5. 编译 flags 对数学语义的影响

默认 release 基线不启用 `--use_fast_math`：

```bash
nvcc -std=c++17 -O3 -DNDEBUG -lineinfo -arch=sm_86 source.cu -o app
```

需要记录的主要选项：

| 选项 | 影响 |
| --- | --- |
| `--use_fast_math` | 全局启用较快近似路径，并联动 FTZ、精确除法/平方根等设置 |
| `--ftz=true/false` | 控制 flush-to-zero 行为 |
| `--prec-div=true/false` | 控制单精度除法精度模式 |
| `--prec-sqrt=true/false` | 控制单精度平方根精度模式 |
| `--fmad=true/false` | 允许或禁止乘加 contraction |

不要在同一候选中同时启用 fast math、改变 tile、unroll 和算法。若评估 `--use_fast_math`，把它作为完整独立 binary；运行相同 correctness、特殊值和 benchmark，并在报告中列出完整命令。

## 6. FP16、BF16、TF32 与 FP64

- `<cuda_fp16.h>` 和 `<cuda_bf16.h>` 提供半精度类型及 intrinsic。转换、算术和 packed 类型的架构门槛不同，以头文件和 `sm_86` 编译为准。
- FP16/BF16 常以 FP32 累加。接口若要求逐步半精度舍入，不能擅自改为 FP32 累加后一次转换。
- TF32 是 Ampere Tensor Core 的 FP32 matrix input 模式，不是可存储 C++ 标量类型。只有矩阵路径且容差允许时启用。
- RTX 3090 的 FP64 吞吐相对 FP32 较低。double 仅在接口或 reference 需要时保留，不用它掩盖 float 实现误差。
- RTX 3090 无原生 FP8 Tensor Core；拒绝将 FP8 MMA 当作 `sm_86` 优化。

## 7. 精度验证矩阵

每个数学候选至少覆盖：

1. 生产 shape、dtype、stride 和真实输入分布。
2. `+0`、`-0`、最小正常值、subnormal（若契约关心）、最大有限值。
3. `+Inf`、`-Inf`、NaN。
4. 函数定义域边界：log 的零/负数、asin/acos 的 ±1、atan2 的象限、pow 的负底数等。
5. argument reduction 困难点和 overflow/underflow 邻域。
6. max absolute error、max relative error、失败样本；严格需求额外记录 ULP。

baseline/candidate 使用相同编译目标、输入、stream、warmup、repeat 和同步。只有 correctness 满足预先确定的阈值且 RTX 3090 上性能没有回退，才保留替换。

## 8. 官方来源

- CUDA Math API：<https://docs.nvidia.com/cuda/cuda-math-api/>
- CUDA C++ Programming Guide 数学函数附录：<https://docs.nvidia.com/cuda/cuda-c-programming-guide/#mathematical-functions-appendix>
- NVCC Compiler Options：<https://docs.nvidia.com/cuda/cuda-compiler-driver-nvcc/#nvcc-command-options>
- NVVM libdevice User's Guide：<https://docs.nvidia.com/cuda/libdevice-users-guide/>
- CUDA Floating Point：<https://docs.nvidia.com/cuda/floating-point/>

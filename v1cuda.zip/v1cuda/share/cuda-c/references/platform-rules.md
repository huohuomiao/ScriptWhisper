# NVIDIA CUDA C/C++ / RTX 3090 平台规则

仅在目标后端为 NVIDIA CUDA C/C++ 时读取本文件。四个主 Skill 继续负责需求分析、代码生成、审查和优化；设备探测、`sm_86` 约束、编译门禁与性能采集集中保存在 `share/cuda-c`，不要把硬件常量复制到各流程。

## 1. 目标环境门禁

只有以下条件全部成立，才可写“已在目标 Linux / RTX 3090 上验证”：

1. 执行后端的操作系统为 Linux；共享探针的 `operating_system` 必须为 `Linux`。
2. `nvidia-smi` 能看到目标设备，设备名严格匹配 `NVIDIA GeForce RTX 3090`（可省略 `NVIDIA` 前缀，但不能把 3090 Ti 当作 3090）。
3. `nvcc` 可执行，所需 Linux host compiler 可用，且真实 `.cu` 文件能以 `-std=c++17 -arch=sm_86` 完成编译和链接。
4. CUDA Runtime 枚举到同一块 PCI 设备；`cudaDeviceProp` 给出 CC 8.6、82 个 SM，并再次得到 RTX 3090 名称。
5. 运行 `share/cuda-c/runtime/test_env_code.py --device 0`，让真实 `__global__` kernel 完成分配、拷贝、launch、同步和数值校验。只有编译成功或只调用 `cudaGetDeviceCount` 都不够。
6. 原算子的 correctness、边界测试、Compute Sanitizer 和性能基准均在同一目标 GPU 上通过。

先运行：

```bash
python3 .claude/skills/share/cuda-c/runtime/get_device_info.py --device 0
python3 .claude/skills/share/cuda-c/runtime/test_env_code.py --device 0
```

非目标 GPU 可配合 `--allow-other-gpu` 或 `--allow-other-supported` 做移植诊断，但报告必须明确写“未在 RTX 3090 上验证”。`nvidia-smi` 显示的 “CUDA Version” 是驱动可支持的最高 CUDA 版本，不等于本机 CUDA Toolkit 版本；Toolkit 以 `nvcc --version` 和实际编译结果为准。

## 2. RTX 3090 / Compute Capability 8.6 边界

下表用于门禁和解释 profiler 结果；调度与分配仍读取当前进程选中的真实设备属性。

| 项目 | RTX 3090 / CC 8.6 | 使用规则 |
| --- | ---: | --- |
| 架构 | Ampere，`sm_86` | 默认生成 `-arch=sm_86`，禁止依赖 Hopper/Blackwell 专属能力 |
| SM 数 | 82 | 仅用于严格型号核验；launch 计算读取 `multiProcessorCount` |
| 显存 | 24 GB GDDR6X（标称） | 可用显存动态读取，不能按 24 GB 直接分配 |
| warp size | 32 threads | warp 算法和 mask 必须按 32 线程验证 |
| 每 block 最大 threads | 1024 | block 的 x/y/z 乘积不得超过限制 |
| 每 SM 最大 resident blocks | 16 | 仍受 threads、warps、registers、shared memory 共同约束 |
| 每 SM 最大 resident warps / threads | 48 / 1536 | 不可套用 64 warps/SM 的其他架构假设 |
| 每 SM 32-bit registers | 64 K | 编译后的 registers/thread 和分配粒度决定驻留数 |
| 每 thread 最大 registers | 255 | 接近上限通常伴随低 occupancy 或 spill 风险 |
| 每 SM shared memory | 100 KiB | 与 L1 使用统一数据缓存资源配置 |
| 每 block shared memory | 99 KiB | 超过默认 48 KiB 的动态共享内存需显式 opt-in |
| grid x 上限 | `2^31 - 1` | 普通 grid 可远大于 SM 数，不能无故裁剪 |
| grid y/z 上限 | 65,535 | 超限时展平或分批，并完整恢复索引 |
| Tensor Core 数据路径 | TF32、FP16、BF16、INT8/INT4 | RTX 3090 没有原生 FP8 Tensor Core |

不属于 RTX 3090 的能力包括 TMA、WGMMA、thread-block cluster、distributed shared memory 和 Hopper/Blackwell warp-group 特性。即使新 Toolkit 暴露了相应头文件，也必须以 `__CUDA_ARCH__ == 860` 可编译和可执行为边界。

## 3. 运行时属性是唯一真值

launcher 必须用 `cudaGetDevice`、`cudaGetDeviceProperties` 和 `cudaDeviceGetAttribute` 从实际逻辑设备读取 CC、SM 数、可用显存及 shared-memory opt-in 上限，检查每个返回值；不得硬编码运行时资源。

`CUDA_VISIBLE_DEVICES` 会重排 Runtime 的逻辑编号。采集脚本用 PCI bus id 关联 CUDA Runtime 与 `nvidia-smi`，输出逻辑 index、物理 index、UUID 和 PCI id；不要假设逻辑设备 0 等于物理设备 0。

## 4. grid、block 与覆盖语义

### 普通 kernel

普通一维 kernel 的 grid 表示覆盖数据所需的逻辑 block 数：

```cpp
constexpr int threads = 256;
const int blocks = static_cast<int>((n + threads - 1) / threads);
kernel<<<blocks, threads, 0, stream>>>(input, output, n);
```

kernel 中必须执行边界判断：

```cpp
const std::size_t index =
    blockIdx.x * static_cast<std::size_t>(blockDim.x) + threadIdx.x;
if (index < n) output[index] = transform(input[index]);
```

不得把普通 grid 直接改为 `min(logical_blocks, sm_count)`，否则会漏算。只有同时引入等价 grid-stride loop 才能压缩 grid：

```cpp
for (std::size_t index = blockIdx.x * static_cast<std::size_t>(blockDim.x) + threadIdx.x;
     index < n;
     index += static_cast<std::size_t>(blockDim.x) * gridDim.x) {
    output[index] = transform(input[index]);
}
```

二维/三维映射必须检查每一维的 grid 上限、乘法溢出和 flatten/unflatten 等价性。索引与元素总数优先使用 `std::size_t` 或足够宽的无符号整数；不能让 `int` 乘法先溢出再提升类型。

### persistent / 限定 grid kernel

只有具备 grid-stride 或显式任务队列语义，才允许按驻留能力限制 block 数。用 `cudaOccupancyMaxActiveBlocksPerMultiprocessor` 估算 `sm_count * blocks_per_sm` 作为初始候选；persistent kernel 可能因尾波、cache locality 或长任务变慢，必须与普通 grid 同输入比较。

## 5. block、tile 与 occupancy

- 一维逐元素 kernel 首轮通常测试 128、256、512 threads/block；不要因为上限是 1024 就默认使用 1024。
- 二维 tile 要同时满足 `blockDim.x * blockDim.y * blockDim.z <= props.maxThreadsPerBlock`，并保证 warp 内连续线程优先访问 stride-1 维。
- 墢大 tile 或 unroll 可能减少循环和地址计算，也会提高 registers/thread、shared memory 和 live range；不能只按理论 FLOP 判断。
- 使用 `cudaOccupancyMaxPotentialBlockSize` 或 `cudaOccupancyMaxActiveBlocksPerMultiprocessor` 生成候选，不把 occupancy API 的建议当作性能结论。
- 用 `nvcc -Xptxas=-v` 记录 registers、stack、spill 和 shared memory，再用 NCU 的 LaunchStats/Occupancy 解释实际限制项。
- occupancy 不是目标函数。较低 occupancy 可能换来更高 ILP 或数据复用；只有端到端基准决定保留。

## 6. 内存、同步与精度门禁

- 检查每个 Runtime 返回值、字节数溢出和释放路径；launch 后检查 `cudaGetLastError()`，correctness 阶段再同步以捕获异步错误。
- `cudaMemcpyAsync` 只有在 stream 依赖与 host pinned memory 条件满足时才可声称重叠；buffer、stream、event 的生命周期必须覆盖最后一次异步使用。
- shared memory 只用于有证据的复用或跨线程交换；动态容量公式、bank conflict、barrier 一致到达和超过 48 KiB 时的 `cudaFuncSetAttribute` 均需验证。
- `__syncthreads()` 不是 grid barrier；warp collective 的 mask 必须等于真实参与 lanes；fence 只提供可见顺序，原子只保护相应更新。
- FP32 普通算术与 TF32 matrix multiply 不同。FP16/BF16 通常以 FP32 累加；FP64、TF32、fast math 与 atomic 非确定性必须服从接口精度契约。
- `--use_fast_math` 会全局改变数学语义，默认禁用；RTX 3090 不得使用原生 FP8、TMA、WGMMA 或 cluster 路径。详细原语与数学规则分别见 `primitives.md` 和 `libdevice.md`。

## 7. 编译配置

可复现 release 基线：

```bash
nvcc -std=c++17 -O3 -DNDEBUG -lineinfo -arch=sm_86 \
  -Xptxas=-v kernel.cu -o kernel
```

调试阶段使用独立产物：

```bash
nvcc -std=c++17 -O0 -G -g -arch=sm_86 kernel.cu -o kernel_debug
```

`-G` 会显著改变寄存器和性能，不能用于性能结论。如需覆盖 host compiler，使用 `NVCC_CCBIN` 或显式 `-ccbin`，并保持 baseline/candidate 一致。记录完整命令、`nvcc --version`、host compiler、driver、设备 UUID、环境变量和退出码。不要在一次候选中同时改变算法、block、编译器 flags 和数学模式，否则无法归因。

## 8. 可供主流程使用的事实门禁

- 目标 `.cu` 的可执行路径不得包含 Triton/MLU/Cambricon/NRAM 等后端残留；检查清单中的字面量不属于执行路径。
- Runtime 与 `nvidia-smi` 必须通过 PCI id 对应同一设备；只有精确 RTX 3090、CC 8.6、82 SM 才是目标验证。
- 正确性必须覆盖非整 block、空输入、小 Shape、极值、NaN/Inf 和 aliasing（按接口契约），并与独立 CPU reference 比较。
- Compute Sanitizer 的 memcheck、initcheck、racecheck、synccheck 作用不同，任一项不能替代其余项。
- 性能数字来自同一 stream 的 CUDA Event；NCU replay 时间只能分诊，不能作为候选接受基准。
- `share/cuda-c/perf-analyzer/analyzer.sh` 要求精确 `NCU_KERNEL_NAME`，输出 `.ncu-rep`、raw CSV 和摘要；完整报告是最终资源证据。

具体的静态审查、动态门禁、迭代、报告与回退顺序由四个主 Skill 表达，本文件只提供平台判定事实。

## 9. 官方来源

- CUDA C++ Programming Guide：<https://docs.nvidia.com/cuda/cuda-c-programming-guide/>
- CUDA Compute Capability 技术规格：<https://docs.nvidia.com/cuda/cuda-programming-guide/05-appendices/compute-capabilities.html>
- CUDA Runtime API：<https://docs.nvidia.com/cuda/cuda-runtime-api/>
- CUDA Compiler Driver NVCC：<https://docs.nvidia.com/cuda/cuda-compiler-driver-nvcc/>
- CUDA Best Practices Guide：<https://docs.nvidia.com/cuda/cuda-c-best-practices-guide/>
- Compute Sanitizer：<https://docs.nvidia.com/compute-sanitizer/ComputeSanitizer/>
- Nsight Compute CLI：<https://docs.nvidia.com/nsight-compute/NsightComputeCli/>
- RTX 3090 官方规格：<https://www.nvidia.com/en-us/geforce/graphics-cards/30-series/rtx-3090/>

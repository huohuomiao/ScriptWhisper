#!/usr/bin/env python3
"""Compile and run a real CUDA C++ vector-add smoke test on Linux / RTX 3090."""

from __future__ import annotations

import argparse
import json
import os
import platform
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Any


RTX_3090 = re.compile(r"^(?:NVIDIA\s+)?GeForce\s+RTX\s+3090$", re.IGNORECASE)
CUDA_SOURCE = r'''
#include <cuda_runtime.h>

#include <algorithm>
#include <cmath>
#include <cstddef>
#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <vector>

#define CUDA_CHECK(call)                                                         \
    do {                                                                         \
        cudaError_t status_ = (call);                                             \
        if (status_ != cudaSuccess) {                                             \
            std::cerr << #call << ": " << cudaGetErrorString(status_) << "\n"; \
            return 20 + static_cast<int>(status_);                                \
        }                                                                        \
    } while (0)

__global__ void vector_add_kernel(
    const float* __restrict__ x,
    const float* __restrict__ y,
    float* __restrict__ output,
    std::size_t n) {
    for (std::size_t index = blockIdx.x * static_cast<std::size_t>(blockDim.x) + threadIdx.x;
         index < n;
         index += static_cast<std::size_t>(blockDim.x) * gridDim.x) {
        output[index] = x[index] + y[index];
    }
}

int main(int argc, char** argv) {
    const int device = argc > 1 ? std::atoi(argv[1]) : 0;
    const std::size_t n = argc > 2 ? std::strtoull(argv[2], nullptr, 10) : 100003;
    const int threads = 256;
    if (n == 0) {
        std::cerr << "vector length must be positive\n";
        return 10;
    }
    CUDA_CHECK(cudaSetDevice(device));
    cudaDeviceProp props{};
    CUDA_CHECK(cudaGetDeviceProperties(&props, device));

    std::vector<float> host_x(n), host_y(n), host_output(n);
    for (std::size_t i = 0; i < n; ++i) {
        const int xi = static_cast<int>(i % 257) - 128;
        const int yi = static_cast<int>((i * 17) % 509) - 254;
        host_x[i] = static_cast<float>(xi) * 0.03125f;
        host_y[i] = static_cast<float>(yi) * 0.015625f;
    }

    float *device_x = nullptr, *device_y = nullptr, *device_output = nullptr;
    const std::size_t bytes = n * sizeof(float);
    CUDA_CHECK(cudaMalloc(&device_x, bytes));
    CUDA_CHECK(cudaMalloc(&device_y, bytes));
    CUDA_CHECK(cudaMalloc(&device_output, bytes));
    CUDA_CHECK(cudaMemcpy(device_x, host_x.data(), bytes, cudaMemcpyHostToDevice));
    CUDA_CHECK(cudaMemcpy(device_y, host_y.data(), bytes, cudaMemcpyHostToDevice));

    const unsigned long long logical_blocks =
        (static_cast<unsigned long long>(n) + threads - 1) / threads;
    const int blocks = static_cast<int>(std::min<unsigned long long>(logical_blocks, 65535));
    for (int i = 0; i < 3; ++i) {
        vector_add_kernel<<<blocks, threads>>>(device_x, device_y, device_output, n);
    }
    CUDA_CHECK(cudaGetLastError());
    CUDA_CHECK(cudaDeviceSynchronize());

    cudaEvent_t start{}, stop{};
    CUDA_CHECK(cudaEventCreate(&start));
    CUDA_CHECK(cudaEventCreate(&stop));
    constexpr int repeats = 20;
    CUDA_CHECK(cudaEventRecord(start));
    for (int i = 0; i < repeats; ++i) {
        vector_add_kernel<<<blocks, threads>>>(device_x, device_y, device_output, n);
    }
    CUDA_CHECK(cudaEventRecord(stop));
    CUDA_CHECK(cudaEventSynchronize(stop));
    CUDA_CHECK(cudaGetLastError());
    float elapsed_ms = 0.0f;
    CUDA_CHECK(cudaEventElapsedTime(&elapsed_ms, start, stop));
    CUDA_CHECK(cudaMemcpy(host_output.data(), device_output, bytes, cudaMemcpyDeviceToHost));

    double max_abs_error = 0.0;
    std::size_t first_bad = n;
    for (std::size_t i = 0; i < n; ++i) {
        const float expected = host_x[i] + host_y[i];
        const double error = std::fabs(static_cast<double>(host_output[i]) - expected);
        max_abs_error = std::max(max_abs_error, error);
        if (error > 1e-6 && first_bad == n) first_bad = i;
    }

    CUDA_CHECK(cudaEventDestroy(start));
    CUDA_CHECK(cudaEventDestroy(stop));
    CUDA_CHECK(cudaFree(device_x));
    CUDA_CHECK(cudaFree(device_y));
    CUDA_CHECK(cudaFree(device_output));

    std::cout << std::setprecision(12);
    std::cout << "device_name=" << props.name << "\n";
    std::cout << "major=" << props.major << "\n";
    std::cout << "minor=" << props.minor << "\n";
    std::cout << "multiprocessor_count=" << props.multiProcessorCount << "\n";
    std::cout << "total_memory_bytes="
              << static_cast<unsigned long long>(props.totalGlobalMem) << "\n";
    std::cout << "n_elements=" << n << "\n";
    std::cout << "threads_per_block=" << threads << "\n";
    std::cout << "grid_blocks=" << blocks << "\n";
    std::cout << "kernel_ms=" << elapsed_ms / repeats << "\n";
    std::cout << "max_abs_error=" << max_abs_error << "\n";
    std::cout << "first_bad_index=" << (first_bad == n ? -1LL : static_cast<long long>(first_bad)) << "\n";
    return first_bad == n ? 0 : 11;
}
'''


def run(command: list[str], timeout: int) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        command,
        capture_output=True,
        text=True,
        errors="replace",
        timeout=timeout,
        check=False,
    )


def exact_rtx_3090(name: str | None) -> bool:
    return bool(name and RTX_3090.fullmatch(" ".join(name.split())))


def parse_output(output: str) -> dict[str, Any]:
    raw: dict[str, str] = {}
    for line in output.splitlines():
        if "=" in line:
            key, value = line.split("=", 1)
            raw[key.strip()] = value.strip()
    required = {
        "device_name", "major", "minor", "multiprocessor_count", "total_memory_bytes",
        "n_elements", "threads_per_block", "grid_blocks", "kernel_ms", "max_abs_error",
        "first_bad_index",
    }
    missing = sorted(required.difference(raw))
    if missing:
        raise ValueError(f"smoke binary omitted fields: {', '.join(missing)}")
    integers = {
        "major", "minor", "multiprocessor_count", "total_memory_bytes", "n_elements",
        "threads_per_block", "grid_blocks", "first_bad_index",
    }
    floats = {"kernel_ms", "max_abs_error"}
    result: dict[str, Any] = {}
    for key, value in raw.items():
        result[key] = int(value) if key in integers else float(value) if key in floats else value
    result["compute_capability"] = f"{result['major']}.{result['minor']}"
    result["cuda_target"] = f"sm_{result['major']}{result['minor']}"
    result["exact_rtx_3090"] = exact_rtx_3090(result["device_name"])
    return result


def fail(summary: dict[str, Any], code: int, message: str, json_output: bool) -> int:
    summary.update(ok=False, error=message)
    if json_output:
        print(json.dumps(summary, ensure_ascii=False, indent=2, sort_keys=True))
    else:
        print(f"FAIL: {message}", file=sys.stderr)
    return code


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--device", type=int, default=0, help="CUDA-visible logical device index")
    parser.add_argument("--size", type=int, default=100_003, help="positive vector length")
    parser.add_argument("--nvcc", default="nvcc", help="nvcc executable name or path")
    parser.add_argument(
        "--allow-other-supported",
        action="store_true",
        help="allow a working non-target NVIDIA GPU with compute capability >= 8.0",
    )
    parser.add_argument("--json", action="store_true", help="emit one machine-readable JSON object")
    args = parser.parse_args()

    summary: dict[str, Any] = {
        "schema_version": 2,
        "logical_device": args.device,
        "n_elements": args.size,
        "compile_target": "sm_86",
        "operating_system": platform.system(),
        "cuda_visible_devices": os.environ.get("CUDA_VISIBLE_DEVICES"),
    }
    if platform.system() != "Linux":
        return fail(summary, 3, "CUDA C/C++ target validation requires Linux", args.json)
    if args.device < 0:
        return fail(summary, 2, "--device must be non-negative", args.json)
    if args.size <= 0 or args.size > 1_000_000_000:
        return fail(summary, 2, "--size must be in [1, 1000000000]", args.json)
    nvcc = shutil.which(args.nvcc)
    if nvcc is None and Path(args.nvcc).is_file():
        nvcc = str(Path(args.nvcc).resolve())
    if nvcc is None:
        return fail(summary, 3, f"nvcc was not found: {args.nvcc!r}", args.json)
    summary["nvcc_path"] = nvcc
    configured_host = os.environ.get("NVCC_CCBIN")
    host_compiler = None
    if configured_host:
        host_compiler = shutil.which(configured_host) or (
            str(Path(configured_host).resolve()) if Path(configured_host).is_file() else None
        )
    if host_compiler is None:
        host_compiler = next(
            (
                path
                for candidate in ("g++", "gcc", "clang++", "clang", "c++", "cc")
                if (path := shutil.which(candidate))
            ),
            None,
        )
    summary["host_compiler"] = host_compiler
    if host_compiler is None:
        return fail(summary, 3, "Linux GCC/Clang host compiler was not found", args.json)

    try:
        with tempfile.TemporaryDirectory(prefix="cuda_vector_add_smoke_") as temp_name:
            temp_dir = Path(temp_name)
            source = temp_dir / "vector_add_smoke.cu"
            binary = temp_dir / "vector_add_smoke"
            source.write_text(CUDA_SOURCE, encoding="utf-8", newline="\n")
            compile_command = [
                nvcc,
                "-std=c++17",
                "-O2",
                "-lineinfo",
                "-arch=sm_86",
                str(source),
                "-o",
                str(binary),
            ]
            summary["compile_command"] = compile_command
            compiled = run(compile_command, 180)
            summary["compile"] = {
                "returncode": compiled.returncode,
                "stdout": compiled.stdout.strip(),
                "stderr": compiled.stderr.strip(),
            }
            if compiled.returncode != 0 or not binary.is_file():
                return fail(summary, 4, "nvcc failed to build the sm_86 CUDA C++ smoke test", args.json)
            executed = run([str(binary), str(args.device), str(args.size)], 120)
            summary["execution"] = {
                "returncode": executed.returncode,
                "stdout": executed.stdout.strip(),
                "stderr": executed.stderr.strip(),
            }
            if executed.returncode != 0:
                return fail(summary, 5, "CUDA C++ vector-add binary failed", args.json)
            result = parse_output(executed.stdout)
    except (OSError, subprocess.SubprocessError, ValueError) as exc:
        return fail(summary, 6, f"{type(exc).__name__}: {exc}", args.json)

    summary["result"] = result
    cc = (result["major"], result["minor"])
    if cc < (8, 0):
        return fail(summary, 7, f"compute capability {result['compute_capability']} is below 8.0", args.json)
    exact_match = bool(
        result["exact_rtx_3090"]
        and cc == (8, 6)
        and result["multiprocessor_count"] == 82
    )
    if not exact_match and not args.allow_other_supported:
        return fail(
            summary,
            8,
            "device is not an exact RTX 3090 / sm_86 / 82-SM target; "
            "use --allow-other-supported only for portability diagnostics",
            args.json,
        )
    summary.update(
        ok=True,
        exact_target_match=exact_match,
        validation_scope="RTX_3090_SM86" if exact_match else "SUPPORTED_NON_TARGET_GPU",
        temporary_directory_cleaned=True,
    )
    if args.json:
        print(json.dumps(summary, ensure_ascii=False, indent=2, sort_keys=True))
    else:
        print(f"nvcc: {nvcc}")
        print(
            f"GPU {args.device}: {result['device_name']}; CC {result['compute_capability']}; "
            f"{result['multiprocessor_count']} SMs"
        )
        print("TARGET_MATCH: exact RTX 3090 / sm_86" if exact_match else "TARGET_MISMATCH_ALLOWED")
        print(
            f"PASS: CUDA C++ vector add ({result['n_elements']} elements), "
            f"max_abs_error={result['max_abs_error']:.3e}, kernel={result['kernel_ms']:.6f} ms"
        )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
